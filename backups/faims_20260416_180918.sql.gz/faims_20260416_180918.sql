--
-- PostgreSQL database dump
--

\restrict S0cKBaMyLkvxwyOh3BdsIeXPvTSh69Dp0ugZvOpFOqD0CXcZkITCqfWNpDW2qJJ

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Departments; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."Departments" (
    "Id" uuid NOT NULL,
    "Name" text NOT NULL,
    "OrganizationId" uuid NOT NULL,
    "CreatedDate" timestamp with time zone NOT NULL,
    "UpdatedDate" timestamp with time zone,
    "DeletedAt" timestamp with time zone,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Departments" OWNER TO faims_admin;

--
-- Name: FirstAidKits; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."FirstAidKits" (
    "Id" uuid NOT NULL,
    "UniqueNumber" text NOT NULL,
    "Name" text NOT NULL,
    "RoomId" uuid NOT NULL,
    "ResponsibleUserId" uuid NOT NULL,
    "OrganizationId" uuid NOT NULL,
    "CreatedDate" timestamp with time zone NOT NULL,
    "UpdatedDate" timestamp with time zone,
    "DeletedAt" timestamp with time zone,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."FirstAidKits" OWNER TO faims_admin;

--
-- Name: Journals; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."Journals" (
    "Id" uuid NOT NULL,
    "ActionType" integer NOT NULL,
    "Reason" text,
    "MedicationName" text NOT NULL,
    "Quantity" integer NOT NULL,
    "Unit" integer NOT NULL,
    "FirstAidKitId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "OrganizationId" uuid NOT NULL,
    "BatchId" uuid,
    "CreatedDate" timestamp with time zone NOT NULL,
    "UpdatedDate" timestamp with time zone,
    "DeletedAt" timestamp with time zone,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Journals" OWNER TO faims_admin;

--
-- Name: Medications; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."Medications" (
    "Id" uuid NOT NULL,
    "Name" text NOT NULL,
    "Quantity" integer NOT NULL,
    "ExpirationDate" timestamp with time zone NOT NULL,
    "MinimumQuantity" integer NOT NULL,
    "Unit" integer NOT NULL,
    "FirstAidKitId" uuid NOT NULL,
    "OrganizationId" uuid NOT NULL,
    "CreatedDate" timestamp with time zone NOT NULL,
    "UpdatedDate" timestamp with time zone,
    "DeletedAt" timestamp with time zone,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Medications" OWNER TO faims_admin;

--
-- Name: Organizations; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."Organizations" (
    "Id" uuid NOT NULL,
    "Name" text NOT NULL,
    "Address" text,
    "CreatedDate" timestamp with time zone NOT NULL,
    "UpdatedDate" timestamp with time zone,
    "DeletedAt" timestamp with time zone,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Organizations" OWNER TO faims_admin;

--
-- Name: RefreshTokens; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."RefreshTokens" (
    "Id" uuid NOT NULL,
    "Token" text NOT NULL,
    "ExpiresAt" timestamp with time zone NOT NULL,
    "IsRevoked" boolean NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UserId" uuid NOT NULL
);


ALTER TABLE public."RefreshTokens" OWNER TO faims_admin;

--
-- Name: Rooms; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."Rooms" (
    "Id" uuid NOT NULL,
    "Name" text NOT NULL,
    "DepartmentId" uuid NOT NULL,
    "OrganizationId" uuid NOT NULL,
    "CreatedDate" timestamp with time zone NOT NULL,
    "UpdatedDate" timestamp with time zone,
    "DeletedAt" timestamp with time zone,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Rooms" OWNER TO faims_admin;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."Users" (
    "Id" uuid NOT NULL,
    "Email" text NOT NULL,
    "PasswordHash" text NOT NULL,
    "FirstName" text NOT NULL,
    "LastName" text NOT NULL,
    "Role" integer NOT NULL,
    "FcmToken" text,
    "OrganizationId" uuid NOT NULL,
    "AvatarUrl" text,
    "CreatedDate" timestamp with time zone NOT NULL,
    "UpdatedDate" timestamp with time zone,
    "DeletedAt" timestamp with time zone,
    "IsDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Users" OWNER TO faims_admin;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: faims_admin
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO faims_admin;

--
-- Data for Name: Departments; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."Departments" ("Id", "Name", "OrganizationId", "CreatedDate", "UpdatedDate", "DeletedAt", "IsDeleted") FROM stdin;
093635d4-2442-48d6-ba13-82572bc97bfb	Неврологічне відділення	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299228+00	\N	\N	f
e57afb5b-0534-4748-bf04-b86569d01ec8	Інфекційне відділення	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.356963+00	2026-04-16 12:15:21.883055+00	\N	f
25af8e61-06e9-44a4-b7c9-fb04d4d572d3	Гінекологічне відділення	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.356964+00	\N	\N	f
373e7c8c-48ab-4f35-9240-0b907526aca8	Педіатричне відділення	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.35697+00	\N	\N	f
5626defc-cc69-4d54-bab2-6e225f6b5c7c	Хірургічне відділення	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.356963+00	\N	\N	f
907130cb-72f7-4aab-a952-9131360f15f4	Кардіологічне відділення	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.356961+00	\N	\N	f
acf504b1-f916-4571-9f89-0cab40073f0a	Травматологічне відділення	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.356964+00	\N	\N	f
d543dc16-edef-440c-a265-788e086f0f2b	Терапевтичне відділення	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.35697+00	\N	\N	f
3295fde9-7647-4cc4-8d60-1be8135bbdec	Інфекційне відділення	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299227+00	\N	\N	f
33be1ee6-6a54-486b-ab0d-806481ec2aef	Офтальмологічне відділення	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299227+00	\N	\N	f
70e78b0b-86b2-4787-9572-2ef52fe02870	Травматологічне відділення	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299226+00	\N	\N	f
eb261711-a00f-4ff4-bb5d-32a4ecdbc212	Гінекологічне відділення	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299227+00	\N	\N	f
1ca1c8a6-8773-495d-a9f7-229a2070f4b3	Травматологічне відділення	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909234+00	\N	\N	f
28df8d82-7849-4ce2-8896-8b0eac2643e6	Педіатричне відділення	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909232+00	\N	\N	f
4adc0153-1f37-4020-9535-eb744b344006	Хірургічне відділення	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909234+00	\N	\N	f
6a7807ce-1f0a-40df-8872-a13814f02b15	Реанімаційне відділення	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909234+00	\N	\N	f
bdd99256-b436-41aa-8bb6-488553bf00c5	Терапевтичне відділення	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909234+00	\N	\N	f
e8f8987f-d0fa-43ab-9295-10cf0500a467	Інфекційне відділення	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909235+00	\N	\N	f
229c2be0-4fd6-412b-b870-b488e449c9d3	Хірургічне відділення	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59425+00	\N	\N	f
5faec016-5b45-4f64-b42d-0df65713e837	Інфекційне відділення	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594248+00	\N	\N	f
62903c81-d34c-4d49-a3c7-e1a53b1d2edf	Травматологічне відділення	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59425+00	\N	\N	f
a42aa014-2f14-4edf-9982-bd478b090e4f	Терапевтичне відділення	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594249+00	\N	\N	f
c49b0d33-5ae6-4d21-a588-065edfcd4888	Гінекологічне відділення	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59425+00	\N	\N	f
ef0ef570-07d6-457f-af27-cd7407353dbe	Реанімаційне відділення	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594248+00	\N	\N	f
f84bf2c3-a30f-4f12-9690-02ba51ab317d	Неврологічне відділення	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59425+00	\N	\N	f
73fb67be-579d-4a4e-b020-23b5487b4c4e	Травматологічне відділення	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182773+00	\N	\N	f
85fb6ac3-f6e1-42dd-bc6a-9db53b023358	Педіатричне відділення	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182773+00	\N	\N	f
b499562d-dc37-489b-b148-e2cabea48b45	Офтальмологічне відділення	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182773+00	\N	\N	f
ed62e0cd-c3c4-4821-9a7e-9d7e8ed689d7	Неврологічне відділення	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182773+00	\N	\N	f
\.


--
-- Data for Name: FirstAidKits; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."FirstAidKits" ("Id", "UniqueNumber", "Name", "RoomId", "ResponsibleUserId", "OrganizationId", "CreatedDate", "UpdatedDate", "DeletedAt", "IsDeleted") FROM stdin;
0944e862-db47-4840-ba45-fe2e8e8efd08	FAK-01-0010	Аптечка Кабінет №133	9e7c904a-6278-404e-ada5-2bc26b3e2909	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974859+00	\N	\N	f
2e53fef1-346d-4743-a751-fc71275d8c0c	FAK-01-0011	Аптечка Кабінет №127	90dab6ed-5999-4284-b8e4-dfbf3afbbbf4	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974861+00	\N	\N	f
d7b3f772-167e-4f25-9a85-310e632a4abc	FAK-01-0002	Аптечка Кабінет №112	27850b62-e6d1-4390-b605-25e67a51d7fe	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974853+00	2026-04-16 08:21:36.503513+00	\N	f
2f24781b-5362-408d-8677-8bdd2751e5ec	FAK-01-0007	Аптечка Кабінет №119	40f087b0-f7df-4b55-a049-d99970224401	2b04b4d7-2de1-4b02-8e0b-9ffd67d1d495	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974858+00	\N	\N	f
3022448e-a09d-4689-8d1d-a4594b5d9102	FAK-01-0004	Аптечка Кабінет №130	336f75b8-38e0-492a-8b97-7c881f795c8a	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974854+00	\N	\N	f
4886163b-e61f-4357-9b8f-097d50a821cd	FAK-01-0001	Аптечка Кабінет №104	69e5f864-601b-42b4-a61d-e7bc5a00dd65	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974847+00	\N	\N	f
855c830b-fee4-4ff1-94a4-3d93122907fe	FAK-01-0009	Аптечка Кабінет №126	6108aefa-43fc-4d40-97f1-ac5a264ff611	f18f48a0-76df-4e4e-b172-65aa694751f5	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974859+00	\N	\N	f
9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	FAK-01-0005	Аптечка Кабінет №129	a5c13bf0-a0b8-4a64-8635-33fd0fcafa21	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974854+00	\N	\N	f
afe653db-7e14-40c9-8758-0bf4babdf69e	FAK-01-0006	Аптечка Кабінет №108	b2dbdb91-713d-423e-b6f4-8ec89dcec27b	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974857+00	\N	\N	f
c36d1c0c-34aa-4bcf-a542-15964da77279	FAK-01-0012	Аптечка Кабінет №116	7b5ae4fc-9f58-4f40-86e7-64382ccd25f4	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974861+00	\N	\N	f
e21fcfed-c37a-4190-adf2-c7aa8ea7c264	FAK-01-0003	Аптечка Кабінет №124	ea28d6cc-4920-444c-966e-4e53c3db1049	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974853+00	\N	\N	f
2208e0cd-22d4-4613-b425-18801b7efc51	FAK-02-0004	Аптечка Кабінет №104	e917cc43-1bda-4bbd-a99f-303928d07cc9	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762437+00	\N	\N	f
521dd62d-9375-4440-9001-828eb746a50a	FAK-02-0005	Аптечка Кабінет №117	ae69dc8c-e35b-41d9-89d9-af2dce06580d	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762438+00	\N	\N	f
75760860-1113-46d6-9cfb-9d6b14667b38	FAK-02-0008	Аптечка Кабінет №120	7de1e7a3-0ad0-495a-842a-3d67c0d57fee	112ffb29-b1d0-4a55-b239-b84f5639842a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76244+00	\N	\N	f
7e435359-29d6-4eb2-8bb5-23362118973f	FAK-02-0003	Аптечка Кабінет №106	d503c0c6-7680-4183-a7eb-cb93ee6e5277	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762431+00	\N	\N	f
9bdb768a-f4cd-4362-b8fb-bc29f727af93	FAK-02-0002	Аптечка Кабінет №105	6463aaf3-3178-4a75-8793-7fa78c268ea5	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762431+00	\N	\N	f
9c4054e0-89cd-490d-9ced-dcbfd107537d	FAK-02-0010	Аптечка Кабінет №112	fcefa63d-e806-44c6-b533-9460adf62c19	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762441+00	\N	\N	f
9e8f24cc-3649-4841-9f10-72ed2d5d780b	FAK-02-0009	Аптечка Кабінет №111	7f9d678a-7f72-413f-a368-7ba5e93b2ca7	68202c68-294e-4a04-b5c6-af07caccaad8	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762441+00	\N	\N	f
c38ec754-c644-4b07-8b9a-7b36772da0f3	FAK-02-0001	Аптечка Кабінет №109	2817f369-a56d-4949-823f-805bf7f2df61	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762427+00	\N	\N	f
cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	FAK-02-0006	Аптечка Кабінет №107	e04c300c-0cad-43a7-b944-0f0c4ae340f5	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762439+00	\N	\N	f
f79c547f-cee7-466a-86e5-4618a86adbd3	FAK-02-0007	Аптечка Кабінет №108	36f395d8-de6b-45c8-ab93-cafab46f48f3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.762439+00	\N	\N	f
2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	FAK-03-0011	Аптечка Кабінет №102	dd1e5770-88bc-493e-babb-eea69de9cfe8	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456049+00	\N	\N	f
44457538-eed8-40d0-9186-dca9e4ed9f9f	FAK-03-0001	Аптечка Кабінет №128	3e7c3e48-9503-4f75-9dce-76be755a2f95	b7772c6a-cce9-4b4d-8b26-53f4dae7375e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456042+00	\N	\N	f
618a3475-904f-466b-a192-52be990ea7fe	FAK-03-0004	Аптечка Кабінет №129	7e9a0a89-a695-4d0a-b01b-8afdb4990568	f180ad63-2730-43fc-83da-54fa3c9da5a4	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456044+00	\N	\N	f
8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	FAK-03-0010	Аптечка Кабінет №112	6316371e-0939-4af5-aa35-1597aa93cfc5	8a7df9ad-f99a-4687-83b1-a974c72d0657	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456049+00	\N	\N	f
93091039-76bb-4740-868c-4421685ad968	FAK-03-0003	Аптечка Кабінет №103	2ce0cff5-442e-4f46-9077-6aaa0f61c6b3	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456043+00	\N	\N	f
a07b8cb1-b942-4cac-9c94-3f70c71e35ec	FAK-03-0005	Аптечка Кабінет №117	66a35332-cd17-49d9-8ed6-7fbdfacb9168	d830c597-a126-4420-9735-2bc6e0c1ed84	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456047+00	\N	\N	f
c95c544b-7c9e-4c22-8ac8-eef5aed3d662	FAK-03-0012	Аптечка Кабінет №124	99863a2f-17ac-4699-a867-fae4b305606f	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456051+00	\N	\N	f
d129b3c4-be09-4e82-bb40-3af9ab8181c9	FAK-03-0008	Аптечка Кабінет №116	079202fc-f4b6-4cb3-b373-035043e55714	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456048+00	\N	\N	f
d999009f-9975-473c-b50b-2e795c35271c	FAK-03-0009	Аптечка Кабінет №100	a223023d-0597-40a9-bacb-d3dbcd108cdc	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456048+00	\N	\N	f
e666c0dc-34e4-41a4-884c-5c4d7a98caed	FAK-03-0006	Аптечка Кабінет №127	6b35ce62-2168-4fe2-b2c9-c8d0f81a3d01	51953ce5-3663-4f9e-a117-4c5b99a6fbd7	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456047+00	\N	\N	f
f1d00635-0565-4eaf-b4cf-228beb6a8dca	FAK-03-0007	Аптечка Кабінет №118	365f6f08-9137-4956-acda-457b00acd209	30110403-4d1a-44f8-8cd9-04d92f5663c8	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456048+00	\N	\N	f
fbe7fcd2-1037-426a-a2c2-107eddad006e	FAK-03-0002	Аптечка Кабінет №107	8c9fdd04-67dc-42eb-b920-43be0d71c834	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456043+00	\N	\N	f
0241c840-f709-4030-a7c3-4780bc84e743	FAK-04-0004	Аптечка Кабінет №127	2e788830-e4e6-4c19-a7d6-25d8c406366e	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091669+00	\N	\N	f
03c26c05-1356-48b7-9f81-e802098016e0	FAK-04-0001	Аптечка Кабінет №121	1e9c8b21-1440-4014-a7ea-26e2082f7acb	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091665+00	\N	\N	f
4b92861f-c987-4786-a375-f284f41e658c	FAK-04-0006	Аптечка Кабінет №119	c27e1078-5a98-44c3-96a6-b5cdc509226c	0d7481c3-6296-4ea8-9904-a8332b6ff51f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09167+00	\N	\N	f
57f31d29-fb5e-4cfa-ab47-0318d16efaac	FAK-04-0009	Аптечка Кабінет №111	e3ac9166-9f0f-486b-a252-d1fe06e7608e	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091678+00	\N	\N	f
5878a5da-6011-4ff8-bec3-b56cee1ea7f5	FAK-04-0007	Аптечка Кабінет №100	b7c27d7b-2b9a-44d5-af05-db062605bf3d	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091677+00	\N	\N	f
96cfdf35-e54e-4785-ae4b-0bac61199794	FAK-04-0003	Аптечка Кабінет №109	bfe87682-ae5d-4677-bd0c-1cdf2d6ac016	4d12ada0-e540-45f2-82d9-1f09d36f8c44	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091668+00	\N	\N	f
a4ad4bf8-435b-44ec-87fd-6b9cea759b36	FAK-04-0008	Аптечка Кабінет №129	2faa3536-7802-4e55-8255-6b41930c49bb	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091678+00	\N	\N	f
c6e912f5-28db-4b92-80a1-f5e3d7819846	FAK-04-0011	Аптечка Кабінет №103	afc56bd2-44ab-4784-b341-5182c4fff357	dce88cda-deda-494c-a043-57cfee71a2d7	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091679+00	\N	\N	f
dd2fb9ff-a18c-4c22-8f15-3be96e14d554	FAK-04-0002	Аптечка Кабінет №125	3c1e8c23-16ce-46c8-b8bf-f5019d80aa74	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091666+00	\N	\N	f
e8ab6cc3-8374-4102-b680-0e8cc0354cb3	FAK-04-0005	Аптечка Кабінет №118	41fe2d23-c2ad-423d-9bf9-7ac563a30189	1a5e4c12-68c3-45d3-a92d-bef2c82e1334	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091669+00	\N	\N	f
f6e6f5d3-630b-4902-8358-7b6e3af39038	FAK-04-0010	Аптечка Кабінет №126	75ea03b5-ca8e-4747-99ce-e33ca199c0d4	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091678+00	\N	\N	f
06302277-15e6-4ecf-85bd-cae11f170372	FAK-05-0001	Аптечка Кабінет №100	8f54f625-6f2e-4d54-bf42-e7f0dd95b564	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765972+00	\N	\N	f
06931566-89d2-4933-8551-6b4fb796afc7	FAK-05-0007	Аптечка Кабінет №102	bb4f3239-ea16-4a2f-bfe0-535e39e7198a	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76598+00	\N	\N	f
23d89a46-4b24-4c7e-9e64-3e027577dec1	FAK-05-0002	Аптечка Кабінет №118	10ce71d7-86c3-496a-8d03-a32ae6ce5e38	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765973+00	\N	\N	f
41f7cb7b-019f-414c-afec-81f375a50e57	FAK-05-0006	Аптечка Кабінет №113	7ce73394-385e-404a-b505-d48fd64e1820	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765976+00	\N	\N	f
5574e047-35eb-46f3-a453-9c5fdf488c87	FAK-05-0009	Аптечка Кабінет №104	51d5f28a-0a63-45b5-a2a7-f7b2047caff2	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765981+00	\N	\N	f
6acd5b88-42f5-4612-a475-469a220c1b17	FAK-05-0011	Аптечка Кабінет №106	bf57ed05-95c1-48e1-85de-0a20f57445c6	44e6ae52-0550-4867-b49b-92eb3078c59d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765982+00	\N	\N	f
e375ca95-635b-4ca3-b762-27a950bdd006	FAK-01-0008	Аптечка Кабінет №100	9d0eee5f-cb26-4b59-849f-d0370435c525	019d9634-10f6-7e3d-8898-a05a0de01bd7	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974858+00	2026-04-16 12:12:19.237573+00	\N	f
6b47cfd0-6948-493c-ba26-2305d73679a8	FAK-05-0008	Аптечка Кабінет №111	1863336f-de06-43c5-855f-0358e4c9b03f	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765981+00	\N	\N	f
8992ed22-2f1d-44ab-958c-a1785f7da058	FAK-05-0013	Аптечка Кабінет №101	f2ad47df-f9d8-401d-b1ee-f31d02bcc7e9	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765983+00	\N	\N	f
8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	FAK-05-0004	Аптечка Кабінет №110	f950f047-6383-4bec-a645-83b248565e88	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765975+00	\N	\N	f
9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	FAK-05-0010	Аптечка Кабінет №105	f28f43de-4cb8-42c6-89bc-c45f9181faa1	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765981+00	\N	\N	f
b6292e00-9c92-40ae-a4b5-a73f306cd665	FAK-05-0012	Аптечка Кабінет №115	67c3562e-5ac8-4f1f-982f-f7e87530db9d	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765982+00	\N	\N	f
f1ce3185-25b4-4096-8362-be811b916e3d	FAK-05-0003	Аптечка Кабінет №117	4a16eaa6-bfc0-4ea0-8494-1ff6b92e2552	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765974+00	\N	\N	f
f3b82c93-17b4-4ceb-9964-b577b5707105	FAK-05-0005	Аптечка Кабінет №107	a1b1d685-0300-4a44-8d53-fc838df3309d	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.765975+00	\N	\N	f
2e84553d-2b1d-4dc9-bf85-46c9c85434e9	FAK-01-0013	Аптечка Кабінет №117	04916acb-b3eb-471b-a92d-cbbd0f5ad15a	1f2e36bb-b869-43c3-8993-c0ab8918a5ad	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.974862+00	2026-04-10 23:53:20.010913+00	\N	f
\.


--
-- Data for Name: Journals; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."Journals" ("Id", "ActionType", "Reason", "MedicationName", "Quantity", "Unit", "FirstAidKitId", "UserId", "OrganizationId", "BatchId", "CreatedDate", "UpdatedDate", "DeletedAt", "IsDeleted") FROM stdin;
019d7698-2cc9-7757-bbb0-b9b4ac108bcd	0	New medication 'Активоване вугілля' added with quantity 10 Tablets.	Активоване вугілля	10	3	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	019d7698-2cc9-7f4a-9c02-ff443c9a82b1	2026-04-10 08:52:57.673706+00	\N	\N	f
019d7699-5511-776b-bdaf-ade8a27bf16c	4	Medication 'Активоване вугілля' used. Quantity changed from 10 to 0. Used 10 Tablets.	Активоване вугілля	10	3	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	019d7698-2cc9-7f4a-9c02-ff443c9a82b1	2026-04-10 08:54:13.521698+00	\N	\N	f
019d7699-fad2-762f-8c47-2855f9267fd4	0	New medication 'Активоване вугілля' added with quantity 10 Pieces.	Активоване вугілля	10	0	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	019d7699-fad1-72be-bc2f-985267dc114f	2026-04-10 08:54:55.954041+00	\N	\N	f
019d9561-6817-7cb5-a2e6-f3fc6d36c5d9	0	New medication 'тест' added with quantity 1 Grams.	тест	1	2	d7b3f772-167e-4f25-9a85-310e632a4abc	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	019d9561-680c-76b8-affb-397e2d6362bf	2026-04-16 08:21:22.065305+00	\N	\N	f
20694b50-1dcc-4c94-bfe6-cc9e333abf2e	5	Списано через закінчення терміну	Фізіологічний розчин 0.9%	12	1	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-24 08:45:46.775742+00	\N	\N	f
21893b3f-fe63-4d06-a91f-a7681615418e	4	Використано пацієнтом	Анальгін 500мг	10	3	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-19 08:45:46.775736+00	\N	\N	f
237cfb25-74dc-4922-8e6a-61bf58cc7bc6	2	Коригування кількості	Бинт еластичний	1	0	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-07 08:45:46.775732+00	\N	\N	f
25f7f470-50ab-4372-99e6-b9c3c107ae93	1	Передано в інше відділення	Рукавички медичні	7	0	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-28 08:45:46.775728+00	\N	\N	f
263042d8-4171-4f3b-b22e-8d72445f38c5	4	Використано пацієнтом	Ібупрофен 200мг	15	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-20 08:45:46.775725+00	\N	\N	f
2930c6ae-03b9-4fa4-8eba-de84af219a89	5	Списано через закінчення терміну	Анальгін 500мг	10	3	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-20 08:45:46.775745+00	\N	\N	f
29d97875-f874-45cc-8e5c-49057a7adacd	5	Списано через закінчення терміну	Серветки спиртові	1	5	6acd5b88-42f5-4612-a475-469a220c1b17	44e6ae52-0550-4867-b49b-92eb3078c59d	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-17 08:45:46.775758+00	\N	\N	f
2b4475af-2983-403a-ac18-c7e6bf1ab44e	2	Коригування кількості	Серветки спиртові	1	5	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-03 08:45:46.775757+00	\N	\N	f
2c10a50f-b5ce-499b-a42e-32698ba297c9	4	Використано пацієнтом	Цитрамон	7	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-06 08:45:46.775726+00	\N	\N	f
2e0b7e42-d39a-4e52-9bc6-84055016fbc9	2	Коригування кількості	Рукавички медичні	8	0	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-21 08:45:46.775763+00	\N	\N	f
2e70a843-b4ac-4221-b9e5-4d1ddd882fb9	2	Коригування кількості	Серветки спиртові	1	5	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-01 08:45:46.775716+00	\N	\N	f
2e8db7c2-1613-420f-825f-95c59db794d8	0	Поповнення запасів	Вата стерильна	3	2	b6292e00-9c92-40ae-a4b5-a73f306cd665	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-01 08:45:46.77576+00	\N	\N	f
2ed2d35d-35dd-4792-ab84-040a5419e3d6	0	Поповнення запасів	Кеторолак 10мг	1	3	23d89a46-4b24-4c7e-9e64-3e027577dec1	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-07 08:45:46.775719+00	\N	\N	f
2f428a2a-60a9-491e-a679-90a455208f1a	4	Використано пацієнтом	Нітрогліцерин	5	3	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-21 08:45:46.775756+00	\N	\N	f
310fcc44-d8cd-4616-89bd-03ed39c6e775	1	Передано в інше відділення	Аспірин 500мг	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-23 08:45:46.775748+00	\N	\N	f
34d5cb9b-9c6d-44a8-9d0d-2ce8b93843f8	2	Коригування кількості	Розчин йоду 5%	5	1	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-14 08:45:46.775766+00	\N	\N	f
36efb3ac-e0d9-411d-9779-278d1e92c84a	5	Списано через закінчення терміну	Фізіологічний розчин 0.9%	149	1	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-06 08:45:46.775746+00	\N	\N	f
388f4a87-0110-4f82-bae4-5655dc5fae52	4	Використано пацієнтом	Валідол	6	3	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-21 08:45:46.775763+00	\N	\N	f
3973382d-b76a-4924-840d-aa83ed5843cb	2	Коригування кількості	Джгут гумовий	1	0	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-25 08:45:46.775765+00	\N	\N	f
3b4a7501-2009-45bf-9bf3-4c8ef7c7c61a	1	Передано в інше відділення	Атропін 0.1%	2	4	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-23 08:45:46.775744+00	\N	\N	f
3c79d075-6389-4331-b0ae-08f3d5144769	0	Поповнення запасів	Спирт етиловий 70%	28	1	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-25 08:45:46.775725+00	\N	\N	f
3f0c0a55-635c-4091-873a-97437a7b9b5c	4	Використано пацієнтом	Аспірин 500мг	1	3	6acd5b88-42f5-4612-a475-469a220c1b17	44e6ae52-0550-4867-b49b-92eb3078c59d	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-24 08:45:46.775758+00	\N	\N	f
42f24fe4-d7a5-43d1-8b05-e79f84739ba9	2	Коригування кількості	Адреналін 0.1%	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-15 08:45:46.775726+00	\N	\N	f
47c520df-4eb6-49f5-ae1e-b725704e446c	5	Списано через закінчення терміну	Фізіологічний розчин 0.9%	114	1	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-24 08:45:46.775756+00	\N	\N	f
4915bdae-3752-4fc2-91a0-ae375b1d6d52	3	Виявлено протермінований препарат	Дімедрол 1%	6	4	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-20 08:45:46.775764+00	\N	\N	f
4a1f5b93-2843-4b44-8205-cb278c3b463a	2	Коригування кількості	Перекис водню 3%	54	1	b6292e00-9c92-40ae-a4b5-a73f306cd665	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-19 08:45:46.77576+00	\N	\N	f
4b5267ca-7862-43be-bdbb-73ae1c174369	4	Використано пацієнтом	Маска медична	9	0	23d89a46-4b24-4c7e-9e64-3e027577dec1	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-21 08:45:46.77572+00	\N	\N	f
4ca52be4-fd74-42e2-b7b7-f06e7596f86c	5	Списано через закінчення терміну	Бинт еластичний	2	0	6acd5b88-42f5-4612-a475-469a220c1b17	44e6ae52-0550-4867-b49b-92eb3078c59d	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-08 08:45:46.775757+00	\N	\N	f
4feb19e4-7cdc-4799-9b38-58cb1ba0737c	0	Поповнення запасів	Бинт марлевий (упаковка)	1	5	b6292e00-9c92-40ae-a4b5-a73f306cd665	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-30 08:45:46.775761+00	\N	\N	f
5a7cdb84-d017-412a-9f16-014ffd234ab0	0	Поповнення запасів	Анальгін 50% (амп.)	2	4	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-04 08:45:46.775721+00	\N	\N	f
5b43a00b-8cc2-43b0-9ca1-e30b324ccbce	1	Передано в інше відділення	Хлоргексидин 0.05%	9	1	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-24 08:45:46.775755+00	\N	\N	f
5d93353a-69d4-4119-818f-cfa2f54e7bdb	0	Поповнення запасів	Бісептол 480мг	5	3	6acd5b88-42f5-4612-a475-469a220c1b17	44e6ae52-0550-4867-b49b-92eb3078c59d	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-05 08:45:46.775759+00	\N	\N	f
611f55f7-a72f-411d-88e4-bc6645375e00	4	Використано пацієнтом	Папаверин 2%	3	4	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-25 08:45:46.775746+00	\N	\N	f
62e3683b-7a58-41b0-89c2-00bf3a3161fe	1	Передано в інше відділення	Амоксицилін 500мг	6	3	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-11 08:45:46.775735+00	\N	\N	f
6490bf8a-c2fe-4b53-a918-e72caddc044a	1	Передано в інше відділення	Валідол	7	3	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-25 08:45:46.775765+00	\N	\N	f
019d76aa-1e88-7a73-95ec-24f2cd60a1b0	0	New medication 'Активоване вугілля' added with quantity 5 Tablets.	Активоване вугілля	5	3	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	019d76aa-1e87-7270-a262-f1174de88cfa	2026-04-10 09:12:33.672004+00	\N	\N	f
019d956d-38c4-7839-9659-2e5861a5cd12	5	Medication 'Валідол' written off. Quantity changed from 20 to 0. Written off 20 Tablets. Reason: Протерміновано	Валідол	20	3	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	6a35499f-2a40-46d8-b004-da851ad33bf6	2026-04-16 08:34:16.388649+00	\N	\N	f
66f1f654-c657-4fb5-8741-eacaf05d645e	3	Виявлено протермінований препарат	Перекис водню 3%	16	1	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-28 08:45:46.775733+00	\N	\N	f
67510697-6206-4b25-8813-ae089ae1cfae	4	Використано пацієнтом	Ібупрофен 200мг	1	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-15 08:45:46.775727+00	\N	\N	f
6952dd73-7961-4ad0-bc08-a64085043b54	5	Списано через закінчення терміну	Розчин брильянтового зеленого	2	1	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-06 08:45:46.775764+00	\N	\N	f
71b0e29d-f38c-4bc8-b29d-53409c1ce836	0	Поповнення запасів	Атропін 0.1%	1	4	23d89a46-4b24-4c7e-9e64-3e027577dec1	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-15 08:45:46.775717+00	\N	\N	f
736a8ba0-a088-4654-a5f3-89bca2071377	1	Передано в інше відділення	Серветки спиртові	2	5	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-03 08:45:46.775716+00	\N	\N	f
74a706e2-6ea5-4d4f-8975-2c645a2cafc6	0	Поповнення запасів	Марля медична	66	2	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-26 08:45:46.77573+00	\N	\N	f
74f71146-ce2f-4587-8376-21770c96d431	4	Використано пацієнтом	Цитрамон	2	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-10 08:45:46.775729+00	\N	\N	f
7544d351-4ec6-4f2d-af0f-62d79824024a	3	Виявлено протермінований препарат	Нітрогліцерин	3	3	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-15 08:45:46.775724+00	\N	\N	f
7593c416-7618-439d-b335-bf9a8829a939	1	Передано в інше відділення	Рукавички медичні	5	0	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-08 08:45:46.775734+00	\N	\N	f
77205383-6903-42b0-a460-1ddd58566687	0	Поповнення запасів	Парацетамол 500мг	4	3	23d89a46-4b24-4c7e-9e64-3e027577dec1	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-27 08:45:46.775718+00	\N	\N	f
77a475b1-81ff-4978-acbd-0746be0fe931	2	Коригування кількості	Нітрогліцерин	4	3	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-28 08:45:46.775753+00	\N	\N	f
79a396ad-ec8d-4fe9-923d-039e17107e5c	5	Списано через закінчення терміну	Бісептол 480мг	4	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-03 08:45:46.775728+00	\N	\N	f
79f10a96-5405-475b-abb0-3885f72580dc	5	Списано через закінчення терміну	Валідол	4	3	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-12 08:45:46.775767+00	\N	\N	f
7a86118f-b539-4336-9c1d-c743f1040675	2	Коригування кількості	Серветки спиртові	2	5	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-08 08:45:46.775754+00	\N	\N	f
7bc76a94-d92c-4276-a11f-762db89a636a	1	Передано в інше відділення	Цитрамон	1	3	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-19 08:45:46.775744+00	\N	\N	f
7bd26b66-5cd9-4e67-8b9b-005a338c4dc4	1	Передано в інше відділення	Корвалол	2	1	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-31 08:45:46.775766+00	\N	\N	f
7c102025-08fb-4a3f-891b-be40d6defb60	0	Поповнення запасів	Магнію сульфат 25%	3	4	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-29 08:45:46.775714+00	\N	\N	f
7c21d96d-1e0f-4d6e-baf8-536ba753d73f	4	Використано пацієнтом	Шприц одноразовий 10мл	11	0	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-04 08:45:46.775741+00	\N	\N	f
855f8cc9-eb8c-400b-9051-79191e2391d5	1	Передано в інше відділення	Атропін 0.1%	1	4	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-28 08:45:46.775723+00	\N	\N	f
868b41e6-a0ce-433f-a880-7c18fe4cb4c2	4	Використано пацієнтом	Шприц одноразовий 10мл	8	0	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-21 08:45:46.775715+00	\N	\N	f
8b05f1ce-a783-417f-92cd-fa7fa2b61fbd	0	Поповнення запасів	Нітрогліцерин	9	3	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-09 08:45:46.775709+00	\N	\N	f
8ca0cf76-8641-4d1c-8e5e-e55e8b35d135	1	Передано в інше відділення	Бинт еластичний	1	0	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-22 08:45:46.775731+00	\N	\N	f
8ed88665-60f4-467b-9b62-25776d7bb99f	4	Використано пацієнтом	Ібупрофен 200мг	11	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-19 08:45:46.775727+00	\N	\N	f
8fa21708-f708-48db-9435-ffb87b43d666	4	Використано пацієнтом	Нітрогліцерин	10	3	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-01 08:45:46.775751+00	\N	\N	f
9200e0b8-3109-4318-81a7-23a4a89a3dd4	4	Використано пацієнтом	Фізіологічний розчин 0.9%	94	1	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-19 08:45:46.775731+00	\N	\N	f
9293c018-a51a-4841-bd59-eb5c8fab1157	4	Використано пацієнтом	Серветки спиртові	1	5	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-30 08:45:46.775753+00	\N	\N	f
93b167f1-b3c8-4e08-98cc-096366dd5629	1	Передано в інше відділення	Цитрамон	9	3	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-15 08:45:46.775711+00	\N	\N	f
943b325c-3e9a-47d9-9829-af147ace68bb	2	Коригування кількості	Лоперамід	6	3	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-14 08:45:46.775724+00	\N	\N	f
94b79e0e-bdb0-49b3-8ebc-d9d9d15e5c4c	5	Списано через закінчення терміну	Преднізолон 30мг	2	4	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-10 08:45:46.775733+00	\N	\N	f
96df9f93-e7fe-458a-bf38-faaa2f167d7f	5	Списано через закінчення терміну	Кеторолак 10мг	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-10 08:45:46.775763+00	\N	\N	f
9bfdf3d3-53f9-448d-9394-aea1fca090b8	1	Передано в інше відділення	Дексаметазон 4мг	5	4	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-08 08:45:46.775723+00	\N	\N	f
9d94363c-5f53-427a-80eb-d6d54936224d	4	Використано пацієнтом	Шприц одноразовий 10мл	5	0	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-27 08:45:46.775753+00	\N	\N	f
9e242ada-ff2e-409b-a828-700f1d01b370	5	Списано через закінчення терміну	Джгут гумовий	1	0	b6292e00-9c92-40ae-a4b5-a73f306cd665	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-29 08:45:46.775762+00	\N	\N	f
9ef99f20-ac54-44c5-9f06-4d632b328ffe	0	Поповнення запасів	Папаверин 2%	1	4	b6292e00-9c92-40ae-a4b5-a73f306cd665	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-02 08:45:46.77576+00	\N	\N	f
9f6c93a7-9904-4685-830c-e716e38311e5	4	Використано пацієнтом	Марля медична	81	2	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-07 08:45:46.775752+00	\N	\N	f
a28eba38-a6c1-4883-ac7b-034d589ddef5	0	Поповнення запасів	Адреналін 0.1%	1	4	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-26 08:45:46.77574+00	\N	\N	f
a3754e9d-a944-4f34-8898-3cf5051ec692	2	Коригування кількості	Парацетамол 500мг	3	3	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-24 08:45:46.775735+00	\N	\N	f
a489b970-af51-45e3-9f1e-f82c0c451997	1	Передано в інше відділення	Анальгін 50% (амп.)	2	4	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-26 08:45:46.775745+00	\N	\N	f
008225cc-f87a-48c9-8e9c-7a6dc385d97a	5	Списано через закінчення терміну	Розчин брильянтового зеленого	12	1	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-20 08:45:44.029879+00	\N	\N	f
047ae8df-26cd-4882-bf16-b30395b50ce0	0	Поповнення запасів	Валідол	6	3	855c830b-fee4-4ff1-94a4-3d93122907fe	f18f48a0-76df-4e4e-b172-65aa694751f5	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-24 08:45:44.029915+00	\N	\N	f
054012cd-e732-4a09-b5ab-f77554c24abe	1	Передано в інше відділення	Диклофенак 50мг	1	3	c36d1c0c-34aa-4bcf-a542-15964da77279	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-08 08:45:44.029944+00	\N	\N	f
0881a125-e24b-4ede-9ca0-e1be85ede92b	0	Поповнення запасів	Перекис водню 3%	20	1	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-23 08:45:44.029881+00	\N	\N	f
0a513128-f753-49ca-af68-219e820d331d	2	Коригування кількості	Аспірин 500мг	1	3	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-13 08:45:44.029888+00	\N	\N	f
0a74153f-b338-4038-bf1c-451ef97dc8ed	3	Виявлено протермінований препарат	Ібупрофен 200мг	4	3	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-20 08:45:44.02993+00	\N	\N	f
0b298b4c-85e9-4621-8f8f-74fffbec967d	0	Поповнення запасів	Анальгін 50% (амп.)	2	4	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-28 08:45:44.029937+00	\N	\N	f
0daf1ae5-7413-4636-adbc-0b247b3e44e6	2	Коригування кількості	Розчин брильянтового зеленого	12	1	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-17 08:45:44.02988+00	\N	\N	f
0db6f83a-4851-409e-bafb-e16473d9cf1c	4	Використано пацієнтом	Анальгін 500мг	1	3	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-16 08:45:44.029912+00	\N	\N	f
0e38504e-d011-44cc-8dcd-7961922ee4e7	2	Коригування кількості	Бинт марлевий (упаковка)	1	5	855c830b-fee4-4ff1-94a4-3d93122907fe	f18f48a0-76df-4e4e-b172-65aa694751f5	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-31 08:45:44.029916+00	\N	\N	f
0ea376b4-a5d0-495c-a2aa-aa22b6fd167b	4	Використано пацієнтом	Лоперамід	4	3	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-26 08:45:44.029875+00	\N	\N	f
10be77fb-f1f8-42b8-868e-404d4b29b1b2	3	Виявлено протермінований препарат	Шприц одноразовий 10мл	10	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-08 08:45:44.029882+00	\N	\N	f
11ca29f5-f288-4026-9f94-8b090a1a0237	4	Використано пацієнтом	Нітрогліцерин	5	3	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-23 08:45:44.029918+00	\N	\N	f
1495ff68-8989-417a-9d89-5dd598803ae5	1	Передано в інше відділення	Шприц одноразовий 5мл	1	0	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-17 08:45:44.029842+00	\N	\N	f
14a56926-f5a2-4d0e-8011-82bed4c33b79	5	Списано через закінчення терміну	Бісептол 480мг	3	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	1f2e36bb-b869-43c3-8993-c0ab8918a5ad	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-01 08:45:44.029952+00	\N	\N	f
19aa024a-861c-4435-821e-88ead1f7a195	5	Списано через закінчення терміну	Бинт стерильний 5м×10см	2	0	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-31 08:45:44.029836+00	\N	\N	f
1a321db1-5ad1-467c-bcb8-bc644398d3d2	0	Поповнення запасів	Валідол	1	3	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-15 08:45:44.029863+00	\N	\N	f
1ea34237-369a-4f7c-8772-fb17b2bbc679	3	Виявлено протермінований препарат	Бісептол 480мг	1	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	1f2e36bb-b869-43c3-8993-c0ab8918a5ad	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-06 08:45:44.029945+00	\N	\N	f
1f51ad1f-25e8-4a60-8cb1-ebe32dd4a8bc	0	Поповнення запасів	Папаверин 2%	2	4	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-06 08:45:44.029874+00	\N	\N	f
250e46e2-635b-4022-bd7a-08ed633773d1	3	Виявлено протермінований препарат	Бинт стерильний 5м×10см	2	0	c36d1c0c-34aa-4bcf-a542-15964da77279	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-18 08:45:44.029943+00	\N	\N	f
26b4f2bd-a299-436b-ba33-f83b488af634	4	Використано пацієнтом	Кеторолак 10мг	3	3	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-10 08:45:44.029864+00	\N	\N	f
28a34a31-4a1e-4ba9-8966-25c7bd471b4b	4	Використано пацієнтом	Адреналін 0.1%	2	4	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	1f2e36bb-b869-43c3-8993-c0ab8918a5ad	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-25 08:45:44.029952+00	\N	\N	f
2d594e3c-c5e9-43ab-bf24-bb03e06b7ad2	3	Виявлено протермінований препарат	Лоперамід	4	3	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-24 08:45:44.029876+00	\N	\N	f
3529b98e-be0a-4b82-88e5-049041579054	1	Передано в інше відділення	Лоперамід	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-15 08:45:44.029879+00	\N	\N	f
35c93a4a-3fb0-418f-a957-173060d66a40	0	Поповнення запасів	Ібупрофен 200мг	1	3	c36d1c0c-34aa-4bcf-a542-15964da77279	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-26 08:45:44.02994+00	\N	\N	f
365eeb5e-f79d-4e4c-ac33-dd82e39b7dbc	1	Передано в інше відділення	Шприц одноразовий 10мл	5	0	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-24 08:45:44.029846+00	\N	\N	f
394db7c2-55b9-4f1d-a78c-a1e25b5b145e	0	Поповнення запасів	Хлоргексидин 0.05%	27	1	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-10 08:45:44.0299+00	\N	\N	f
3a886690-7439-4817-acd0-7dd884b18202	1	Передано в інше відділення	Бісептол 480мг	2	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	1f2e36bb-b869-43c3-8993-c0ab8918a5ad	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-30 08:45:44.029946+00	\N	\N	f
3bcae716-a093-4cf0-93d6-342e2ebc7e57	1	Передано в інше відділення	Дімедрол 1%	1	4	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-28 08:45:44.029911+00	\N	\N	f
3c8555cd-862c-4519-9ac3-907a930bfed0	2	Коригування кількості	Бинт стерильний 5м×10см	2	0	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-14 08:45:44.029835+00	\N	\N	f
40167d46-5459-491f-a0d5-ef144ee8f9c9	4	Використано пацієнтом	Фізіологічний розчин 0.9%	17	1	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-24 08:45:44.029885+00	\N	\N	f
408db4a9-a837-42c1-af4f-a534b0977b0f	4	Використано пацієнтом	Валідол	1	3	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-07 08:45:44.02985+00	\N	\N	f
41824327-fbb2-4fa6-8d87-c7789b523ccc	0	Поповнення запасів	Спирт етиловий 70%	76	1	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-30 08:45:44.029812+00	\N	\N	f
43e97ebb-fe1b-41d8-ae5e-4a068f49dbe4	2	Коригування кількості	Хлоргексидин 0.05%	88	1	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-11 08:45:44.029928+00	\N	\N	f
465654e4-6373-482f-9b5e-16d96e2de232	4	Використано пацієнтом	Лоратадин 10мг	2	3	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-02 08:45:44.029841+00	\N	\N	f
470571d1-4886-4c73-8aa8-6148df047d03	2	Коригування кількості	Бинт стерильний 5м×10см	1	0	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-01 08:45:44.029842+00	\N	\N	f
470827af-440d-4489-b1ef-28a07562b2a7	2	Коригування кількості	Цитрамон	6	3	855c830b-fee4-4ff1-94a4-3d93122907fe	f18f48a0-76df-4e4e-b172-65aa694751f5	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-05 08:45:44.029916+00	\N	\N	f
4869032d-29f9-46b7-900b-428b857a258b	3	Виявлено протермінований препарат	Перекис водню 3%	31	1	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-11 08:45:44.029919+00	\N	\N	f
4a382068-92c5-400e-8bd2-5ef93d72c020	5	Списано через закінчення терміну	Хлоргексидин 0.05%	76	1	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-26 08:45:44.02982+00	\N	\N	f
4b78c59d-19d6-4835-801d-20e6b4646793	2	Коригування кількості	Но-шпа 40мг	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-07 08:45:44.029868+00	\N	\N	f
4d172a4d-1089-4194-91d3-11e3f8609212	2	Коригування кількості	Бісептол 480мг	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-01 08:45:44.029891+00	\N	\N	f
4e510765-2314-491c-8331-464b9d6584e7	3	Виявлено протермінований препарат	Бісептол 480мг	3	3	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-07 08:45:44.029795+00	\N	\N	f
514d6330-30f6-432d-9f33-85a3d192bf1b	2	Коригування кількості	Перекис водню 3%	48	1	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-04 08:45:44.029894+00	\N	\N	f
531d85da-0e7a-4581-8c76-648c58b0f9c7	0	Поповнення запасів	Активоване вугілля	7	3	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-08 08:45:44.029817+00	\N	\N	f
5613545c-1bcd-439b-911b-9a0f34c164ad	2	Коригування кількості	Джгут гумовий	2	0	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-15 08:45:44.02989+00	\N	\N	f
568051e6-497c-47a2-ad7e-3101dc4a18ba	3	Виявлено протермінований препарат	Цитрамон	5	3	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-06 08:45:44.029926+00	\N	\N	f
5822fdbe-ed0f-42c5-9ae5-e9eb0bb1cf06	0	Поповнення запасів	Валідол	1	3	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-16 08:45:44.029848+00	\N	\N	f
5cad5765-8190-48b7-a056-24c1530cc82c	1	Передано в інше відділення	Диклофенак 50мг	1	3	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-04 08:45:44.029932+00	\N	\N	f
5eda921b-2abc-40a6-911a-e315dbafa248	4	Використано пацієнтом	Хлоргексидин 0.05%	40	1	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-05 08:45:44.029819+00	\N	\N	f
5edc705d-83d6-4b29-80b4-ed690afd829b	5	Списано через закінчення терміну	Хлоргексидин 0.05%	42	1	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-28 08:45:44.029815+00	\N	\N	f
68375115-352c-4d02-8544-afd28c2f0f09	4	Використано пацієнтом	Вата стерильна	2	2	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-30 08:45:44.029883+00	\N	\N	f
694d9093-4e82-4546-9430-2afde9207b2e	4	Використано пацієнтом	Корвалол	13	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	1f2e36bb-b869-43c3-8993-c0ab8918a5ad	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-18 08:45:44.029951+00	\N	\N	f
6ae4a582-48fe-441a-b85b-f11c5fe19c94	4	Використано пацієнтом	Перекис водню 3%	2	1	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-26 08:45:44.029932+00	\N	\N	f
6e0d0c73-c8e7-4351-81c7-7909f170bedd	3	Виявлено протермінований препарат	Перекис водню 3%	67	1	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-31 08:45:44.029908+00	\N	\N	f
6f69e3d9-0096-4e92-8f35-88475ca995bc	5	Списано через закінчення терміну	Валідол	3	3	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-30 08:45:44.029814+00	\N	\N	f
6f823f34-a9bd-49bb-896d-c1fb0103b7ee	2	Коригування кількості	Диклофенак 50мг	1	3	2f24781b-5362-408d-8677-8bdd2751e5ec	2b04b4d7-2de1-4b02-8e0b-9ffd67d1d495	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-19 08:45:44.029902+00	\N	\N	f
6fca7c71-d782-4cda-86e6-55c85495cbf9	4	Використано пацієнтом	Розчин йоду 5%	10	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	1f2e36bb-b869-43c3-8993-c0ab8918a5ad	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-07 08:45:44.029946+00	\N	\N	f
71ab6d61-d2fe-45d6-8dc3-05ebde4490d6	3	Виявлено протермінований препарат	Хлоргексидин 0.05%	3	1	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-27 08:45:44.029901+00	\N	\N	f
72f32b4c-ee25-47f3-87f2-743d97838eeb	2	Коригування кількості	Бинт стерильний 5м×10см	5	0	2f24781b-5362-408d-8677-8bdd2751e5ec	2b04b4d7-2de1-4b02-8e0b-9ffd67d1d495	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-01 08:45:44.029903+00	\N	\N	f
76ed864c-eb68-4f46-a620-2afba39ee74c	2	Коригування кількості	Спирт етиловий 70%	92	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-18 08:45:44.029846+00	\N	\N	f
788fb3ea-b9ae-4f6d-9703-6eb13efc1ac5	1	Передано в інше відділення	Перекис водню 3%	100	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-24 08:45:44.029865+00	\N	\N	f
7a5d58af-430e-42be-987f-934deff6f5ec	1	Передано в інше відділення	Нітрогліцерин	5	3	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-13 08:45:44.029909+00	\N	\N	f
7c1ce9aa-6938-487d-82f5-cca1dfdba917	2	Коригування кількості	Дексаметазон 4мг	1	4	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-27 08:45:44.029934+00	\N	\N	f
7cad9fff-9990-49eb-a3dd-5c30c0fe4021	0	Поповнення запасів	Бісептол 480мг	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-05 08:45:44.029941+00	\N	\N	f
7d13f7e8-89ac-4575-ae92-b4930e3c0c91	3	Виявлено протермінований препарат	Магнію сульфат 25%	2	4	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-27 08:45:44.029839+00	\N	\N	f
7d93289f-11df-4bf5-b7fc-a30df844832a	1	Передано в інше відділення	Диклофенак 50мг	1	3	855c830b-fee4-4ff1-94a4-3d93122907fe	f18f48a0-76df-4e4e-b172-65aa694751f5	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-12 08:45:44.029917+00	\N	\N	f
7efccb50-25ae-4f1b-b22e-fb6e0680e2e9	0	Поповнення запасів	Лоратадин 10мг	3	3	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-08 08:45:44.029833+00	\N	\N	f
82fce434-2a63-41cb-87e9-8461660d511c	4	Використано пацієнтом	Корвалол	4	1	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-06 08:45:44.029893+00	\N	\N	f
84b8e522-6dec-45bf-b90e-aa0e703fb1a8	0	Поповнення запасів	Папаверин 2%	1	4	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-11 08:45:44.029926+00	\N	\N	f
8572f18e-a76e-4602-b67a-24f2fb822538	1	Передано в інше відділення	Шприц одноразовий 5мл	4	0	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-12 08:45:44.029938+00	\N	\N	f
85e3562f-37b0-4376-a8f7-c2bbcc15ef14	2	Коригування кількості	Дімедрол 1%	1	4	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-20 08:45:44.029908+00	\N	\N	f
864cfc98-db14-4697-b463-774a288e5b21	3	Виявлено протермінований препарат	Спирт етиловий 70%	92	1	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-29 08:45:44.029877+00	\N	\N	f
871fb9f9-8ea6-4458-8f02-13f3f772bada	3	Виявлено протермінований препарат	Дексаметазон 4мг	2	4	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:44.029935+00	\N	\N	f
886d8665-2426-4be4-952b-c47d009e5736	5	Списано через закінчення терміну	Магнію сульфат 25%	5	4	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-02 08:45:44.029895+00	\N	\N	f
89fdc700-6b77-4d44-97e8-64230c273dbc	4	Використано пацієнтом	Бісептол 480мг	1	3	c36d1c0c-34aa-4bcf-a542-15964da77279	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-15 08:45:44.029942+00	\N	\N	f
9272a529-b50d-430d-9847-af040fcb68b7	2	Коригування кількості	Шприц одноразовий 5мл	3	0	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-24 08:45:44.02984+00	\N	\N	f
98818a11-90af-42c4-9a6f-f6a7dc57c137	2	Коригування кількості	Диклофенак 50мг	6	3	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-01 08:45:44.029889+00	\N	\N	f
98b7753b-eda0-4c24-8123-a04260aa16c7	2	Коригування кількості	Маска медична	27	0	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-07 08:45:44.029816+00	\N	\N	f
9ad244bd-d708-41d7-b066-e37dc9226bba	5	Списано через закінчення терміну	Бинт марлевий (упаковка)	2	5	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-21 08:45:44.029907+00	\N	\N	f
a0f8e23e-9151-4772-86a7-911cf685b2b2	1	Передано в інше відділення	Анальгін 50% (амп.)	3	4	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-21 08:45:44.029887+00	\N	\N	f
a52dcee4-761e-4216-9e7f-19c3f80e7d52	2	Коригування кількості	Дексаметазон 4мг	3	4	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-02 08:45:44.029911+00	\N	\N	f
ac7ad8a5-0687-4e11-97bb-e7bf3f56bcca	3	Виявлено протермінований препарат	Розчин брильянтового зеленого	8	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-07 08:45:44.029866+00	\N	\N	f
ae522fef-a3f2-4485-b6eb-de4badf5a04f	5	Списано через закінчення терміну	Бинт стерильний 5м×10см	2	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-28 08:45:44.029886+00	\N	\N	f
ae7311d0-dd7a-4349-b202-62bbf22ed9bb	0	Поповнення запасів	Джгут гумовий	2	0	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-15 08:45:44.029895+00	\N	\N	f
b3a01959-54b1-4023-8951-774ad190e714	0	Поповнення запасів	Джгут гумовий	1	0	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-02 08:45:44.029924+00	\N	\N	f
b58b4dbf-e0f5-4968-a287-76ebf8f85e65	4	Використано пацієнтом	Розчин брильянтового зеленого	6	1	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-07 08:45:44.029925+00	\N	\N	f
b62410be-3f0a-418c-881e-af75937d65a1	1	Передано в інше відділення	Аспірин 500мг	4	3	2f24781b-5362-408d-8677-8bdd2751e5ec	2b04b4d7-2de1-4b02-8e0b-9ffd67d1d495	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-18 08:45:44.029903+00	\N	\N	f
b65c7012-2c75-44d9-8020-3e3c280e0df9	2	Коригування кількості	Но-шпа 40мг	3	3	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:44.029867+00	\N	\N	f
b845cbd2-c49e-48b8-bb26-6608abc03033	5	Списано через закінчення терміну	Розчин брильянтового зеленого	9	1	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-02 08:45:44.029869+00	\N	\N	f
bb78d670-3dfb-452c-b32f-a78176f6b422	0	Поповнення запасів	Супрастин 25мг	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-04 08:45:44.029892+00	\N	\N	f
bbf43389-f7bf-4f6a-8b55-87dc18a74ad8	2	Коригування кількості	Лоперамід	6	3	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-27 08:45:44.029936+00	\N	\N	f
be0f299d-8a72-4da4-95cb-e44ff2923f34	0	Поповнення запасів	Анальгін 500мг	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-27 08:45:44.029877+00	\N	\N	f
be7011c5-a049-492f-992a-c44072ab9bde	1	Передано в інше відділення	Лоперамід	4	3	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-14 08:45:44.02991+00	\N	\N	f
bf158017-0560-4c05-85f2-c0f97850517f	1	Передано в інше відділення	Хлоргексидин 0.05%	91	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-01 08:45:44.029849+00	\N	\N	f
c0a9acd8-b1b1-408b-a774-2d24db234361	1	Передано в інше відділення	Бинт марлевий (упаковка)	2	5	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-09 08:45:44.029847+00	\N	\N	f
c3b4535c-98ec-40ed-9691-ffb3861ad9e1	2	Коригування кількості	Хлоргексидин 0.05%	56	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-25 08:45:44.029865+00	\N	\N	f
c64a2b77-7229-43c7-9e4c-222afc0462b0	2	Коригування кількості	Анальгін 500мг	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-25 08:45:44.02989+00	\N	\N	f
c76ab9b4-2428-42eb-9f26-015242992d8a	2	Коригування кількості	Лейкопластир бактерицидний	3	0	855c830b-fee4-4ff1-94a4-3d93122907fe	f18f48a0-76df-4e4e-b172-65aa694751f5	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-23 08:45:44.029914+00	\N	\N	f
c8172645-354a-4a5c-8325-46e3707b22f6	4	Використано пацієнтом	Вата стерильна	27	2	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-29 08:45:44.029931+00	\N	\N	f
c890bfd0-6497-4dbd-acf5-5975b18e12cf	4	Використано пацієнтом	Бинт стерильний 5м×10см	2	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-11 08:45:44.029885+00	\N	\N	f
cc5e1d22-9f09-4fdf-afac-08aa070beef4	4	Використано пацієнтом	Корвалол	7	1	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-29 08:45:44.029927+00	\N	\N	f
cc6e7aa4-adf7-4870-93bc-5ea7f22b563d	2	Коригування кількості	Бісептол 480мг	4	3	c36d1c0c-34aa-4bcf-a542-15964da77279	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-17 08:45:44.029939+00	\N	\N	f
cda3eb65-bb32-4b2e-9d3c-e4a3376e46cd	2	Коригування кількості	Розчин йоду 5%	17	1	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-23 08:45:44.029918+00	\N	\N	f
d2a18537-7688-415c-812f-3b0dce49afd9	0	Поповнення запасів	Лоратадин 10мг	2	3	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-21 08:45:44.029928+00	\N	\N	f
d4131708-647d-4e55-bb7d-cfd0f83ef67b	1	Передано в інше відділення	Маска медична	18	0	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-26 08:45:44.029906+00	\N	\N	f
d444f324-dfdf-4ad6-813b-6c7171ec93a1	2	Коригування кількості	Цитрамон	3	3	e375ca95-635b-4ca3-b762-27a950bdd006	3b77085b-d895-4074-9e32-2022c609b673	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-23 08:45:44.029913+00	\N	\N	f
dba0b5c1-8ecf-4351-887e-6b829b879907	2	Коригування кількості	Лоперамід	3	3	afe653db-7e14-40c9-8758-0bf4babdf69e	916c26c8-d2e2-44f3-859d-1f65afbee01d	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-08 08:45:44.029892+00	\N	\N	f
dc6dc14c-81b3-4f24-9d52-2dd84251be86	5	Списано через закінчення терміну	Лейкопластир бактерицидний	4	0	2f24781b-5362-408d-8677-8bdd2751e5ec	2b04b4d7-2de1-4b02-8e0b-9ffd67d1d495	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-11 08:45:44.029905+00	\N	\N	f
dfb2ebbc-3797-49f4-9b57-106a1f16bc29	5	Списано через закінчення терміну	Атропін 0.1%	2	4	0944e862-db47-4840-ba45-fe2e8e8efd08	cb8b7040-9e8e-448c-86ee-f1a281daa951	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-02 08:45:44.029929+00	\N	\N	f
e0c09b2a-68c5-429d-8ebb-7d06c6785858	2	Коригування кількості	Папаверин 2%	1	4	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-23 08:45:44.029831+00	\N	\N	f
e16df19f-47c3-4bd9-80aa-bebe8b0afd66	1	Передано в інше відділення	Спирт етиловий 70%	5	1	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-23 08:45:44.029883+00	\N	\N	f
e1ed078f-e1f9-42bf-aeba-66617ca93211	4	Використано пацієнтом	Розчин брильянтового зеленого	3	1	855c830b-fee4-4ff1-94a4-3d93122907fe	f18f48a0-76df-4e4e-b172-65aa694751f5	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-04 08:45:44.029913+00	\N	\N	f
e1f1cfd5-fd5a-4973-8718-f7261565b2f4	0	Поповнення запасів	Шприц одноразовий 10мл	7	0	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-03 08:45:44.029937+00	\N	\N	f
e23725cf-b3d3-461c-85a9-b0f001cb9063	0	Поповнення запасів	Кеторолак 10мг	7	3	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-31 08:45:44.029844+00	\N	\N	f
e7bcb8fb-f5d1-48e6-b489-53bb16d14126	3	Виявлено протермінований препарат	Лоратадин 10мг	2	3	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-06 08:45:44.029843+00	\N	\N	f
e899def3-0612-493f-9145-b2723af7fe15	4	Використано пацієнтом	Парацетамол 500мг	6	3	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-09 08:45:44.029819+00	\N	\N	f
e95b1bad-f1b8-4657-9606-76d4c1c8a772	1	Передано в інше відділення	Перекис водню 3%	27	1	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-04 08:45:44.029934+00	\N	\N	f
ede1b700-6f8d-4b74-9a63-4aef59de35fe	4	Використано пацієнтом	Бинт еластичний	2	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	f704683c-26b2-4f67-acd3-5d3b793899ec	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-10 08:45:44.029884+00	\N	\N	f
edf486ee-2ab6-4721-98de-80196343c656	0	Поповнення запасів	Аспірин 500мг	5	3	c36d1c0c-34aa-4bcf-a542-15964da77279	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-26 08:45:44.02994+00	\N	\N	f
ef40314f-fa60-41d9-9f96-713617c05237	0	Поповнення запасів	Вата стерильна	35	2	2e53fef1-346d-4743-a751-fc71275d8c0c	d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-11 08:45:44.029933+00	\N	\N	f
f00b3ef2-4827-489b-92ad-8bd6f0be2173	4	Використано пацієнтом	Бісептол 480мг	4	3	3022448e-a09d-4689-8d1d-a4594b5d9102	70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-21 08:45:44.029878+00	\N	\N	f
f1096219-8a5c-4c89-b9c0-b9025c630cf2	3	Виявлено протермінований препарат	Диклофенак 50мг	1	3	2f24781b-5362-408d-8677-8bdd2751e5ec	2b04b4d7-2de1-4b02-8e0b-9ffd67d1d495	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-21 08:45:44.029904+00	\N	\N	f
f588ff90-0825-4d11-8bae-a0ef56c122af	2	Коригування кількості	Розчин брильянтового зеленого	8	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	1f2e36bb-b869-43c3-8993-c0ab8918a5ad	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-05 08:45:44.029953+00	\N	\N	f
f8560ae8-ab9c-418f-a503-116cd4bd0205	0	Поповнення запасів	Лейкопластир бактерицидний	3	0	2f24781b-5362-408d-8677-8bdd2751e5ec	2b04b4d7-2de1-4b02-8e0b-9ffd67d1d495	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-02-18 08:45:44.029905+00	\N	\N	f
fcd7de4b-cc92-45dc-aa32-e6c96e8b541a	0	Поповнення запасів	Серветки спиртові	2	5	d7b3f772-167e-4f25-9a85-310e632a4abc	40dd8bc1-9306-4823-b993-49ac350a806b	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-28 08:45:44.029838+00	\N	\N	f
fe9ea1f4-e6a9-4df7-baec-943c5a86239a	4	Використано пацієнтом	Розчин брильянтового зеленого	5	1	c36d1c0c-34aa-4bcf-a542-15964da77279	44587e9f-888b-4319-9dc5-c08d249d7cbe	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-03-16 08:45:44.029943+00	\N	\N	f
fef67e68-fe09-4ae1-85e8-2bf7429477d7	0	Поповнення запасів	Розчин брильянтового зеленого	8	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	28b2ef4b-569e-4925-bd00-8006dd4c5ffd	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-01-26 08:45:44.029845+00	\N	\N	f
07f3e242-e2b8-45e2-9d2e-2d086fae154b	1	Передано в інше відділення	Но-шпа 40мг	1	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-02 08:45:44.769434+00	\N	\N	f
09b38682-6422-4689-bbe7-2903a199e12c	4	Використано пацієнтом	Амоксицилін 500мг	1	3	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-10 08:45:44.769407+00	\N	\N	f
0a05f449-c10d-4b3d-8bb6-522495dfe1da	1	Передано в інше відділення	Магнію сульфат 25%	1	4	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-19 08:45:44.769404+00	\N	\N	f
0a6101af-024f-4ffd-9d65-770d0871eb2e	1	Передано в інше відділення	Амоксицилін 500мг	3	3	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-01 08:45:44.769415+00	\N	\N	f
1059ae9a-fb2a-48d6-bf23-c9b820a3f5ca	5	Списано через закінчення терміну	Ібупрофен 200мг	9	3	75760860-1113-46d6-9cfb-9d6b14667b38	112ffb29-b1d0-4a55-b239-b84f5639842a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-17 08:45:44.769425+00	\N	\N	f
125cb5d0-e594-4c2b-a61f-2c77970e0759	0	Поповнення запасів	Бинт еластичний	1	0	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-10 08:45:44.76939+00	\N	\N	f
12806d15-d9a5-4027-a712-4a4ee001ddb9	4	Використано пацієнтом	Цитрамон	11	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-22 08:45:44.769435+00	\N	\N	f
16c5013a-cf1f-4d34-b50a-95f2f00ba3d6	3	Виявлено протермінований препарат	Валідол	1	3	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-09 08:45:44.769413+00	\N	\N	f
1a2b2be4-5102-48da-8ba7-9a9a5e87621e	0	Поповнення запасів	Но-шпа 40мг	7	3	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-01 08:45:44.769392+00	\N	\N	f
1a8074d3-1cd7-4db2-89e9-9bd557652f84	3	Виявлено протермінований препарат	Парацетамол 500мг	12	3	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-01 08:45:44.769405+00	\N	\N	f
1d96262b-12ca-4b90-854a-36bfed77d907	2	Коригування кількості	Лоперамід	3	3	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-25 08:45:44.769397+00	\N	\N	f
1e2ba1d5-4766-45c1-92fc-e67eb1247244	1	Передано в інше відділення	Лоперамід	2	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-22 08:45:44.769374+00	\N	\N	f
20bb627b-ecb0-49a7-a569-1934a297f24f	3	Виявлено протермінований препарат	Преднізолон 30мг	2	4	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-08 08:45:44.769416+00	\N	\N	f
21d95825-b198-4c2b-90db-6b206b958ca3	4	Використано пацієнтом	Активоване вугілля	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-01 08:45:44.7694+00	\N	\N	f
283a7f26-74b8-48ca-9b3f-27550064a277	0	Поповнення запасів	Шприц одноразовий 10мл	3	0	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-10 08:45:44.769406+00	\N	\N	f
291718da-63bd-4a98-9a9d-2e7422a3d0f1	0	Поповнення запасів	Спирт етиловий 70%	22	1	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-03 08:45:44.769403+00	\N	\N	f
29c5e678-2a0e-4294-ac68-52667f842329	0	Поповнення запасів	Вата стерильна	16	2	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-13 08:45:44.769436+00	\N	\N	f
2e584aab-e90d-4c13-b96b-245bd57ce469	3	Виявлено протермінований препарат	Маска медична	4	0	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-12 08:45:44.769388+00	\N	\N	f
2f24e9f2-474f-491a-91ca-686a246ebbc9	2	Коригування кількості	Магнію сульфат 25%	2	4	9e8f24cc-3649-4841-9f10-72ed2d5d780b	68202c68-294e-4a04-b5c6-af07caccaad8	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-25 08:45:44.769431+00	\N	\N	f
32db9f4c-9045-48f7-9b02-fffe8f9c912f	4	Використано пацієнтом	Бісептол 480мг	2	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-22 08:45:44.76937+00	\N	\N	f
396bf90e-fa51-4685-99c8-d9a8057d1d32	5	Списано через закінчення терміну	Перекис водню 3%	87	1	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-19 08:45:44.76941+00	\N	\N	f
3e47097d-ce8f-4f68-8b3c-76b5fd63625e	3	Виявлено протермінований препарат	Парацетамол 500мг	1	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-22 08:45:44.769377+00	\N	\N	f
44653849-38ad-49ff-9e43-1cfc9eb0041c	1	Передано в інше відділення	Диклофенак 50мг	2	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-15 08:45:44.769435+00	\N	\N	f
44eba621-e72c-4ce4-86fa-dbd225574c3b	0	Поповнення запасів	Преднізолон 30мг	2	4	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-17 08:45:44.769381+00	\N	\N	f
4aed5a1e-ced9-4fcc-b74e-057bd10f9bf4	4	Використано пацієнтом	Но-шпа 40мг	6	3	f79c547f-cee7-466a-86e5-4618a86adbd3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-06 08:45:44.769424+00	\N	\N	f
4d541703-81ee-43ba-9bf3-1d131d1a9bb3	1	Передано в інше відділення	Перекис водню 3%	29	1	75760860-1113-46d6-9cfb-9d6b14667b38	112ffb29-b1d0-4a55-b239-b84f5639842a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-14 08:45:44.769427+00	\N	\N	f
4da832c8-2ab3-4920-ada3-4b92adf78e5d	0	Поповнення запасів	Бинт еластичний	2	0	9bdb768a-f4cd-4362-b8fb-bc29f727af93	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-15 08:45:44.769378+00	\N	\N	f
4f8db9d5-e657-4f4b-9938-3609247b0c14	4	Використано пацієнтом	Перекис водню 3%	58	1	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-11 08:45:44.769383+00	\N	\N	f
53fc5fe9-25e7-43ea-9f66-c408d20f4e08	2	Коригування кількості	Шприц одноразовий 10мл	1	0	f79c547f-cee7-466a-86e5-4618a86adbd3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-26 08:45:44.76942+00	\N	\N	f
56712948-1a78-405c-8827-0aaca6dc4095	0	Поповнення запасів	Анальгін 50% (амп.)	3	4	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-31 08:45:44.769408+00	\N	\N	f
58cf111d-11fa-41cf-9701-48baf7734f78	5	Списано через закінчення терміну	Валідол	6	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-29 08:45:44.769376+00	\N	\N	f
601e8ae8-82b6-49d6-ba7b-aff15dc68782	5	Списано через закінчення терміну	Амоксицилін 500мг	1	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-27 08:45:44.769372+00	\N	\N	f
617afc76-6b92-4100-a598-62eaa602577f	4	Використано пацієнтом	Корвалол	4	1	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-23 08:45:44.769389+00	\N	\N	f
6542951b-7237-4a24-a071-7cf35b47b72f	4	Використано пацієнтом	Бинт еластичний	1	0	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-17 08:45:44.769391+00	\N	\N	f
6a6d1a52-aa75-43ca-b0fc-7822913a7faf	5	Списано через закінчення терміну	Фізіологічний розчин 0.9%	4	1	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-06 08:45:44.769406+00	\N	\N	f
6c56ffcc-dcff-4968-a9cb-877693d1adb5	5	Списано через закінчення терміну	Шприц одноразовий 5мл	4	0	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-21 08:45:44.769371+00	\N	\N	f
6dc577f6-89b0-4484-b100-e605fbca4a7e	3	Виявлено протермінований препарат	Бинт марлевий (упаковка)	1	5	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-01 08:45:44.769411+00	\N	\N	f
6e6c27fb-089a-45da-8415-32f7d78d4cc0	3	Виявлено протермінований препарат	Бинт еластичний	2	0	75760860-1113-46d6-9cfb-9d6b14667b38	112ffb29-b1d0-4a55-b239-b84f5639842a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-27 08:45:44.769424+00	\N	\N	f
70bd1cc2-a305-41f9-9a7c-412af78d4b2f	4	Використано пацієнтом	Перекис водню 3%	2	1	75760860-1113-46d6-9cfb-9d6b14667b38	112ffb29-b1d0-4a55-b239-b84f5639842a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-14 08:45:44.769427+00	\N	\N	f
716599e4-0518-43aa-9e21-756505f571ab	1	Передано в інше відділення	Но-шпа 40мг	3	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-16 08:45:44.769434+00	\N	\N	f
746a8e81-3644-4ae0-844a-fd970ba58ae7	5	Списано через закінчення терміну	Адреналін 0.1%	1	4	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-15 08:45:44.769408+00	\N	\N	f
7a3f1c1e-ba8a-43d8-a4d8-15b436ff4fc0	4	Використано пацієнтом	Бинт еластичний	1	0	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-15 08:45:44.769397+00	\N	\N	f
7a4fbc7a-01f5-4368-ab20-f6294fada89b	4	Використано пацієнтом	Аспірин 500мг	1	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-06 08:45:44.76937+00	\N	\N	f
8005f1a2-8850-463b-a01a-6e377bc830fd	3	Виявлено протермінований препарат	Корвалол	6	1	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-11 08:45:44.76939+00	\N	\N	f
81c0dfed-1f20-4d4e-9561-045b3d234412	2	Коригування кількості	Парацетамол 500мг	3	3	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-28 08:45:44.769411+00	\N	\N	f
82f73f3f-4566-4b5a-b38a-54919a3cbd10	1	Передано в інше відділення	Нітрогліцерин	3	3	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-22 08:45:44.769384+00	\N	\N	f
87ae6d2f-954d-41ce-858c-d14f404a70b5	3	Виявлено протермінований препарат	Лоперамід	1	3	f79c547f-cee7-466a-86e5-4618a86adbd3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-18 08:45:44.769422+00	\N	\N	f
893a0d32-f3f7-47f5-8e69-41e9bd1c55a3	1	Передано в інше відділення	Розчин брильянтового зеленого	17	1	9e8f24cc-3649-4841-9f10-72ed2d5d780b	68202c68-294e-4a04-b5c6-af07caccaad8	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-24 08:45:44.769429+00	\N	\N	f
8a5ddf24-dca6-437b-aa29-cc17a80e604f	1	Передано в інше відділення	Бинт еластичний	2	0	75760860-1113-46d6-9cfb-9d6b14667b38	112ffb29-b1d0-4a55-b239-b84f5639842a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-08 08:45:44.769426+00	\N	\N	f
8bc3582f-5fef-484f-a40b-59f67f58f8dd	2	Коригування кількості	Лоперамід	2	3	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-16 08:45:44.769381+00	\N	\N	f
8cbe7a1d-02c8-47a0-a440-4db9c23120bd	2	Коригування кількості	Серветки спиртові	2	5	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-09 08:45:44.769373+00	\N	\N	f
8e156453-a216-4292-854d-8c62f29c5c06	4	Використано пацієнтом	Марля медична	91	2	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-20 08:45:44.769419+00	\N	\N	f
8edf5cb2-ea5c-4960-9c58-469bc6a55f5b	5	Списано через закінчення терміну	Маска медична	6	0	f79c547f-cee7-466a-86e5-4618a86adbd3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-25 08:45:44.769423+00	\N	\N	f
916761f1-e29c-4996-9b37-01e3c2739569	2	Коригування кількості	Джгут гумовий	2	0	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-21 08:45:44.769372+00	\N	\N	f
929994b0-358b-422c-8a74-9f24cde08f14	1	Передано в інше відділення	Лоперамід	1	3	f79c547f-cee7-466a-86e5-4618a86adbd3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-15 08:45:44.769421+00	\N	\N	f
92f4458d-f9de-465d-b127-4b1ca43586c6	0	Поповнення запасів	Парацетамол 500мг	8	3	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-14 08:45:44.769409+00	\N	\N	f
93055daa-0365-4064-924d-b883dbcfa7a4	1	Передано в інше відділення	Атропін 0.1%	1	4	75760860-1113-46d6-9cfb-9d6b14667b38	112ffb29-b1d0-4a55-b239-b84f5639842a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-12 08:45:44.769426+00	\N	\N	f
95f902e7-5ef7-41b5-bc07-89b7a5ddc83a	4	Використано пацієнтом	Маска медична	30	0	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-11 08:45:44.769418+00	\N	\N	f
96257904-85f3-4c2f-8536-974c67ebc0e7	0	Поповнення запасів	Лоратадин 10мг	3	3	9e8f24cc-3649-4841-9f10-72ed2d5d780b	68202c68-294e-4a04-b5c6-af07caccaad8	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-14 08:45:44.769432+00	\N	\N	f
96b41bca-effb-4b0a-84cd-68f3388c781e	1	Передано в інше відділення	Маска медична	18	0	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-12 08:45:44.769416+00	\N	\N	f
9bcd6ed4-5a10-4b3b-bb92-2729e8ee26a4	2	Коригування кількості	Преднізолон 30мг	2	4	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-01 08:45:44.769398+00	\N	\N	f
a4048e8e-1b04-4b0d-9257-a06c5d2635b5	5	Списано через закінчення терміну	Нітрогліцерин	4	3	9e8f24cc-3649-4841-9f10-72ed2d5d780b	68202c68-294e-4a04-b5c6-af07caccaad8	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-24 08:45:44.76943+00	\N	\N	f
a4f1aacf-922a-440e-980b-3baf142c2c6a	4	Використано пацієнтом	Но-шпа 40мг	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-09 08:45:44.769404+00	\N	\N	f
a7bfe46c-d3ea-4a43-9a7f-2d353b282088	2	Коригування кількості	Бинт марлевий (упаковка)	2	5	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-19 08:45:44.769414+00	\N	\N	f
a801b973-8c6b-4638-a078-c84e9380e91b	4	Використано пацієнтом	Преднізолон 30мг	2	4	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-10 08:45:44.769409+00	\N	\N	f
a8251a65-0ebc-4718-8f08-93c2c85e7aae	5	Списано через закінчення терміну	Джгут гумовий	2	0	9e8f24cc-3649-4841-9f10-72ed2d5d780b	68202c68-294e-4a04-b5c6-af07caccaad8	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-25 08:45:44.769431+00	\N	\N	f
aac412de-2d89-4ce9-97c8-6ee7707f3728	1	Передано в інше відділення	Спирт етиловий 70%	81	1	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-16 08:45:44.769402+00	\N	\N	f
ac5a7826-7232-4b93-b763-d5d2b33c9329	1	Передано в інше відділення	Лоратадин 10мг	2	3	9e8f24cc-3649-4841-9f10-72ed2d5d780b	68202c68-294e-4a04-b5c6-af07caccaad8	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-20 08:45:44.769429+00	\N	\N	f
af1651ed-40b8-4f9d-b2ce-9afc246ba7a0	2	Коригування кількості	Бісептол 480мг	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-08 08:45:44.769405+00	\N	\N	f
af7303ce-e16c-4716-8bd9-a5d95db5ebf8	4	Використано пацієнтом	Магнію сульфат 25%	2	4	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-27 08:45:44.769401+00	\N	\N	f
b2fcc8e8-e943-4e5e-8b68-d0beeb2cf387	0	Поповнення запасів	Парацетамол 500мг	15	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-27 08:45:44.769436+00	\N	\N	f
b41f1ae5-1a39-4925-9e16-67a1cd864f11	2	Коригування кількості	Шприц одноразовий 5мл	7	0	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-29 08:45:44.769432+00	\N	\N	f
b9345ec2-6026-4e16-b7e7-0e0afda2b814	1	Передано в інше відділення	Бісептол 480мг	3	3	9e8f24cc-3649-4841-9f10-72ed2d5d780b	68202c68-294e-4a04-b5c6-af07caccaad8	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-18 08:45:44.76943+00	\N	\N	f
b9ebf943-dc80-4516-8835-cae64dfe419c	0	Поповнення запасів	Перекис водню 3%	13	1	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-19 08:45:44.7694+00	\N	\N	f
ba4569f9-7d30-4887-81a0-da4b30e56bd7	4	Використано пацієнтом	Аспірин 500мг	1	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-04 08:45:44.769373+00	\N	\N	f
bc84d57a-11d3-4a4e-bbbb-b67828a876f7	2	Коригування кількості	Парацетамол 500мг	4	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-03 08:45:44.769438+00	\N	\N	f
c13a8220-1565-40b9-ba58-b36678d6eda3	1	Передано в інше відділення	Анальгін 50% (амп.)	1	4	f79c547f-cee7-466a-86e5-4618a86adbd3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-02 08:45:44.769421+00	\N	\N	f
c1fdffeb-b326-4960-b0f3-d963dec7327d	1	Передано в інше відділення	Дімедрол 1%	1	4	f79c547f-cee7-466a-86e5-4618a86adbd3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-29 08:45:44.76942+00	\N	\N	f
c9e422bf-77b7-4819-90a9-2af4fa34ecd9	5	Списано через закінчення терміну	Вата стерильна	1	2	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-17 08:45:44.769369+00	\N	\N	f
ccf001a1-7979-46bb-b1b1-67fda86c276f	3	Виявлено протермінований препарат	Но-шпа 40мг	9	3	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-23 08:45:44.769383+00	\N	\N	f
d0bb7b6b-8b86-4e24-a48f-8e561b05cd82	1	Передано в інше відділення	Серветки спиртові	2	5	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-21 08:45:44.769415+00	\N	\N	f
d24b819b-5841-4776-8d04-ce3c0dc2bbfa	2	Коригування кількості	Валідол	3	3	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-21 08:45:44.769414+00	\N	\N	f
d44493a1-a140-4875-b893-baf7d342009f	1	Передано в інше відділення	Розчин брильянтового зеленого	11	1	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-09 08:45:44.769413+00	\N	\N	f
d4b2afb6-f41b-4285-b945-c276cc44d5e6	3	Виявлено протермінований препарат	Маска медична	27	0	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-02 08:45:44.769437+00	\N	\N	f
d55faeab-0f45-44e5-a73c-1f5a0cea634b	0	Поповнення запасів	Валідол	4	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-09 08:45:44.76938+00	\N	\N	f
d6187763-993e-44f9-b846-d39c51ff29a0	4	Використано пацієнтом	Дімедрол 1%	1	4	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-16 08:45:44.769402+00	\N	\N	f
d9c815fb-41b2-4532-9eb7-52a24dee7f00	3	Виявлено протермінований препарат	Розчин йоду 5%	2	1	521dd62d-9375-4440-9001-828eb746a50a	84321877-7731-4a53-8eb0-43e62cba6d22	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-27 08:45:44.769412+00	\N	\N	f
dd54aa12-75b5-49df-9552-f55c949b2dbe	2	Коригування кількості	Серветки спиртові	1	5	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-04 08:45:44.769419+00	\N	\N	f
e0bf7a7e-4bbf-4c45-8e5c-3da87a5501d9	2	Коригування кількості	Шприц одноразовий 10мл	7	0	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-01 08:45:44.769437+00	\N	\N	f
e15cb153-4aaa-4546-8c52-88f8c719d730	0	Поповнення запасів	Супрастин 25мг	6	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	9c5d76b1-4179-48e5-9222-ef71e2e981fb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-02 08:45:44.769367+00	\N	\N	f
e4a1516f-4c92-4bd6-9547-05cfe18c8977	5	Списано через закінчення терміну	Аспірин 500мг	3	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-20 08:45:44.769379+00	\N	\N	f
e7b6a0a8-f528-4016-a107-8ad00d08d77a	4	Використано пацієнтом	Марля медична	113	2	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-27 08:45:44.769418+00	\N	\N	f
ecf2094f-7dc4-4118-8580-27627c55a2f4	3	Виявлено протермінований препарат	Шприц одноразовий 10мл	3	0	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-21 08:45:44.769399+00	\N	\N	f
ed52fa07-b80f-4ce0-b51c-99deabb5413c	2	Коригування кількості	Рукавички медичні	6	0	9bdb768a-f4cd-4362-b8fb-bc29f727af93	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-05 08:45:44.76938+00	\N	\N	f
f08a6d31-9bb4-4734-bad2-0990ac337449	0	Поповнення запасів	Вата стерильна	43	2	7e435359-29d6-4eb2-8bb5-23362118973f	6e81ae0f-1cff-4006-a4b2-1313f573d224	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-01 08:45:44.769398+00	\N	\N	f
f0a3fc15-3ccd-434a-a0eb-6d03c74ca4cc	1	Передано в інше відділення	Марля медична	20	2	f79c547f-cee7-466a-86e5-4618a86adbd3	f56fe224-1c44-4692-865d-be39ff1c4041	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-17 08:45:44.769422+00	\N	\N	f
f636f697-2f55-44d7-8f44-1d5bfdad422b	1	Передано в інше відділення	Марля медична	99	2	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-16 08:45:44.769417+00	\N	\N	f
fb501f0f-0244-4f64-8a48-0c4eb99d5fab	3	Виявлено протермінований препарат	Амоксицилін 500мг	6	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	f535a0c6-8624-4bf3-bd86-9d18f6aae388	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-03-26 08:45:44.769433+00	\N	\N	f
fbf1d7f7-d46a-4d9d-b2be-cd904f587d21	0	Поповнення запасів	Спирт етиловий 70%	21	1	75760860-1113-46d6-9cfb-9d6b14667b38	112ffb29-b1d0-4a55-b239-b84f5639842a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-21 08:45:44.769428+00	\N	\N	f
fd2a0bf1-da66-4b39-b098-70379d032e5e	0	Поповнення запасів	Бісептол 480мг	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	0b1a46c4-9749-40f7-a98e-9a677ae01a8c	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-08 08:45:44.769401+00	\N	\N	f
fd5143cc-33dd-4769-99b9-12116df27870	3	Виявлено протермінований препарат	Лоратадин 10мг	3	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-02-10 08:45:44.769375+00	\N	\N	f
fdd0c0ba-aae9-4de5-b9eb-177b6b99e775	0	Поповнення запасів	Валідол	5	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	13c10326-88f8-4262-ae80-1b46898055dd	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-01-14 08:45:44.769377+00	\N	\N	f
053745a0-08c0-4fd2-893a-2eb611477829	4	Використано пацієнтом	Анальгін 50% (амп.)	1	4	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	d830c597-a126-4420-9735-2bc6e0c1ed84	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-11 08:45:45.457167+00	\N	\N	f
0849b7a3-44ee-48dd-9955-d3f8c9b9cde9	5	Списано через закінчення терміну	Бісептол 480мг	7	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-15 08:45:45.4572+00	\N	\N	f
12e02bdd-d831-4836-818d-4f51bfd0cfb0	2	Коригування кількості	Адреналін 0.1%	1	4	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-27 08:45:45.457148+00	\N	\N	f
131bc784-f02b-42d6-a929-b759585e15b1	3	Виявлено протермінований препарат	Бинт марлевий (упаковка)	1	5	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-04 08:45:45.457193+00	\N	\N	f
18c8c425-924c-43a9-a569-c2b6fcdc0eaf	3	Виявлено протермінований препарат	Бинт марлевий (упаковка)	1	5	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-23 08:45:45.457146+00	\N	\N	f
1dd9608a-841d-45bb-a07a-4da3801a9640	4	Використано пацієнтом	Бинт марлевий (упаковка)	2	5	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-21 08:45:45.457144+00	\N	\N	f
1e1aa052-52e5-401a-a813-9a7436125527	5	Списано через закінчення терміну	Марля медична	2	2	618a3475-904f-466b-a192-52be990ea7fe	f180ad63-2730-43fc-83da-54fa3c9da5a4	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-20 08:45:45.457161+00	\N	\N	f
22a0ddff-f5d9-4b76-93c6-87b250846931	3	Виявлено протермінований препарат	Перекис водню 3%	88	1	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-31 08:45:45.457154+00	\N	\N	f
25f06a23-870d-4797-aa48-4b25afc58492	2	Коригування кількості	Цитрамон	6	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	8a7df9ad-f99a-4687-83b1-a974c72d0657	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-04 08:45:45.457188+00	\N	\N	f
26870c7b-3af4-47c0-aa2d-f701b4872c45	4	Використано пацієнтом	Корвалол	5	1	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-16 08:45:45.457183+00	\N	\N	f
26d121b5-61d8-40e4-a2cc-428ca7edf6ad	1	Передано в інше відділення	Валідол	5	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-26 08:45:45.457202+00	\N	\N	f
287f8234-a4ff-44fe-a447-2b5f9fa5e046	5	Списано через закінчення терміну	Корвалол	5	1	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-11 08:45:45.457185+00	\N	\N	f
2b1ffced-4c7e-4c63-bacf-0d43ee8651e6	4	Використано пацієнтом	Дексаметазон 4мг	4	4	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	d830c597-a126-4420-9735-2bc6e0c1ed84	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-14 08:45:45.457165+00	\N	\N	f
302948b5-b2ca-4734-b69d-75b15de3dccd	1	Передано в інше відділення	Бинт еластичний	2	0	618a3475-904f-466b-a192-52be990ea7fe	f180ad63-2730-43fc-83da-54fa3c9da5a4	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-03 08:45:45.457162+00	\N	\N	f
32b3496a-178d-495c-94bf-b8106f042b34	1	Передано в інше відділення	Хлоргексидин 0.05%	96	1	e666c0dc-34e4-41a4-884c-5c4d7a98caed	51953ce5-3663-4f9e-a117-4c5b99a6fbd7	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-29 08:45:45.45717+00	\N	\N	f
35293d57-5eed-43fa-ab58-a005adbfff76	3	Виявлено протермінований препарат	Преднізолон 30мг	2	4	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-21 08:45:45.457181+00	\N	\N	f
3699ae75-5a65-4292-b19b-868d63a6d16d	3	Виявлено протермінований препарат	Джгут гумовий	2	0	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-25 08:45:45.457174+00	\N	\N	f
37434cb8-320a-4f1b-9c25-d7cbd40cd6df	2	Коригування кількості	Парацетамол 500мг	10	3	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-10 08:45:45.457179+00	\N	\N	f
3f30f207-e468-436a-bc73-01e7b36a8985	4	Використано пацієнтом	Активоване вугілля	7	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	d830c597-a126-4420-9735-2bc6e0c1ed84	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-13 08:45:45.457168+00	\N	\N	f
40c4db31-542c-42cb-98a6-456ae9cbe762	2	Коригування кількості	Марля медична	24	2	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-19 08:45:45.457152+00	\N	\N	f
424fd3f4-cd61-4c70-9d88-7ce04c0712bd	1	Передано в інше відділення	Бісептол 480мг	3	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-14 08:45:45.4572+00	\N	\N	f
42a115e8-9533-4329-af45-7c0b1f4861ec	0	Поповнення запасів	Анальгін 500мг	4	3	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-19 08:45:45.457183+00	\N	\N	f
4c97659f-41c7-4f50-8d4b-e41361099b44	2	Коригування кількості	Маска медична	17	0	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-22 08:45:45.457151+00	\N	\N	f
502b8f7f-0cd1-4fd0-9908-d6c079d5174e	3	Виявлено протермінований препарат	Серветки спиртові	2	5	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-09 08:45:45.457196+00	\N	\N	f
56f92394-6892-4b82-a346-84328bf42e1c	0	Поповнення запасів	Парацетамол 500мг	4	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-26 08:45:45.457198+00	\N	\N	f
5a2956fa-bc7e-417c-83f7-7baf7a20614c	4	Використано пацієнтом	Вата стерильна	26	2	44457538-eed8-40d0-9186-dca9e4ed9f9f	b7772c6a-cce9-4b4d-8b26-53f4dae7375e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-27 08:45:45.45714+00	\N	\N	f
5b673f5f-c3a9-42f6-9667-098e7555dad1	4	Використано пацієнтом	Парацетамол 500мг	4	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	d830c597-a126-4420-9735-2bc6e0c1ed84	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-20 08:45:45.457167+00	\N	\N	f
5b69328d-39d2-4a63-b046-ea31fb30aec9	2	Коригування кількості	Бинт марлевий (упаковка)	2	5	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-10 08:45:45.457192+00	\N	\N	f
5bbad477-23f4-45eb-bc5d-263a3ee663ec	2	Коригування кількості	Анальгін 50% (амп.)	1	4	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-08 08:45:45.457147+00	\N	\N	f
5d8db2e6-bc97-49df-a7cc-a86e2bd2eb9f	4	Використано пацієнтом	Розчин брильянтового зеленого	9	1	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-05 08:45:45.457192+00	\N	\N	f
68b70e28-bce2-4cf8-9e00-edc64a87a50d	4	Використано пацієнтом	Перекис водню 3%	26	1	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	8a7df9ad-f99a-4687-83b1-a974c72d0657	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-05 08:45:45.457189+00	\N	\N	f
6aad7959-dd1e-4d17-8030-742624461963	5	Списано через закінчення терміну	Супрастин 25мг	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-25 08:45:45.457203+00	\N	\N	f
6d79e511-9eab-4529-a167-d504bd98147a	0	Поповнення запасів	Фізіологічний розчин 0.9%	17	1	f1d00635-0565-4eaf-b4cf-228beb6a8dca	30110403-4d1a-44f8-8cd9-04d92f5663c8	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-09 08:45:45.457174+00	\N	\N	f
6d8018d1-b9ee-4031-a49c-978bcbbe8485	3	Виявлено протермінований препарат	Рукавички медичні	10	0	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-22 08:45:45.457149+00	\N	\N	f
7075af4e-3a62-4e14-8b42-695b38db4c94	4	Використано пацієнтом	Аспірин 500мг	1	3	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-21 08:45:45.457152+00	\N	\N	f
70abe9ae-e982-4983-acb0-f85d28d8ba14	4	Використано пацієнтом	Парацетамол 500мг	3	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	d830c597-a126-4420-9735-2bc6e0c1ed84	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-02 08:45:45.457167+00	\N	\N	f
745f5d5c-af8b-4aeb-b124-a40c645490af	0	Поповнення запасів	Амоксицилін 500мг	1	3	e666c0dc-34e4-41a4-884c-5c4d7a98caed	51953ce5-3663-4f9e-a117-4c5b99a6fbd7	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-20 08:45:45.457169+00	\N	\N	f
74b4d05a-0505-44f4-8257-8b43a06bf3c9	3	Виявлено протермінований препарат	Рукавички медичні	15	0	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-09 08:45:45.457145+00	\N	\N	f
78a0ce32-9033-4caf-98a7-e668e5f6d656	5	Списано через закінчення терміну	Розчин йоду 5%	11	1	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-27 08:45:45.45718+00	\N	\N	f
79ea11af-6313-4a0e-9baa-1bd6af078e9d	2	Коригування кількості	Анальгін 50% (амп.)	4	4	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-28 08:45:45.45715+00	\N	\N	f
7c6e4ef9-1d54-49e4-82b6-bd7315a7da1f	4	Використано пацієнтом	Диклофенак 50мг	3	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-13 08:45:45.457195+00	\N	\N	f
7d2b76c9-e112-43bd-b1e4-9c0b7abab5d0	4	Використано пацієнтом	Диклофенак 50мг	2	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-21 08:45:45.457196+00	\N	\N	f
7dbb5f02-526f-4bee-a633-53e17d32df4c	1	Передано в інше відділення	Анальгін 50% (амп.)	3	4	e666c0dc-34e4-41a4-884c-5c4d7a98caed	51953ce5-3663-4f9e-a117-4c5b99a6fbd7	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-16 08:45:45.457169+00	\N	\N	f
7e232f00-d6d2-42d0-8d0c-ab65ddd657fd	4	Використано пацієнтом	Нітрогліцерин	1	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-13 08:45:45.457201+00	\N	\N	f
7e9c8a4a-3da1-4b78-8af1-f14e5dbcf141	1	Передано в інше відділення	Амоксицилін 500мг	7	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-29 08:45:45.457143+00	\N	\N	f
7ff9effc-d59b-4539-a88e-b583762d7ff7	2	Коригування кількості	Хлоргексидин 0.05%	66	1	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-16 08:45:45.457148+00	\N	\N	f
80a44b52-1398-494e-94b4-6684b5023a69	2	Коригування кількості	Бинт стерильний 5м×10см	2	0	f1d00635-0565-4eaf-b4cf-228beb6a8dca	30110403-4d1a-44f8-8cd9-04d92f5663c8	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-30 08:45:45.457173+00	\N	\N	f
80dd1a84-2a52-482c-92d2-933a70acd7f1	3	Виявлено протермінований препарат	Спирт етиловий 70%	34	1	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-23 08:45:45.457178+00	\N	\N	f
80f460c0-944c-4b39-9b78-e1e1af284c17	0	Поповнення запасів	Валідол	1	3	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-06 08:45:45.457184+00	\N	\N	f
82d9fa1f-6b3c-4796-9691-8eaaed809425	0	Поповнення запасів	Амоксицилін 500мг	7	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	30110403-4d1a-44f8-8cd9-04d92f5663c8	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-24 08:45:45.457171+00	\N	\N	f
83746322-f3e7-4637-aca3-cafd5f0524ea	1	Передано в інше відділення	Диклофенак 50мг	1	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.457194+00	\N	\N	f
85e98e7c-07d8-42c9-9a7e-295ff28fc8c4	2	Коригування кількості	Валідол	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-02 08:45:45.457203+00	\N	\N	f
86019d14-cb9b-4141-8626-da47f0af74a6	3	Виявлено протермінований препарат	Серветки спиртові	2	5	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-19 08:45:45.457176+00	\N	\N	f
862948e3-06c1-4e83-9881-381da33babb2	3	Виявлено протермінований препарат	Атропін 0.1%	3	4	44457538-eed8-40d0-9186-dca9e4ed9f9f	b7772c6a-cce9-4b4d-8b26-53f4dae7375e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-13 08:45:45.457139+00	\N	\N	f
86e6d9bc-9cf7-4b5d-8d0c-50c0fdda6225	1	Передано в інше відділення	Дімедрол 1%	2	4	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-17 08:45:45.457155+00	\N	\N	f
87180d76-8752-45c2-b8a0-44b2be752aed	1	Передано в інше відділення	Активоване вугілля	1	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	8a7df9ad-f99a-4687-83b1-a974c72d0657	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-27 08:45:45.457187+00	\N	\N	f
88af5822-ef3d-4b33-b587-380acb71a34b	2	Коригування кількості	Анальгін 50% (амп.)	3	4	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-20 08:45:45.457146+00	\N	\N	f
88f42ffd-439a-4b7a-aaed-85de88327557	0	Поповнення запасів	Валідол	4	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-28 08:45:45.457191+00	\N	\N	f
8b5179ee-848f-44fb-a85a-98b8d235065c	1	Передано в інше відділення	Маска медична	23	0	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-17 08:45:45.457197+00	\N	\N	f
8d6ac4cc-757f-4841-a234-5e1f9de7ee96	4	Використано пацієнтом	Диклофенак 50мг	9	3	618a3475-904f-466b-a192-52be990ea7fe	f180ad63-2730-43fc-83da-54fa3c9da5a4	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-24 08:45:45.457165+00	\N	\N	f
8eb2ef32-4ab6-42b9-b347-7172b2ea9f51	3	Виявлено протермінований препарат	Джгут гумовий	2	0	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-04 08:45:45.457175+00	\N	\N	f
8ec574cc-d0e9-45d8-b390-0213765d878c	3	Виявлено протермінований препарат	Супрастин 25мг	3	3	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-01 08:45:45.457154+00	\N	\N	f
98031daf-0083-4530-bb01-90497eecd559	4	Використано пацієнтом	Валідол	1	3	44457538-eed8-40d0-9186-dca9e4ed9f9f	b7772c6a-cce9-4b4d-8b26-53f4dae7375e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-19 08:45:45.457141+00	\N	\N	f
9a97fe7a-71a1-428f-8cf1-52dba39ecc1a	1	Передано в інше відділення	Бинт марлевий (упаковка)	1	5	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-03 08:45:45.457153+00	\N	\N	f
9b0347ae-bf99-48e0-a8b3-3ea0b36b7bd0	5	Списано через закінчення терміну	Шприц одноразовий 5мл	1	0	f1d00635-0565-4eaf-b4cf-228beb6a8dca	30110403-4d1a-44f8-8cd9-04d92f5663c8	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-31 08:45:45.457172+00	\N	\N	f
9d8d1b2f-9c01-4744-8c2e-cbc7fe8adc95	1	Передано в інше відділення	Дімедрол 1%	2	4	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-17 08:45:45.457195+00	\N	\N	f
9ef8f287-393c-4dcd-8e81-003d615a28e0	3	Виявлено протермінований препарат	Цитрамон	2	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	8a7df9ad-f99a-4687-83b1-a974c72d0657	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-08 08:45:45.457189+00	\N	\N	f
a19f6a7b-72b2-49c3-9b91-71a558f69018	5	Списано через закінчення терміну	Спирт етиловий 70%	54	1	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-07 08:45:45.457186+00	\N	\N	f
a2270654-e581-442f-aa9c-5c092264e2ac	4	Використано пацієнтом	Бинт марлевий (упаковка)	1	5	f1d00635-0565-4eaf-b4cf-228beb6a8dca	30110403-4d1a-44f8-8cd9-04d92f5663c8	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-02 08:45:45.457172+00	\N	\N	f
a244cee0-8b5c-431b-88e5-31740addd93d	3	Виявлено протермінований препарат	Супрастин 25мг	1	3	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-06 08:45:45.45715+00	\N	\N	f
a345a5e8-591c-481a-9b16-b3e7fc986042	1	Передано в інше відділення	Валідол	1	3	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-21 08:45:45.457184+00	\N	\N	f
a67113af-8038-406f-8e8d-9117bcb32864	5	Списано через закінчення терміну	Магнію сульфат 25%	2	4	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-19 08:45:45.457191+00	\N	\N	f
ac730ce9-796d-4581-86ea-04df2aec369e	4	Використано пацієнтом	Лейкопластир бактерицидний	2	0	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-12 08:45:45.45719+00	\N	\N	f
b1466950-d6b2-4043-bb36-56a4a8a7d257	4	Використано пацієнтом	Магнію сульфат 25%	1	4	618a3475-904f-466b-a192-52be990ea7fe	f180ad63-2730-43fc-83da-54fa3c9da5a4	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-11 08:45:45.457163+00	\N	\N	f
b3171b6b-0f7e-4857-9b70-08a5259cf829	2	Коригування кількості	Парацетамол 500мг	11	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	d830c597-a126-4420-9735-2bc6e0c1ed84	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-26 08:45:45.457168+00	\N	\N	f
b3ae7519-2a5c-4591-8285-409e46d8a50a	2	Коригування кількості	Вата стерильна	13	2	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-19 08:45:45.457177+00	\N	\N	f
b4512acd-8ac0-43de-9da3-f2e344076f1b	5	Списано через закінчення терміну	Адреналін 0.1%	2	4	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-16 08:45:45.45715+00	\N	\N	f
b62c7225-f62b-4abf-bac8-40a1c7f93c12	4	Використано пацієнтом	Преднізолон 30мг	2	4	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-14 08:45:45.457185+00	\N	\N	f
b64022fd-c7eb-41db-8901-1368622bc965	5	Списано через закінчення терміну	Ібупрофен 200мг	2	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-24 08:45:45.457147+00	\N	\N	f
b76f8799-ec05-4d66-9633-b7aea8acec41	0	Поповнення запасів	Вата стерильна	17	2	44457538-eed8-40d0-9186-dca9e4ed9f9f	b7772c6a-cce9-4b4d-8b26-53f4dae7375e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-26 08:45:45.457141+00	\N	\N	f
b9cb8477-ea79-46a0-b486-5406d9ca4aec	1	Передано в інше відділення	Перекис водню 3%	62	1	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-22 08:45:45.457186+00	\N	\N	f
ba77b2f2-6e51-416e-bb4f-baa5bfdbe2b4	0	Поповнення запасів	Хлоргексидин 0.05%	77	1	44457538-eed8-40d0-9186-dca9e4ed9f9f	b7772c6a-cce9-4b4d-8b26-53f4dae7375e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-11 08:45:45.457142+00	\N	\N	f
bd0645ca-4d18-4029-ae94-eb41e3715131	5	Списано через закінчення терміну	Ібупрофен 200мг	11	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	30110403-4d1a-44f8-8cd9-04d92f5663c8	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-21 08:45:45.457173+00	\N	\N	f
bdbcc1d1-91b4-4122-9275-e363e3353e4b	2	Коригування кількості	Активоване вугілля	1	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	8a7df9ad-f99a-4687-83b1-a974c72d0657	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-22 08:45:45.457187+00	\N	\N	f
beab5679-a4c1-4591-89b0-21276c3511a1	1	Передано в інше відділення	Серветки спиртові	1	5	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-25 08:45:45.457194+00	\N	\N	f
c0699b6f-f556-4f40-b67a-f91e96fdd311	5	Списано через закінчення терміну	Перекис водню 3%	67	1	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-07 08:45:45.457182+00	\N	\N	f
c5878a2a-e1c9-43f5-9daf-1463d1f80183	2	Коригування кількості	Преднізолон 30мг	3	4	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-05 08:45:45.457199+00	\N	\N	f
c9d117fd-540f-48b9-bb9a-8c466bf02338	5	Списано через закінчення терміну	Марля медична	25	2	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-08 08:45:45.457181+00	\N	\N	f
cfae8763-a871-4910-93a4-3ab19ca2be42	3	Виявлено протермінований препарат	Валідол	5	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-07 08:45:45.457199+00	\N	\N	f
d05f6bda-10a5-4ed9-af05-a9fff802a1c4	1	Передано в інше відділення	Джгут гумовий	2	0	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-09 08:45:45.457175+00	\N	\N	f
d0c1ca7f-2812-481e-ae5e-414bda249591	1	Передано в інше відділення	Валідол	2	3	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-08 08:45:45.457179+00	\N	\N	f
d1a9bdfa-ef67-437b-856a-4b3ce3d638c0	1	Передано в інше відділення	Анальгін 500мг	2	3	e666c0dc-34e4-41a4-884c-5c4d7a98caed	51953ce5-3663-4f9e-a117-4c5b99a6fbd7	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-02-24 08:45:45.457171+00	\N	\N	f
d4135c72-d2d5-4488-83a8-ee374a916731	1	Передано в інше відділення	Цитрамон	2	3	618a3475-904f-466b-a192-52be990ea7fe	f180ad63-2730-43fc-83da-54fa3c9da5a4	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-08 08:45:45.457162+00	\N	\N	f
d41d9ec5-1df5-4ea8-bd4a-1391bad85345	0	Поповнення запасів	Бинт еластичний	3	0	618a3475-904f-466b-a192-52be990ea7fe	f180ad63-2730-43fc-83da-54fa3c9da5a4	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-10 08:45:45.457164+00	\N	\N	f
d7279874-5afb-4b05-a52e-5ed54b427e57	2	Коригування кількості	Перекис водню 3%	12	1	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.457153+00	\N	\N	f
d7923377-f912-4185-a65b-d6aa88aad501	5	Списано через закінчення терміну	Спирт етиловий 70%	15	1	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-03 08:45:45.45719+00	\N	\N	f
da21aadc-aeec-4606-963d-9861b8df2069	3	Виявлено протермінований препарат	Супрастин 25мг	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.457201+00	\N	\N	f
dcff9fa0-2268-4dc9-b6a3-55452d822efd	0	Поповнення запасів	Нітрогліцерин	3	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-13 08:45:45.4572+00	\N	\N	f
dd62a6e5-e480-45ce-ad7d-9e1efbdc7890	4	Використано пацієнтом	Парацетамол 500мг	17	3	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-28 08:45:45.457176+00	\N	\N	f
e2455af4-d13c-4ca2-a3e5-6c239a0b5bcd	0	Поповнення запасів	Супрастин 25мг	3	3	44457538-eed8-40d0-9186-dca9e4ed9f9f	b7772c6a-cce9-4b4d-8b26-53f4dae7375e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-04 08:45:45.457143+00	\N	\N	f
e2d31b2d-396c-4d30-878b-e8773e6fe5e0	3	Виявлено протермінований препарат	Лоперамід	2	3	93091039-76bb-4740-868c-4421685ad968	f7c84a1b-3bee-43df-b289-164526a9f502	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-05 08:45:45.457152+00	\N	\N	f
e4b36715-fcca-407d-9b3d-85cdf22f19cd	1	Передано в інше відділення	Лоперамід	1	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	8a7df9ad-f99a-4687-83b1-a974c72d0657	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-28 08:45:45.457188+00	\N	\N	f
ee939451-4ef5-4647-a62b-876db5551a2e	2	Коригування кількості	Кеторолак 10мг	3	3	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-12 08:45:45.457183+00	\N	\N	f
eeaf11e8-0b0d-470d-9f18-02f4d240db99	2	Коригування кількості	Фізіологічний розчин 0.9%	74	1	d999009f-9975-473c-b50b-2e795c35271c	e9e6681a-b8c6-4ed7-9f46-27959285c73c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-12 08:45:45.457181+00	\N	\N	f
ef902739-0928-40f9-a4dd-0118f75354cf	4	Використано пацієнтом	Дексаметазон 4мг	1	4	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	57d0af0e-6ec7-41b7-be5a-2c1850d758dc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-06 08:45:45.457196+00	\N	\N	f
f1c397d4-87ba-4144-814e-fc3bf9ee68df	2	Коригування кількості	Нітрогліцерин	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-01-17 08:45:45.457198+00	\N	\N	f
f1d8c321-d431-4c2d-8a56-aea3fd4fd2f4	1	Передано в інше відділення	Марля медична	9	2	618a3475-904f-466b-a192-52be990ea7fe	f180ad63-2730-43fc-83da-54fa3c9da5a4	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-31 08:45:45.457163+00	\N	\N	f
f1e6874f-95da-4ce0-ab0d-3e4b1a8c75c6	2	Коригування кількості	Джгут гумовий	1	0	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-28 08:45:45.457177+00	\N	\N	f
f9081b73-1a3e-46f0-b5db-1f2704c55347	0	Поповнення запасів	Дексаметазон 4мг	1	4	d129b3c4-be09-4e82-bb40-3af9ab8181c9	8c02d414-979a-4fa5-a16d-486026ad9f7b	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-09 08:45:45.457178+00	\N	\N	f
f993bcec-cfe8-44b9-b86e-7a3c0e823acc	0	Поповнення запасів	Джгут гумовий	1	0	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	d830c597-a126-4420-9735-2bc6e0c1ed84	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-04 08:45:45.457166+00	\N	\N	f
fc393827-b072-41ae-8adf-79c69d863716	3	Виявлено протермінований препарат	Марля медична	43	2	fbe7fcd2-1037-426a-a2c2-107eddad006e	f3eab368-5eb5-4e86-81ee-fbd331a647cc	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-28 08:45:45.457146+00	\N	\N	f
feb871e6-b9fb-4197-b2da-cfe1ae623b4c	3	Виявлено протермінований препарат	Кеторолак 10мг	2	3	e666c0dc-34e4-41a4-884c-5c4d7a98caed	51953ce5-3663-4f9e-a117-4c5b99a6fbd7	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-06 08:45:45.45717+00	\N	\N	f
fed9ee80-bcfb-4412-830e-a175869b29ef	2	Коригування кількості	Супрастин 25мг	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	b2e71292-8b17-4167-b4fa-e0d34af255ba	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-03-04 08:45:45.457202+00	\N	\N	f
0142aa11-51e4-4da3-a0d1-8d58a08ce7ad	0	Поповнення запасів	Бинт еластичний	1	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-18 08:45:46.092562+00	\N	\N	f
0181e651-bab0-4d1a-9638-eed85ced6f49	2	Коригування кількості	Спирт етиловий 70%	19	1	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-25 08:45:46.092574+00	\N	\N	f
03bf5407-4623-4c1b-8fcf-2d4f007d4b70	4	Використано пацієнтом	Розчин йоду 5%	21	1	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	1a5e4c12-68c3-45d3-a92d-bef2c82e1334	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-20 08:45:46.092549+00	\N	\N	f
04588a4e-2250-4ca2-aa42-787318358adc	2	Коригування кількості	Но-шпа 40мг	1	3	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-20 08:45:46.092529+00	\N	\N	f
0c0e59a5-1a1d-4786-9008-8c2e7fb406a6	4	Використано пацієнтом	Бинт еластичний	2	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-25 08:45:46.092565+00	\N	\N	f
0c248755-0768-4da2-ae7e-0ebae7316637	0	Поповнення запасів	Лейкопластир бактерицидний	4	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-01 08:45:46.09257+00	\N	\N	f
0f6a6d00-6cd6-4d7d-b34c-14e97ef28975	5	Списано через закінчення терміну	Вата стерильна	35	2	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-10 08:45:46.092558+00	\N	\N	f
1064b3c5-f4c7-4e30-9da6-9c2826c7c281	1	Передано в інше відділення	Парацетамол 500мг	5	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-23 08:45:46.092559+00	\N	\N	f
1224c981-9575-4879-983e-01dfc0a2f7ee	2	Коригування кількості	Активоване вугілля	7	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-01 08:45:46.092566+00	\N	\N	f
1682df60-aee7-4fb2-a82c-7dd36875b5bd	1	Передано в інше відділення	Спирт етиловий 70%	69	1	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-22 08:45:46.092559+00	\N	\N	f
18cb44a3-e176-4acd-adf6-cc2667493b93	0	Поповнення запасів	Анальгін 500мг	5	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-19 08:45:46.092535+00	\N	\N	f
19212e86-2b3e-4323-95f5-844c3c5e2ff2	4	Використано пацієнтом	Анальгін 500мг	9	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-24 08:45:46.092545+00	\N	\N	f
1a0c2fe5-8dc6-4288-947a-720a9979ee77	0	Поповнення запасів	Атропін 0.1%	2	4	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-25 08:45:46.092565+00	\N	\N	f
1fa7d8fc-7c5d-4ab0-b85b-07ba2d7ea561	5	Списано через закінчення терміну	Лейкопластир бактерицидний	2	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-03 08:45:46.092571+00	\N	\N	f
2079daad-0269-476b-a274-93df3c24f5fa	4	Використано пацієнтом	Адреналін 0.1%	3	4	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-28 08:45:46.092546+00	\N	\N	f
286c8d92-088c-4720-a150-17b2cb777cf2	1	Передано в інше відділення	Атропін 0.1%	1	4	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-26 08:45:46.092562+00	\N	\N	f
2ca6d147-8efe-4120-817e-aaa177673c6c	3	Виявлено протермінований препарат	Лоперамід	4	3	4b92861f-c987-4786-a375-f284f41e658c	0d7481c3-6296-4ea8-9904-a8332b6ff51f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-08 08:45:46.092553+00	\N	\N	f
2cd30056-1f95-4486-b3a5-80a9772aa310	3	Виявлено протермінований препарат	Маска медична	13	0	96cfdf35-e54e-4785-ae4b-0bac61199794	4d12ada0-e540-45f2-82d9-1f09d36f8c44	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-13 08:45:46.092536+00	\N	\N	f
355b493d-12d7-468a-8e5c-c113ab68328c	3	Виявлено протермінований препарат	Лейкопластир бактерицидний	9	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-21 08:45:46.09257+00	\N	\N	f
35f038ba-373e-4ce6-bc48-d6c717db3ad0	2	Коригування кількості	Бісептол 480мг	1	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-03 08:45:46.092535+00	\N	\N	f
3610a959-9219-47c4-841d-3bba22984138	3	Виявлено протермінований препарат	Хлоргексидин 0.05%	70	1	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-21 08:45:46.092573+00	\N	\N	f
36922e52-e0e7-4792-b32c-399ef2ed4ff8	3	Виявлено протермінований препарат	Перекис водню 3%	13	1	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-17 08:45:46.092578+00	\N	\N	f
37e41db9-4e87-42fb-97bc-9e2aa72a4699	5	Списано через закінчення терміну	Валідол	1	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-10 08:45:46.092571+00	\N	\N	f
3e3eb0f4-cb1e-4378-81ec-89d82fd5c9fa	4	Використано пацієнтом	Ібупрофен 200мг	1	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-19 08:45:46.092562+00	\N	\N	f
3e95c551-0fbe-4390-97dd-c21c9163ddb6	1	Передано в інше відділення	Парацетамол 500мг	1	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	dce88cda-deda-494c-a043-57cfee71a2d7	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-27 08:45:46.092584+00	\N	\N	f
3f5089c0-89d0-4572-80e4-2d0c496585e2	3	Виявлено протермінований препарат	Кеторолак 10мг	3	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-09 08:45:46.09256+00	\N	\N	f
3f790c60-efe3-4da7-ab24-6748b7d1ab57	0	Поповнення запасів	Рукавички медичні	6	0	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-31 08:45:46.092576+00	\N	\N	f
3fee46e1-f52e-437e-bbfc-7548ff8b7c72	5	Списано через закінчення терміну	Маска медична	2	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-16 08:45:46.092569+00	\N	\N	f
401f66f0-d6fd-43d4-9c8e-73a7a4e36676	2	Коригування кількості	Спирт етиловий 70%	59	1	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-08 08:45:46.092563+00	\N	\N	f
4192dfbb-39fa-47ae-9c6e-fa8214b51258	1	Передано в інше відділення	Но-шпа 40мг	1	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-02 08:45:46.092533+00	\N	\N	f
4773480e-75a3-4970-a5db-30f912a4fb3a	0	Поповнення запасів	Корвалол	7	1	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-22 08:45:46.092563+00	\N	\N	f
4c2dcbe1-7f26-4d25-a834-3594f6f1f8ee	3	Виявлено протермінований препарат	Парацетамол 500мг	6	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-08 08:45:46.092543+00	\N	\N	f
4c3a0eaf-bc98-4696-b0dd-087320fac986	3	Виявлено протермінований препарат	Бинт еластичний	2	0	c6e912f5-28db-4b92-80a1-f5e3d7819846	dce88cda-deda-494c-a043-57cfee71a2d7	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-10 08:45:46.092584+00	\N	\N	f
59648702-ff84-426a-9c1f-7190f5ae5331	4	Використано пацієнтом	Лейкопластир бактерицидний	3	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-24 08:45:46.092574+00	\N	\N	f
5af9b08d-aa56-4696-ad37-5539fd3e9414	3	Виявлено протермінований препарат	Бісептол 480мг	3	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-16 08:45:46.09256+00	\N	\N	f
5b201afd-9a72-449e-a161-8dbac4f668aa	3	Виявлено протермінований препарат	Розчин йоду 5%	12	1	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-26 08:45:46.092544+00	\N	\N	f
5e2ea4c6-bef7-46c7-8a22-b70fd8d642b2	2	Коригування кількості	Вата стерильна	23	2	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-25 08:45:46.092557+00	\N	\N	f
5e39561d-a039-4a29-98fd-ae391f1df718	3	Виявлено протермінований препарат	Серветки спиртові	2	5	96cfdf35-e54e-4785-ae4b-0bac61199794	4d12ada0-e540-45f2-82d9-1f09d36f8c44	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-25 08:45:46.092538+00	\N	\N	f
5f99791a-2981-4187-9b30-8c02226b8918	4	Використано пацієнтом	Кеторолак 10мг	1	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-12 08:45:46.092544+00	\N	\N	f
5faf48ab-239a-4afe-8c63-95d123414cfa	0	Поповнення запасів	Адреналін 0.1%	3	4	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-13 08:45:46.092545+00	\N	\N	f
60be716b-b41a-4040-93bf-9482925eaf6a	3	Виявлено протермінований препарат	Рукавички медичні	7	0	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-24 08:45:46.092559+00	\N	\N	f
61568961-fbb9-433b-9bcc-997e40faf637	5	Списано через закінчення терміну	Бісептол 480мг	2	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-16 08:45:46.092558+00	\N	\N	f
618ae917-55c7-4765-8bb5-9db8e0037991	0	Поповнення запасів	Но-шпа 40мг	4	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-14 08:45:46.092547+00	\N	\N	f
64a5bd80-e85b-4b21-ba8e-230593326894	5	Списано через закінчення терміну	Корвалол	11	1	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-08 08:45:46.092561+00	\N	\N	f
650396c9-a595-4103-b9e8-4d966b8e23af	5	Списано через закінчення терміну	Цитрамон	6	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-26 08:45:46.092574+00	\N	\N	f
6816db25-da6a-48ff-8eb0-6e01287b8dfc	2	Коригування кількості	Розчин йоду 5%	12	1	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-15 08:45:46.092566+00	\N	\N	f
68cb13c3-906f-4d34-a532-d9ab2c1eceb4	0	Поповнення запасів	Джгут гумовий	1	0	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	1a5e4c12-68c3-45d3-a92d-bef2c82e1334	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-15 08:45:46.092548+00	\N	\N	f
69738e5f-5fa6-4180-8697-640e1672235a	4	Використано пацієнтом	Анальгін 500мг	2	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-01 08:45:46.092564+00	\N	\N	f
6b684269-8e85-4824-a02d-f44a62e13037	3	Виявлено протермінований препарат	Валідол	5	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-11 08:45:46.092532+00	\N	\N	f
6f556699-9549-4949-b6f5-79b1f4ee783e	0	Поповнення запасів	Марля медична	3	2	4b92861f-c987-4786-a375-f284f41e658c	0d7481c3-6296-4ea8-9904-a8332b6ff51f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-25 08:45:46.092552+00	\N	\N	f
71543d04-9085-49fd-b31e-4b21e65f9c3e	4	Використано пацієнтом	Бісептол 480мг	9	3	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-06 08:45:46.09253+00	\N	\N	f
71913b1d-b87c-4c8b-9d1d-8ba6242edf03	5	Списано через закінчення терміну	Лейкопластир бактерицидний	3	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-28 08:45:46.092563+00	\N	\N	f
726928e5-462b-49a1-8576-93cd935dd8f7	2	Коригування кількості	Диклофенак 50мг	7	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-13 08:45:46.092538+00	\N	\N	f
730c1453-77bf-4cde-9393-4868f709a649	4	Використано пацієнтом	Серветки спиртові	1	5	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-26 08:45:46.092579+00	\N	\N	f
73415b59-0d3c-4eef-9cac-17aa900d90dc	4	Використано пацієнтом	Марля медична	34	2	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	1a5e4c12-68c3-45d3-a92d-bef2c82e1334	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-22 08:45:46.092549+00	\N	\N	f
734bce9c-5a12-47bd-83de-b2dd239d4826	5	Списано через закінчення терміну	Лоратадин 10мг	3	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-13 08:45:46.092546+00	\N	\N	f
741b4511-90c7-4c68-be09-cf66d7db33ce	4	Використано пацієнтом	Папаверин 2%	2	4	96cfdf35-e54e-4785-ae4b-0bac61199794	4d12ada0-e540-45f2-82d9-1f09d36f8c44	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-31 08:45:46.092538+00	\N	\N	f
7cac9551-ce1b-42f7-826f-44f14c4bfab3	1	Передано в інше відділення	Серветки спиртові	2	5	4b92861f-c987-4786-a375-f284f41e658c	0d7481c3-6296-4ea8-9904-a8332b6ff51f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-14 08:45:46.092551+00	\N	\N	f
7de29666-6a61-4d24-90e1-ea8a137c60f4	2	Коригування кількості	Спирт етиловий 70%	18	1	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-07 08:45:46.092532+00	\N	\N	f
845e0017-6ee1-482a-a60c-e7ef17c55b98	1	Передано в інше відділення	Корвалол	18	1	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-17 08:45:46.092573+00	\N	\N	f
84e3b28e-c33b-4a84-93aa-97be9b3eb5a7	2	Коригування кількості	Атропін 0.1%	1	4	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	1a5e4c12-68c3-45d3-a92d-bef2c82e1334	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-06 08:45:46.09255+00	\N	\N	f
8610d0a8-263d-404d-a457-c28e484ed785	4	Використано пацієнтом	Кеторолак 10мг	3	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-06 08:45:46.092548+00	\N	\N	f
92718154-32dd-4396-bd29-db6001f4eb74	1	Передано в інше відділення	Бинт стерильний 5м×10см	5	0	96cfdf35-e54e-4785-ae4b-0bac61199794	4d12ada0-e540-45f2-82d9-1f09d36f8c44	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-06 08:45:46.092536+00	\N	\N	f
9a71e637-1afd-4795-8106-2fb740ea4b8f	2	Коригування кількості	Бісептол 480мг	3	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-19 08:45:46.092561+00	\N	\N	f
9d641bf2-6381-4b64-833c-c7f8330df823	1	Передано в інше відділення	Преднізолон 30мг	2	4	4b92861f-c987-4786-a375-f284f41e658c	0d7481c3-6296-4ea8-9904-a8332b6ff51f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-20 08:45:46.092552+00	\N	\N	f
9ecd319f-6db9-4e28-8a96-d94e8517d833	1	Передано в інше відділення	Валідол	3	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	dce88cda-deda-494c-a043-57cfee71a2d7	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-28 08:45:46.09258+00	\N	\N	f
9ee319d7-8143-448b-9eb7-9db521a517e3	1	Передано в інше відділення	Рукавички медичні	13	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-19 08:45:46.092572+00	\N	\N	f
a0ccf2e1-555f-4278-95fb-553a897c3248	0	Поповнення запасів	Серветки спиртові	2	5	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-13 08:45:46.092547+00	\N	\N	f
a1e0f140-2682-48a4-8001-48d7cf9e60ed	0	Поповнення запасів	Серветки спиртові	2	5	c6e912f5-28db-4b92-80a1-f5e3d7819846	dce88cda-deda-494c-a043-57cfee71a2d7	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-13 08:45:46.09258+00	\N	\N	f
a3ad6f4a-7a6d-432b-bb1f-6a86ba5cd49d	0	Поповнення запасів	Хлоргексидин 0.05%	85	1	c6e912f5-28db-4b92-80a1-f5e3d7819846	dce88cda-deda-494c-a043-57cfee71a2d7	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-04 08:45:46.092584+00	\N	\N	f
a5014c85-c21a-4326-863c-04dd8c3f22d5	4	Використано пацієнтом	Корвалол	1	1	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-08 08:45:46.092533+00	\N	\N	f
a67d7f81-fb9b-4437-a471-6bfe88a129b4	5	Списано через закінчення терміну	Атропін 0.1%	2	4	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-12 08:45:46.092564+00	\N	\N	f
ace4cdc8-50a7-4fc6-880a-9f0adc24b8d5	1	Передано в інше відділення	Парацетамол 500мг	15	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	dce88cda-deda-494c-a043-57cfee71a2d7	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-16 08:45:46.09258+00	\N	\N	f
ad81aefc-e66b-45f9-8a1a-9ce91622e657	3	Виявлено протермінований препарат	Розчин йоду 5%	3	1	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-07 08:45:46.092578+00	\N	\N	f
ad83fde7-8a89-411e-b539-5be3963c8407	3	Виявлено протермінований препарат	Серветки спиртові	1	5	96cfdf35-e54e-4785-ae4b-0bac61199794	4d12ada0-e540-45f2-82d9-1f09d36f8c44	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-03 08:45:46.092537+00	\N	\N	f
af245a0b-c72b-4faa-b901-b283ea5e5bf3	3	Виявлено протермінований препарат	Розчин йоду 5%	4	1	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-18 08:45:46.092534+00	\N	\N	f
afdb53b3-e86e-4471-8525-e4b8ffb88f3d	4	Використано пацієнтом	Кеторолак 10мг	2	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-15 08:45:46.092558+00	\N	\N	f
b0b6200c-8d4d-46da-a4a0-469970b2cc2b	5	Списано через закінчення терміну	Серветки спиртові	2	5	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-17 08:45:46.092531+00	\N	\N	f
b0f0a8ac-a746-464c-a752-e304bd355914	2	Коригування кількості	Марля медична	25	2	4b92861f-c987-4786-a375-f284f41e658c	0d7481c3-6296-4ea8-9904-a8332b6ff51f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-26 08:45:46.092552+00	\N	\N	f
b1a28531-8f02-430c-bf59-63ce7c277ab9	2	Коригування кількості	Лоперамід	4	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-15 08:45:46.092536+00	\N	\N	f
b3359bc0-8ba8-4832-ba9d-f0f6c9cea2a4	2	Коригування кількості	Корвалол	4	1	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-26 08:45:46.092561+00	\N	\N	f
b41113c5-0420-41f1-bc77-cdc51d6a8af0	5	Списано через закінчення терміну	Парацетамол 500мг	8	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-16 08:45:46.092575+00	\N	\N	f
b4661ff5-ec68-4e11-8b19-9b25814739ac	5	Списано через закінчення терміну	Амоксицилін 500мг	6	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-22 08:45:46.092572+00	\N	\N	f
bba0342c-36f7-4993-8f9f-9d76ea17a194	0	Поповнення запасів	Активоване вугілля	6	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-15 08:45:46.092547+00	\N	\N	f
bfa110a4-ba0e-4437-b208-556bf486d515	2	Коригування кількості	Бісептол 480мг	1	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-16 08:45:46.092553+00	\N	\N	f
c2cbb9ab-dff6-4fa6-98e0-ae5da323cf38	0	Поповнення запасів	Маска медична	16	0	96cfdf35-e54e-4785-ae4b-0bac61199794	4d12ada0-e540-45f2-82d9-1f09d36f8c44	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-11 08:45:46.092537+00	\N	\N	f
c5b00a35-8bdf-4f00-9083-da9affde921d	5	Списано через закінчення терміну	Бинт еластичний	3	0	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-01 08:45:46.092522+00	\N	\N	f
c76d7455-60f6-4216-8ead-fbe2bfa86e07	4	Використано пацієнтом	Валідол	2	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-06 08:45:46.092534+00	\N	\N	f
c9813887-da71-4b94-b235-a2a0d7769879	4	Використано пацієнтом	Валідол	6	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-27 08:45:46.092572+00	\N	\N	f
cbec492c-8b86-495f-a3ac-f93a286f93aa	2	Коригування кількості	Корвалол	21	1	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-08 08:45:46.092529+00	\N	\N	f
d06161d2-41ae-4ee3-88cd-ff9015c6313a	5	Списано через закінчення терміну	Бісептол 480мг	2	3	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-14 08:45:46.092531+00	\N	\N	f
d30f1cd8-9a05-4fae-8b88-91de00aef5a0	1	Передано в інше відділення	Атропін 0.1%	1	4	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-05 08:45:46.092529+00	\N	\N	f
d38281f6-47fe-4c1d-981e-dcb6520886c6	3	Виявлено протермінований препарат	Розчин йоду 5%	6	1	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-12 08:45:46.092577+00	\N	\N	f
d6cba737-ce9d-4728-a4ea-159eb2c0d893	5	Списано через закінчення терміну	Шприц одноразовий 10мл	6	0	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	1a5e4c12-68c3-45d3-a92d-bef2c82e1334	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-09 08:45:46.092549+00	\N	\N	f
d7c110b1-4fb8-439f-a07d-6a78002a76a8	0	Поповнення запасів	Маска медична	10	0	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-17 08:45:46.092577+00	\N	\N	f
d91125be-c4db-4e78-99d6-fe2d87ecdadf	2	Коригування кількості	Серветки спиртові	2	5	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-08 08:45:46.092577+00	\N	\N	f
dab80e5e-2c57-415f-a77b-973803cea7f8	0	Поповнення запасів	Валідол	4	3	4b92861f-c987-4786-a375-f284f41e658c	0d7481c3-6296-4ea8-9904-a8332b6ff51f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-09 08:45:46.092551+00	\N	\N	f
db8c6e12-3d1a-4037-951c-5102dc5a1ec4	3	Виявлено протермінований препарат	Серветки спиртові	2	5	c6e912f5-28db-4b92-80a1-f5e3d7819846	dce88cda-deda-494c-a043-57cfee71a2d7	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-06 08:45:46.092585+00	\N	\N	f
dcfa95eb-29d5-4854-a947-2b5ee6370e01	2	Коригування кількості	Атропін 0.1%	1	4	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-05 08:45:46.092528+00	\N	\N	f
df3f3ae8-f408-4217-b1aa-d1bfab5285cb	0	Поповнення запасів	Но-шпа 40мг	4	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-13 08:45:46.092545+00	\N	\N	f
e0f0defd-0cda-4d79-abc6-281da809e6ad	5	Списано через закінчення терміну	Спирт етиловий 70%	90	1	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-14 08:45:46.092576+00	\N	\N	f
e1972c3d-810a-4c37-9b87-cdcc0f1e6033	5	Списано через закінчення терміну	Корвалол	14	1	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-05 08:45:46.092573+00	\N	\N	f
e24d74ce-769e-4e6b-8c46-d9e3fcb8cf62	2	Коригування кількості	Рукавички медичні	1	0	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-22 08:45:46.092531+00	\N	\N	f
e71d3239-e222-4690-8403-2734a6528004	0	Поповнення запасів	Шприц одноразовий 10мл	8	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	d249ab9d-20be-4594-9730-5e8ca7be7707	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-21 08:45:46.092564+00	\N	\N	f
e890be97-c8d8-47f5-8b81-65f2db7dae47	5	Списано через закінчення терміну	Амоксицилін 500мг	3	3	4b92861f-c987-4786-a375-f284f41e658c	0d7481c3-6296-4ea8-9904-a8332b6ff51f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-07 08:45:46.092553+00	\N	\N	f
e8ab8212-d237-4e60-934f-1010e6bd1747	5	Списано через закінчення терміну	Лоперамід	1	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-22 08:45:46.092578+00	\N	\N	f
eaefe685-443f-4184-8b1b-e4eb4b66b028	3	Виявлено протермінований препарат	Бісептол 480мг	3	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	1a5e4c12-68c3-45d3-a92d-bef2c82e1334	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-20 08:45:46.09255+00	\N	\N	f
ebde0b93-e6d6-45e3-bc1b-eca96b34aa2b	5	Списано через закінчення терміну	Преднізолон 30мг	1	4	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-26 08:45:46.092576+00	\N	\N	f
ed0214f3-d58d-4862-9d4e-141e8363a94f	4	Використано пацієнтом	Серветки спиртові	2	5	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-20 08:45:46.092539+00	\N	\N	f
ee00e6bc-d93d-46a1-a577-a7c8ca2745fb	3	Виявлено протермінований препарат	Хлоргексидин 0.05%	13	1	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-27 08:45:46.092535+00	\N	\N	f
efa954fd-4a1c-4999-93c7-e53e29f94ff3	5	Списано через закінчення терміну	Лейкопластир бактерицидний	5	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	8e6640f0-577c-476f-975a-33c1ddf2fd63	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-21 08:45:46.09257+00	\N	\N	f
f1425b0e-5565-48a1-b92b-a6c8331d52e2	0	Поповнення запасів	Амоксицилін 500мг	8	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-16 08:45:46.092575+00	\N	\N	f
f1c75f43-7967-4c04-9469-b60f1ca3d21d	2	Коригування кількості	Бісептол 480мг	3	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	2a779739-3a10-43b2-b1ce-cf108480a30a	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-01-25 08:45:46.092557+00	\N	\N	f
f28903c2-2671-460a-9115-c83a38fca442	1	Передано в інше відділення	Магнію сульфат 25%	3	4	f6e6f5d3-630b-4902-8358-7b6e3af39038	2f99e495-00e9-495b-b6c2-80d6c2a06e6c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-03-05 08:45:46.092579+00	\N	\N	f
f3b6a33c-a026-4817-b08b-9b1cf2d497bb	0	Поповнення запасів	Спирт етиловий 70%	45	1	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	d234d8f8-8f49-4a69-b268-316777633cb9	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-07 08:45:46.092533+00	\N	\N	f
f52dd1ea-fd71-4260-a315-cf70f60e1cf0	3	Виявлено протермінований препарат	Корвалол	19	1	03c26c05-1356-48b7-9f81-e802098016e0	5781d60c-cc1d-4a0f-89f2-e1690857287d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-02-20 08:45:46.092528+00	\N	\N	f
f953997c-7f41-4e88-8367-37e39c655ed8	4	Використано пацієнтом	Бісептол 480мг	3	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	1a5e4c12-68c3-45d3-a92d-bef2c82e1334	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-08 08:45:46.09255+00	\N	\N	f
fb9efda0-cfd9-4176-8d9d-995c7d4ccb24	4	Використано пацієнтом	Анальгін 500мг	5	3	0241c840-f709-4030-a7c3-4780bc84e743	012587be-48f8-4678-9486-6fb54e502d2d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:46.092546+00	\N	\N	f
01322eac-ccd4-40aa-8ba7-4279ff7741bb	3	Виявлено протермінований препарат	Кеторолак 10мг	1	3	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-17 08:45:46.775722+00	\N	\N	f
03dd3689-1e59-4a06-b7f7-0e7022715159	5	Списано через закінчення терміну	Рукавички медичні	9	0	6acd5b88-42f5-4612-a475-469a220c1b17	44e6ae52-0550-4867-b49b-92eb3078c59d	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-11 08:45:46.775759+00	\N	\N	f
0400532c-c476-4235-bb96-54165bfb65e3	1	Передано в інше відділення	Преднізолон 30мг	2	4	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-25 08:45:46.775714+00	\N	\N	f
0453f878-ea78-4356-95f2-b8ff0ab90385	3	Виявлено протермінований препарат	Атропін 0.1%	1	4	23d89a46-4b24-4c7e-9e64-3e027577dec1	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-07 08:45:46.77572+00	\N	\N	f
057751c0-191d-4030-81a4-7fbe52df51a4	5	Списано через закінчення терміну	Корвалол	4	1	b6292e00-9c92-40ae-a4b5-a73f306cd665	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-27 08:45:46.775761+00	\N	\N	f
019d76ac-0778-79b4-bf63-5160d9da1d65	1	The record for Активоване вугілля (batch 019d7699-fad1-72be-bc2f-985267dc114f) has been fully deleted from the system (quantity was 0).	Активоване вугілля	0	0	4886163b-e61f-4357-9b8f-097d50a821cd	063a708f-4471-488e-81e4-fa4617696898	69d1796a-d3cb-4761-b636-873c46de50ad	019d7699-fad1-72be-bc2f-985267dc114f	2026-04-10 09:14:38.840358+00	\N	\N	f
019d9578-4f57-7c22-9612-e57557c6616b	4	Medication 'Джгут гумовий' used. Quantity changed from 3 to 0. Used 3 Pieces.	Джгут гумовий	3	0	4886163b-e61f-4357-9b8f-097d50a821cd	0f8ed8de-312a-498a-84fa-3ef04e663455	69d1796a-d3cb-4761-b636-873c46de50ad	d11b16a5-db85-49e0-b389-e092ba60164d	2026-04-16 08:46:23.063182+00	\N	\N	f
05ee364d-b536-437c-82fa-98edb4e514a5	1	Передано в інше відділення	Лоперамід	4	3	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-03 08:45:46.775764+00	\N	\N	f
0633df8a-f25b-4420-94de-59bf65fe8230	5	Списано через закінчення терміну	Атропін 0.1%	2	4	b6292e00-9c92-40ae-a4b5-a73f306cd665	b7707c87-cdc9-481a-bff6-8a3cbc4c8505	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-17 08:45:46.775762+00	\N	\N	f
06887eb7-0185-483e-8ef1-4a3dd89cf87c	0	Поповнення запасів	Бинт еластичний	1	0	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-16 08:45:46.775747+00	\N	\N	f
069c86b0-443e-4cc5-9dd4-aff7a7a0d2c5	1	Передано в інше відділення	Марля медична	11	2	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-19 08:45:46.775736+00	\N	\N	f
088b92da-48d7-4860-a323-ead569bdf512	3	Виявлено протермінований препарат	Лоперамід	3	3	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-05 08:45:46.775767+00	\N	\N	f
0997e0f1-12dc-44a2-a3cb-013ffc15c7a9	3	Виявлено протермінований препарат	Хлоргексидин 0.05%	37	1	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-15 08:45:46.775755+00	\N	\N	f
0b777a6b-b709-47d7-8921-d611e1df4b9a	3	Виявлено протермінований препарат	Шприц одноразовий 10мл	9	0	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-09 08:45:46.775743+00	\N	\N	f
0dadb111-9faf-4929-8e6f-0a5a0cb69a19	1	Передано в інше відділення	Маска медична	16	0	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-28 08:45:46.775739+00	\N	\N	f
0db938a1-6358-4635-aa01-136177d3480c	2	Коригування кількості	Ібупрофен 200мг	5	3	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-27 08:45:46.775737+00	\N	\N	f
0e629277-9a43-4960-8ba3-1388e2573ea7	5	Списано через закінчення терміну	Папаверин 2%	2	4	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-10 08:45:46.775745+00	\N	\N	f
1176e3c6-bd4e-4a9c-9228-fb3496c8c2b0	4	Використано пацієнтом	Анальгін 50% (амп.)	1	4	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-21 08:45:46.775749+00	\N	\N	f
159581c7-0632-403d-8fa3-30ee7720053a	3	Виявлено протермінований препарат	Дімедрол 1%	1	4	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-04 08:45:46.775734+00	\N	\N	f
1bdc52e9-f530-4a6e-bee1-36231773d78d	4	Використано пацієнтом	Маска медична	13	0	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-01 08:45:46.775748+00	\N	\N	f
1c87073d-c5ba-48a0-bb59-2fa8ed07af55	5	Списано через закінчення терміну	Валідол	2	3	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-25 08:45:46.775714+00	\N	\N	f
1d859d11-813d-47ce-a991-1183ab2b94c6	5	Списано через закінчення терміну	Супрастин 25мг	3	3	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-24 08:45:46.775731+00	\N	\N	f
a56fc554-96a3-4661-93ef-d7db40065682	2	Коригування кількості	Цитрамон	9	3	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-08 08:45:46.77575+00	\N	\N	f
a78fd3e0-208e-4a90-8010-1cb21ace3bb4	0	Поповнення запасів	Папаверин 2%	3	4	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-13 08:45:46.77575+00	\N	\N	f
a9ae9f99-2670-48fc-991f-4c4415f76423	3	Виявлено протермінований препарат	Цитрамон	1	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-05 08:45:46.775726+00	\N	\N	f
a9c54cf5-1b87-472c-b6d7-898593527b70	4	Використано пацієнтом	Бісептол 480мг	5	3	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-16 08:45:46.775721+00	\N	\N	f
abd65240-fa1f-4d82-b89f-0064c1d4464b	5	Списано через закінчення терміну	Аспірин 500мг	2	3	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-19 08:45:46.775711+00	\N	\N	f
ae43f76c-9c1a-4521-a863-69c24844c644	5	Списано через закінчення терміну	Супрастин 25мг	7	3	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-19 08:45:46.775767+00	\N	\N	f
ae4d4718-4461-4227-b715-beec8bfc3db3	4	Використано пацієнтом	Лоперамід	4	3	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-02 08:45:46.775733+00	\N	\N	f
af28da04-05cf-4fee-9589-46257fadc6f9	1	Передано в інше відділення	Хлоргексидин 0.05%	22	1	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-19 08:45:46.775724+00	\N	\N	f
afbc7a10-a86c-4de2-b4d8-0888f149f8bc	1	Передано в інше відділення	Магнію сульфат 25%	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-07 08:45:46.775727+00	\N	\N	f
b02d89d5-651e-48e5-96c8-38e5161a0d1e	0	Поповнення запасів	Валідол	1	3	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-15 08:45:46.775747+00	\N	\N	f
b262575f-41d4-49a2-a10e-30f13b0f102e	0	Поповнення запасів	Шприц одноразовий 10мл	2	0	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-01 08:45:46.775754+00	\N	\N	f
b65b56e7-420b-4028-b125-0ea163b4f68e	0	Поповнення запасів	Аспірин 500мг	3	3	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-07 08:45:46.775752+00	\N	\N	f
b738b7cf-141c-4b5c-9888-7f3948f00a95	2	Коригування кількості	Шприц одноразовий 10мл	8	0	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-13 08:45:46.775713+00	\N	\N	f
bb1198ef-d577-4544-8b1c-4e34dfe08df0	5	Списано через закінчення терміну	Кеторолак 10мг	4	3	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-05 08:45:46.775742+00	\N	\N	f
be56f6f1-6aec-4702-bfeb-683cbec4c5c4	3	Виявлено протермінований препарат	Бинт еластичний	1	0	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-21 08:45:46.775749+00	\N	\N	f
be8c8a34-edcf-493e-a4ab-6b83b58aa0d8	0	Поповнення запасів	Нітрогліцерин	2	3	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-01 08:45:46.775722+00	\N	\N	f
bf372081-a3ed-45ec-aca3-fbf4837a19e9	3	Виявлено протермінований препарат	Амоксицилін 500мг	3	3	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-01 08:45:46.775766+00	\N	\N	f
bfb2a692-86d1-49ce-ae42-e93b96805f06	2	Коригування кількості	Атропін 0.1%	1	4	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-27 08:45:46.775741+00	\N	\N	f
c08a1f84-a80d-47f0-bc62-9254974e2584	0	Поповнення запасів	Атропін 0.1%	1	4	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-20 08:45:46.775735+00	\N	\N	f
c1ba61ae-6b53-4dba-9189-e245f3e121bf	1	Передано в інше відділення	Фізіологічний розчин 0.9%	2	1	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-12 08:45:46.775746+00	\N	\N	f
c52dbc9c-b1fe-4a85-9675-216ae6b29db4	3	Виявлено протермінований препарат	Маска медична	38	0	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-22 08:45:46.775713+00	\N	\N	f
c80c8559-09e1-4e12-87d6-31d0fc6d3bed	1	Передано в інше відділення	Шприц одноразовий 5мл	2	0	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-26 08:45:46.775723+00	\N	\N	f
c8c99edc-a92f-4c05-8567-a3b8e540e719	1	Передано в інше відділення	Фізіологічний розчин 0.9%	56	1	8992ed22-2f1d-44ab-958c-a1785f7da058	e69e45c3-3993-4935-8237-1d279e96e12b	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-17 08:45:46.775768+00	\N	\N	f
c9053fdc-cb77-42fb-b284-042836f6f2b7	5	Списано через закінчення терміну	Атропін 0.1%	3	4	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-15 08:45:46.775751+00	\N	\N	f
cc6a740c-13fe-45ad-8a72-33127e784449	3	Виявлено протермінований препарат	Дексаметазон 4мг	6	4	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-08 08:45:46.775715+00	\N	\N	f
ccbdc148-b9a1-4192-9014-bc561e3894d7	0	Поповнення запасів	Маска медична	19	0	23d89a46-4b24-4c7e-9e64-3e027577dec1	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-20 08:45:46.775718+00	\N	\N	f
ccd79a52-c7fc-4a12-adfb-4c1a66034d42	4	Використано пацієнтом	Лоратадин 10мг	4	3	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-09 08:45:46.775738+00	\N	\N	f
ccf25de8-d098-4b9b-8486-436e65e8ff22	0	Поповнення запасів	Шприц одноразовий 10мл	5	0	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-23 08:45:46.775712+00	\N	\N	f
ce2b4353-7560-402c-80ac-de870e3c33f5	3	Виявлено протермінований препарат	Шприц одноразовий 10мл	1	0	23d89a46-4b24-4c7e-9e64-3e027577dec1	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-26 08:45:46.77572+00	\N	\N	f
d1d171e6-01e7-4033-9466-97f08ddf158a	1	Передано в інше відділення	Дімедрол 1%	2	4	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-05 08:45:46.775743+00	\N	\N	f
d1d59f21-eb51-4e5d-b1f8-62eae0563655	3	Виявлено протермінований препарат	Кеторолак 10мг	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-14 08:45:46.77575+00	\N	\N	f
d29e9369-7a5b-4353-a2ac-960b8d913c96	3	Виявлено протермінований препарат	Нітрогліцерин	7	3	23d89a46-4b24-4c7e-9e64-3e027577dec1	b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-28 08:45:46.775717+00	\N	\N	f
d939b4f5-25a7-4c65-a3b8-54bea6123c0b	1	Передано в інше відділення	Супрастин 25мг	6	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-03 08:45:46.775728+00	\N	\N	f
d9a21eac-2b0b-4bf4-93b0-8fec82119a6c	0	Поповнення запасів	Парацетамол 500мг	3	3	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-25 08:45:46.775742+00	\N	\N	f
da09ad74-d1d1-437c-8b30-ebca442bc663	3	Виявлено протермінований препарат	Маска медична	1	0	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-03 08:45:46.775737+00	\N	\N	f
dd625c2c-3922-4198-ad85-07006e42f464	0	Поповнення запасів	Преднізолон 30мг	2	4	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-19 08:45:46.775738+00	\N	\N	f
df34e69a-ac75-4383-836a-df8d5b6225e7	3	Виявлено протермінований препарат	Дімедрол 1%	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-10 08:45:46.775729+00	\N	\N	f
df380f45-fcb1-47c6-af9c-ee0e1d156212	2	Коригування кількості	Бісептол 480мг	4	3	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-03 08:45:46.775736+00	\N	\N	f
e1329618-94c6-4d95-8069-bc18098ec370	3	Виявлено протермінований препарат	Папаверин 2%	2	4	6acd5b88-42f5-4612-a475-469a220c1b17	44e6ae52-0550-4867-b49b-92eb3078c59d	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-13 08:45:46.775757+00	\N	\N	f
e1c7db0c-e6da-4552-8292-0daf4f29feea	5	Списано через закінчення терміну	Цитрамон	2	3	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-15 08:45:46.775741+00	\N	\N	f
e3a8b696-381a-42fa-88b1-ec075e2c3d6e	5	Списано через закінчення терміну	Папаверин 2%	2	4	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-02 08:45:46.775738+00	\N	\N	f
e4e9316e-b199-4d02-9088-58e0c44b9830	4	Використано пацієнтом	Марля медична	59	2	f3b82c93-17b4-4ceb-9964-b577b5707105	3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-19 08:45:46.775732+00	\N	\N	f
e69f84a2-c5d1-4e0b-b54d-e838b6e7eae9	1	Передано в інше відділення	Бинт марлевий (упаковка)	1	5	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-26 08:45:46.775748+00	\N	\N	f
e907714e-51e1-424a-ac21-53648ff9e82b	1	Передано в інше відділення	Перекис водню 3%	20	1	6acd5b88-42f5-4612-a475-469a220c1b17	44e6ae52-0550-4867-b49b-92eb3078c59d	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-14 08:45:46.775758+00	\N	\N	f
e9130321-fbbb-41aa-b511-02feb8ce4b06	4	Використано пацієнтом	Анальгін 500мг	11	3	6b47cfd0-6948-493c-ba26-2305d73679a8	8da86b6a-99c2-4450-bde9-72a97861930f	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-06 08:45:46.775744+00	\N	\N	f
ea76e985-1ca0-4cf4-a4d3-19870715af5d	2	Коригування кількості	Серветки спиртові	1	5	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-08 08:45:46.775713+00	\N	\N	f
ea875f27-11bc-4b9b-86df-755dd29ca04d	1	Передано в інше відділення	Преднізолон 30мг	2	4	41f7cb7b-019f-414c-afec-81f375a50e57	75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-25 08:45:46.775739+00	\N	\N	f
ebf714a9-35ee-49fb-be86-c1ba3ae698ca	5	Списано через закінчення терміну	Джгут гумовий	1	0	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-20 08:45:46.775754+00	\N	\N	f
ecf0f6b1-7ff7-4ee4-90ae-1407f3b37861	3	Виявлено протермінований препарат	Но-шпа 40мг	3	3	06302277-15e6-4ecf-85bd-cae11f170372	0df2f73a-fdaf-4db2-8a57-390642dc1c66	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-02-03 08:45:46.775716+00	\N	\N	f
eeb05915-6529-4c5c-9327-de2452e2827e	1	Передано в інше відділення	Хлоргексидин 0.05%	80	1	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	7a2e2c23-f709-46a0-81b7-17a60ab2e754	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-01 08:45:46.775729+00	\N	\N	f
f57fc2ab-5d13-428a-a7ed-a8f3c5a1bf18	5	Списано через закінчення терміну	Бинт марлевий (упаковка)	1	5	5574e047-35eb-46f3-a453-9c5fdf488c87	8a1196c3-cdb3-4728-bb24-b4e505f57788	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-13 08:45:46.775749+00	\N	\N	f
f8bdda71-e9b6-4890-8e96-ffe059237993	5	Списано через закінчення терміну	Фізіологічний розчин 0.9%	221	1	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-10 08:45:46.775755+00	\N	\N	f
f9b7f41f-8ab6-4aba-b6aa-b49d577ff423	2	Коригування кількості	Парацетамол 500мг	3	3	06931566-89d2-4933-8551-6b4fb796afc7	e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-03-13 08:45:46.77574+00	\N	\N	f
fd94fe5c-048e-425a-b256-0c0bfc9896a6	2	Коригування кількості	Ібупрофен 200мг	8	3	f1ce3185-25b4-4096-8362-be811b916e3d	7c42e46e-f141-4f8e-9a48-00fd59443331	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-01-10 08:45:46.775721+00	\N	\N	f
\.


--
-- Data for Name: Medications; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."Medications" ("Id", "Name", "Quantity", "ExpirationDate", "MinimumQuantity", "Unit", "FirstAidKitId", "OrganizationId", "CreatedDate", "UpdatedDate", "DeletedAt", "IsDeleted") FROM stdin;
019d7698-2cc9-7f4a-9c02-ff443c9a82b1	Активоване вугілля	0	2027-04-10 11:52:41.17976+00	5	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:52:57.673541+00	2026-04-10 08:54:13.521638+00	\N	f
019d9561-680c-76b8-affb-397e2d6362bf	тест	1	2026-05-30 00:00:00+00	1	2	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-16 08:21:22.055962+00	\N	\N	f
f05bebbc-bdde-4a8a-b000-1a913d52c9fd	Марля медична	174	2027-01-26 08:45:46.76623+00	25	2	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76623+00	\N	\N	f
f2756aff-e6fb-4320-851c-65eac693cf1a	Нітрогліцерин	57	2026-03-06 08:45:46.766184+00	5	3	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766184+00	\N	\N	f
f2c57f25-1f61-4aca-b2e0-02fe6138096b	Диклофенак 50мг	26	2027-11-26 08:45:46.766214+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766215+00	\N	\N	f
f2f1198d-dc00-4f47-8b07-6a5ee6d40aa3	Но-шпа 40мг	17	2026-04-20 08:45:46.766149+00	2	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766149+00	\N	\N	f
f58eec26-df5a-4904-81e4-417879f6b1e4	Лоратадин 10мг	11	2027-04-02 08:45:46.766236+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766236+00	\N	\N	f
f5f991d7-554e-4a30-a7aa-1781ddf11dc0	Цитрамон	43	2026-04-14 08:45:46.76618+00	2	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76618+00	\N	\N	f
f7088299-9af6-40ef-af44-a52f14b310d6	Аспірин 500мг	56	2027-10-07 08:45:46.766202+00	2	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766203+00	\N	\N	f
f992110f-c534-4d3c-8986-6481d350edb1	Фізіологічний розчин 0.9%	938	2026-04-16 08:45:46.766221+00	50	1	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766221+00	\N	\N	f
f9c465aa-ee67-41b3-9fd8-56746c27d8ea	Цитрамон	50	2026-10-01 08:45:46.766217+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766217+00	\N	\N	f
f9e91f3b-5cbe-412f-af5a-21765daeff0d	Лоперамід	20	2026-12-30 08:45:46.766215+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766215+00	\N	\N	f
fab382d2-cac5-406c-a80e-47d79755037f	Активоване вугілля	34	2026-06-17 08:45:46.766163+00	5	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766163+00	\N	\N	f
019d76aa-1e87-7270-a262-f1174de88cfa	Активоване вугілля	5	2027-04-10 00:00:00+00	2	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 09:12:33.671734+00	\N	\N	f
6a35499f-2a40-46d8-b004-da851ad33bf6	Валідол	0	2025-10-13 08:45:44.00217+00	2	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002171+00	2026-04-16 08:34:16.388493+00	\N	f
fadfdc2c-a862-4ff6-b336-aab4a2a7c610	Фізіологічний розчин 0.9%	388	2026-11-20 08:45:46.766148+00	50	1	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766148+00	\N	\N	f
fd3527a6-bbb8-495c-8fe5-8a47c5ba7f3c	Парацетамол 500мг	34	2026-08-27 08:45:46.766214+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766214+00	\N	\N	f
fe4a6024-22d3-4a6b-a22e-0119543a5b87	Спирт етиловий 70%	213	2026-05-25 08:45:46.766173+00	25	1	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766173+00	\N	\N	f
fe8e39a5-1268-455a-b587-abcf9de25aa3	Преднізолон 30мг	6	2025-11-06 08:45:46.766183+00	1	4	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766183+00	\N	\N	f
ff88211c-2447-47b0-80af-b5c56f8110ba	Серветки спиртові	5	2025-12-14 08:45:46.766154+00	1	5	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766154+00	\N	\N	f
004123d9-da9e-44a4-835f-b0835b6341c3	Бинт марлевий (упаковка)	4	2027-09-01 08:45:44.002274+00	1	5	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002275+00	\N	\N	f
01444b67-343e-4fd3-a6d6-09f490a98b4f	Лоратадин 10мг	18	2026-03-10 08:45:44.002406+00	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002406+00	\N	\N	f
03aea17e-6a6e-46ca-890f-16af45bfa024	Спирт етиловий 70%	110	2026-05-22 08:45:44.002293+00	25	1	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002293+00	\N	\N	f
03fa76c4-7e3a-451d-ba64-c432f6c63f06	Цитрамон	57	2026-10-09 08:45:44.002331+00	2	3	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002332+00	\N	\N	f
07362f39-4fea-4433-8bb7-ecfd1b867b1d	Бинт марлевий (упаковка)	9	2027-08-16 08:45:44.002335+00	1	5	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002335+00	\N	\N	f
075220b4-36c0-46f5-80ee-9f40e375a078	Амоксицилін 500мг	24	2025-10-20 08:45:44.002305+00	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002305+00	\N	\N	f
08bccedd-4f63-425f-b87a-cf7b62d9d726	Цитрамон	40	2026-12-06 08:45:44.002335+00	2	3	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002335+00	\N	\N	f
08dd8109-1860-46f2-9ea6-5a51f3c32bd7	Активоване вугілля	24	2026-06-23 08:45:44.002388+00	5	3	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002388+00	\N	\N	f
099e15d7-94aa-4e29-92ea-4dab1a655247	Марля медична	405	2027-06-10 08:45:44.002416+00	25	2	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002416+00	\N	\N	f
09c95d69-5f83-4d3b-9a4c-4facf0d50b2e	Нітрогліцерин	34	2026-05-25 08:45:44.002289+00	5	3	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00229+00	\N	\N	f
0ad40dd5-cf5e-4cf6-a810-151c07041848	Диклофенак 50мг	22	2026-05-08 08:45:44.002389+00	2	3	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002389+00	\N	\N	f
0c1d6647-25d2-4eb7-aa7b-8426a50bce78	Но-шпа 40мг	43	2027-05-02 08:45:44.002238+00	2	3	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002238+00	\N	\N	f
0c9bd2b1-981a-4344-8939-2802f176130b	Корвалол	30	2026-06-08 08:45:44.002266+00	6	1	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002267+00	\N	\N	f
0da2025d-92c2-4742-b56c-b0c1ed28a7d1	Шприц одноразовий 10мл	35	2026-06-30 08:45:44.002387+00	2	0	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002387+00	\N	\N	f
0fcd89d3-51ae-43d6-b430-ebddee6e9f11	Хлоргексидин 0.05%	375	2026-12-29 08:45:44.002279+00	25	1	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002279+00	\N	\N	f
0fddb16a-63a3-4ec8-81b1-553f9324fca9	Бинт стерильний 5м×10см	6	2026-04-05 08:45:44.002276+00	1	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002276+00	\N	\N	f
0fdf64ef-f42b-4d8e-9a7c-76222293a6d8	Лоратадин 10мг	23	2026-08-08 08:45:44.002318+00	2	3	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002318+00	\N	\N	f
118683ab-2b96-4f2a-9cfe-b45fa43ecd0b	Бинт марлевий (упаковка)	9	2026-11-17 08:45:44.002403+00	1	5	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002404+00	\N	\N	f
12be8eae-247a-4381-bcf5-5d804f0d4257	Папаверин 2%	15	2025-11-02 08:45:44.002303+00	1	4	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002304+00	\N	\N	f
13831a8f-c37a-4b13-84a5-cd715a40c877	Кеторолак 10мг	16	2026-06-30 08:45:44.002405+00	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002405+00	\N	\N	f
13f5984d-5f90-470d-aedc-c1a6fd736526	Бісептол 480мг	18	2026-01-29 08:45:44.002309+00	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002309+00	\N	\N	f
16782a21-ed1c-4bad-bf22-9f3b8ae438f0	Бинт еластичний	9	2027-12-18 08:45:44.002293+00	1	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002294+00	\N	\N	f
19064785-3d85-4bdb-9167-4357e132695e	Анальгін 500мг	16	2026-04-13 08:45:44.002309+00	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00231+00	\N	\N	f
1b153f24-72bf-4f85-9c1b-e9cecc39879f	Вата стерильна	283	2026-04-04 08:45:44.002373+00	12	2	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002374+00	\N	\N	f
1c2c9645-aa0f-4700-b87a-f3f5a030a9e1	Активоване вугілля	80	2027-11-30 08:45:44.002421+00	5	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002421+00	\N	\N	f
1e38ebe5-ec0b-44fc-b83b-5627dadd8bfc	Лоперамід	30	2027-01-14 08:45:44.002256+00	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002257+00	\N	\N	f
1f2cfc01-3399-456a-8438-57cf943705f9	Лоперамід	30	2028-01-28 08:45:44.002386+00	2	3	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002386+00	\N	\N	f
1fb41810-c9b4-4519-96cb-f3cdc059a580	Кеторолак 10мг	24	2026-06-22 08:45:44.002239+00	2	3	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002239+00	\N	\N	f
21d1099c-5fd5-4c99-901e-03877c58e8d8	Корвалол	45	2026-05-09 08:45:44.002306+00	6	1	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002306+00	\N	\N	f
21e58b43-3fec-4e86-b120-2b9b75e5909d	Лоперамід	16	2027-01-11 08:45:44.002418+00	2	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002419+00	\N	\N	f
2240894c-d4e0-401a-aa6a-cb3458fe85ea	Папаверин 2%	21	2026-03-17 08:45:44.002372+00	1	4	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002372+00	\N	\N	f
2266d7cb-cb34-4644-9cce-4ad1786a4f2c	Амоксицилін 500мг	20	2026-08-27 08:45:44.002363+00	2	3	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002364+00	\N	\N	f
23adb9b9-ef41-4cd6-9780-05457cb27739	Фізіологічний розчин 0.9%	528	2027-02-24 08:45:44.002274+00	50	1	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002274+00	\N	\N	f
241eae20-d8dc-4a75-9d89-669f91b42187	Бинт еластичний	5	2026-04-29 08:45:44.002409+00	1	0	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002409+00	\N	\N	f
24a8727c-8825-4c94-b560-cb65b2d08eea	Рукавички медичні	168	2027-11-22 08:45:44.002409+00	5	0	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00241+00	\N	\N	f
24fb85c7-deab-45dd-a91c-00cf2be723fb	Корвалол	32	2027-01-08 08:45:44.00233+00	6	1	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00233+00	\N	\N	f
26b35690-76bf-42f6-8085-231556257f88	Папаверин 2%	20	2027-03-18 08:45:44.002417+00	1	4	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002418+00	\N	\N	f
26f2e464-79e9-456e-bad3-945074d3743f	Шприц одноразовий 10мл	42	2027-03-27 08:45:44.00234+00	2	0	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00234+00	\N	\N	f
282d019a-463b-4609-ae16-4e3af6457a05	Анальгін 50% (амп.)	12	2026-06-15 08:45:44.002401+00	1	4	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002401+00	\N	\N	f
292e6569-6764-444a-9f0c-e4bddeb97e34	Адреналін 0.1%	17	2026-03-05 08:45:44.002311+00	1	4	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002311+00	\N	\N	f
294ad8f5-7860-4275-8a1c-2b6561d7fcb9	Дексаметазон 4мг	7	2027-05-19 08:45:44.002312+00	1	4	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002312+00	\N	\N	f
2d6eb43d-c162-4ebc-9f6e-988da9dff5e1	Дексаметазон 4мг	12	2026-12-14 08:45:44.002351+00	1	4	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002362+00	\N	\N	f
2ec5475e-88c8-4ca9-886e-f482f1456883	Перекис водню 3%	246	2026-04-27 08:45:44.002365+00	25	1	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002365+00	\N	\N	f
2eff18c9-c6b0-4719-b5c1-1de824a9677b	Диклофенак 50мг	10	2027-02-11 08:45:44.002316+00	2	3	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002316+00	\N	\N	f
2f62627c-2106-4045-b6c3-54a05c9ea63d	Нітрогліцерин	47	2026-05-21 08:45:44.002258+00	5	3	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002258+00	\N	\N	f
313cf547-1629-4e68-b4f8-63fd44be2387	Бісептол 480мг	17	2027-02-12 08:45:44.002379+00	2	3	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002379+00	\N	\N	f
327df7a0-c111-40c1-b090-805628352a18	Нітрогліцерин	25	2025-12-04 08:45:44.002365+00	5	3	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002366+00	\N	\N	f
3291768e-2a32-421e-acc1-50822250f4b5	Вата стерильна	94	2026-06-13 08:45:44.002289+00	12	2	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002289+00	\N	\N	f
3326b07a-dab1-4fe1-bdc0-134e44838810	Розчин йоду 5%	57	2027-07-13 08:45:44.002331+00	6	1	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002331+00	\N	\N	f
337b2a0c-88b8-4dd2-a266-1675fb834dc6	Бісептол 480мг	35	2026-11-10 08:45:44.002264+00	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002264+00	\N	\N	f
3547b082-f47c-436c-b7e8-18086005db28	Цитрамон	40	2027-03-03 08:45:44.002345+00	2	3	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002345+00	\N	\N	f
35b92a63-46c0-4d66-a880-62e1c9659770	Вата стерильна	400	2026-06-25 08:45:44.002422+00	12	2	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002423+00	\N	\N	f
37176239-0325-44ad-869b-9758fecbe658	Дімедрол 1%	19	2027-01-18 08:45:44.002318+00	1	4	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002318+00	\N	\N	f
37736404-1711-42f0-b47d-fe0659717da1	Лоратадин 10мг	17	2027-05-21 08:45:44.002172+00	2	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002173+00	\N	\N	f
3984135d-22e9-4af3-8d77-6700acabe9ae	Бісептол 480мг	17	2026-06-05 08:45:44.002401+00	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002401+00	\N	\N	f
3a079e35-e62b-403c-97b3-3822cfc83ccc	Бинт стерильний 5м×10см	19	2027-12-01 08:45:44.002338+00	1	0	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002339+00	\N	\N	f
3a08f2ea-3467-4cc0-b8d5-71e12ae54042	Перекис водню 3%	138	2026-06-25 08:45:44.002262+00	25	1	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002263+00	\N	\N	f
3a4d412f-70fb-4b61-b59d-fffcec83c6d0	Дімедрол 1%	17	2025-11-04 08:45:44.002376+00	1	4	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002376+00	\N	\N	f
3adc2a2d-44c9-4a48-898c-f0577b2d223b	Перекис водню 3%	460	2026-12-12 08:45:44.002238+00	25	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002238+00	\N	\N	f
3b28fe0c-764f-4e3b-9788-963663fa32dd	Но-шпа 40мг	34	2026-02-08 08:45:44.002338+00	2	3	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002338+00	\N	\N	f
3ca837ee-2748-404e-9d40-996d0f7a82a9	Фізіологічний розчин 0.9%	675	2028-01-13 08:45:44.00242+00	50	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002421+00	\N	\N	f
3e9896e5-6ffe-478c-8162-59c2a46cdfcf	Атропін 0.1%	6	2026-06-17 08:45:44.002408+00	1	4	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002409+00	\N	\N	f
3f4d6a66-7087-461a-86e3-7985e5c4bb67	Дексаметазон 4мг	7	2027-12-31 08:45:44.00228+00	1	4	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00228+00	\N	\N	f
414ed2f5-1a3c-4ecf-b942-24e8b74e5327	Амоксицилін 500мг	15	2026-04-30 08:45:44.002418+00	2	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002418+00	\N	\N	f
46c9d85a-3075-49bf-b301-9a5685faeec0	Бинт еластичний	14	2027-07-30 08:45:44.002422+00	1	0	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002422+00	\N	\N	f
46cd16eb-54cf-49ec-9310-be26cbfa5485	Серветки спиртові	8	2026-04-27 08:45:44.002406+00	1	5	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002406+00	\N	\N	f
479cfe7d-fc01-4068-a7eb-b4552c6294ba	Папаверин 2%	9	2027-07-26 08:45:44.002317+00	1	4	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002317+00	\N	\N	f
4948eb70-3623-479f-aed0-2b19d6664caa	Розчин брильянтового зеленого	32	2027-11-03 08:45:44.002238+00	6	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002239+00	\N	\N	f
49c6f840-d59c-43b3-b829-406d9e38f224	Преднізолон 30мг	25	2025-11-30 08:45:44.002408+00	1	4	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002408+00	\N	\N	f
4ac55a8c-431c-4d8b-9558-bdcdbee2f071	Шприц одноразовий 10мл	36	2026-06-03 08:45:44.002363+00	2	0	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002363+00	\N	\N	f
4b70137d-de97-4050-83d3-4da8ef1f4988	Но-шпа 40мг	25	2025-12-16 08:45:44.002376+00	2	3	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002377+00	\N	\N	f
4bf9efc1-269b-4216-b1a8-9927b22da014	Розчин брильянтового зеленого	35	2027-01-28 08:45:44.00242+00	6	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00242+00	\N	\N	f
4c4b880d-3901-4187-a738-d7251867c420	Перекис водню 3%	157	2026-02-23 08:45:44.002223+00	25	1	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002224+00	\N	\N	f
50ad4a1c-0534-402f-9e1e-15ab1ea2fac6	Супрастин 25мг	14	2026-05-26 08:45:44.002411+00	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002411+00	\N	\N	f
5119e0ba-7a04-43e0-aef9-d2a53ad37d25	Валідол	13	2026-05-04 08:45:44.002239+00	2	3	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00224+00	\N	\N	f
51a2137a-037b-47e3-82d5-d08116bfeaef	Рукавички медичні	138	2027-10-09 08:45:44.002273+00	5	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002274+00	\N	\N	f
5279ac23-4749-4ba5-8f57-3de172b96a9b	Джгут гумовий	9	2025-11-06 08:45:44.002307+00	1	0	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002308+00	\N	\N	f
529250a7-8bcb-4887-83c3-2572dc16388a	Вата стерильна	358	2027-03-04 08:45:44.002236+00	12	2	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002236+00	\N	\N	f
529b6882-6db6-44de-b550-7ea88fcb0a0f	Лейкопластир бактерицидний	14	2025-10-22 08:45:44.002371+00	2	0	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002371+00	\N	\N	f
5493b3bf-e462-47f7-90a5-9f8692b62104	Шприц одноразовий 5мл	25	2027-11-15 08:45:44.002364+00	2	0	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002364+00	\N	\N	f
55621e47-0d20-4a03-8a05-79f4601abec9	Шприц одноразовий 5мл	19	2026-04-20 08:45:44.002222+00	2	0	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002222+00	\N	\N	f
557e0a2a-e3cd-4a0d-a9cb-485230ff51f4	Супрастин 25мг	13	2026-06-08 08:45:44.002349+00	2	3	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00235+00	\N	\N	f
57975853-7e14-43ed-9114-2afd600a67a3	Хлоргексидин 0.05%	407	2027-01-30 08:45:44.002175+00	25	1	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002176+00	\N	\N	f
583f8ea5-fbef-40d7-82ea-4a19d5cd34b4	Аспірин 500мг	29	2026-04-29 08:45:44.00231+00	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002311+00	\N	\N	f
5941feb1-83b0-44eb-bb33-37340f4d7954	Диклофенак 50мг	24	2026-11-14 08:45:44.002207+00	2	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002207+00	\N	\N	f
599bafa3-bf33-423b-96b6-23d65af29889	Нітрогліцерин	41	2027-09-06 08:45:44.002375+00	5	3	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002376+00	\N	\N	f
59b546bf-ca5f-448f-b5a8-52e586169d98	Лейкопластир бактерицидний	35	2025-12-07 08:45:44.002292+00	2	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002293+00	\N	\N	f
59bb9288-ff7d-4118-b577-327ced88953c	Рукавички медичні	41	2026-06-30 08:45:44.002372+00	5	0	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002372+00	\N	\N	f
5a9e5599-f39a-49b4-9f02-78a161409e40	Активоване вугілля	82	2026-12-23 08:45:44.002304+00	5	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002304+00	\N	\N	f
5bab2428-d408-40fc-bcda-c7afe7b98146	Перекис водню 3%	424	2028-01-24 08:45:44.002319+00	25	1	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002319+00	\N	\N	f
5e6d34a9-9dcb-4e1d-9557-501091029eec	Дімедрол 1%	9	2027-08-23 08:45:44.002348+00	1	4	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002348+00	\N	\N	f
5ee76eed-e917-433a-9e99-0be7cff6f311	Розчин брильянтового зеленого	54	2027-04-12 08:45:44.002258+00	6	1	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002259+00	\N	\N	f
5f05caee-6a7d-4560-9e13-4d9ad3957a06	Аспірин 500мг	16	2027-05-28 08:45:44.00232+00	2	3	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00232+00	\N	\N	f
6196a0b0-34b7-4087-b8e2-f99f1180d6ff	Аспірин 500мг	33	2026-05-27 08:45:44.002277+00	2	3	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002278+00	\N	\N	f
63a7e677-2454-4a37-a490-600fff850fc3	Кеторолак 10мг	21	2027-11-13 08:45:44.002322+00	2	3	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00233+00	\N	\N	f
65d06662-ebaf-4938-99ee-cb8ba68752c5	Лейкопластир бактерицидний	35	2026-04-26 08:45:44.002225+00	2	0	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002225+00	\N	\N	f
66c1c04f-fe6f-454c-82f9-c1bb8f8ddd95	Шприц одноразовий 5мл	24	2027-11-19 08:45:44.002388+00	2	0	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002388+00	\N	\N	f
670f6777-389b-4790-b3ef-658cc2679ae6	Фізіологічний розчин 0.9%	898	2028-01-19 08:45:44.002382+00	50	1	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002382+00	\N	\N	f
6773efa6-c4cb-4f76-9dfb-7661d115e6af	Дексаметазон 4мг	22	2027-10-22 08:45:44.002341+00	1	4	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002341+00	\N	\N	f
67d5a1a3-36ac-44e8-9342-265631ccb379	Шприц одноразовий 10мл	50	2025-12-03 08:45:44.002287+00	2	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002288+00	\N	\N	f
689043b3-1273-41b7-a36c-aad2e0de89c4	Розчин йоду 5%	42	2026-06-02 08:45:44.002275+00	6	1	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002275+00	\N	\N	f
69a7566e-3736-4224-9dc9-b6ef0a92cfd0	Джгут гумовий	9	2026-06-20 08:45:44.002375+00	1	0	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002375+00	\N	\N	f
6cfe63d5-f6ae-46d8-aa3b-378c036bf6dd	Аспірин 500мг	36	2027-09-24 08:45:44.002179+00	2	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.0022+00	\N	\N	f
6cff342a-623a-42a3-a549-fbfdb6899e03	Бинт стерильний 5м×10см	8	2026-04-05 08:45:44.002406+00	1	0	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002407+00	\N	\N	f
6df1e2eb-8e07-4ff0-9ec5-d33758bb7ad9	Лейкопластир бактерицидний	27	2027-11-03 08:45:44.002351+00	2	0	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002351+00	\N	\N	f
729b8b39-1b02-4d5c-a7e9-67369f05525d	Папаверин 2%	5	2026-05-15 08:45:44.002169+00	1	4	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00217+00	\N	\N	f
73cb2265-a3cb-42ab-9ce7-188616fc0df9	Лейкопластир бактерицидний	41	2026-05-25 08:45:44.002408+00	2	0	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002408+00	\N	\N	f
741de159-bc8f-45f8-90ca-bc39b8869fcc	Атропін 0.1%	17	2026-06-11 08:45:44.002336+00	1	4	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002336+00	\N	\N	f
743167f2-c4b7-4753-a30b-0556e93fd80d	Серветки спиртові	4	2026-11-18 08:45:44.002221+00	1	5	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002221+00	\N	\N	f
78a23a0a-6a3e-4ba7-b564-6955bcdb6774	Папаверин 2%	16	2027-07-30 08:45:44.002381+00	1	4	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002382+00	\N	\N	f
796436bf-5f3b-43b9-9f9b-56972f16ba36	Адреналін 0.1%	7	2027-07-20 08:45:44.00224+00	1	4	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00224+00	\N	\N	f
7b16c513-f302-4378-acf3-0aa2e6b1605e	Ібупрофен 200мг	53	2026-03-29 08:45:44.002385+00	2	3	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002385+00	\N	\N	f
7d331d64-473a-47ab-9538-9c9dd07b5fa3	Атропін 0.1%	12	2026-12-31 08:45:44.002315+00	1	4	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002315+00	\N	\N	f
7dfa7d63-33da-40df-ac17-7a5ef1d3cff9	Преднізолон 30мг	25	2026-04-17 08:45:44.002373+00	1	4	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002373+00	\N	\N	f
7f2b10bc-7a11-400f-a292-73800ef99440	Но-шпа 40мг	25	2026-12-28 08:45:44.002316+00	2	3	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002316+00	\N	\N	f
81fe1339-87a0-4b12-832e-71ea43d723bf	Корвалол	55	2026-09-30 08:45:44.002202+00	6	1	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002204+00	\N	\N	f
838f4c45-5431-4d92-96e5-af351295a136	Шприц одноразовий 5мл	28	2026-06-24 08:45:44.002206+00	2	0	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002206+00	\N	\N	f
84090460-691d-4ddc-8568-e3a3c54c1012	Джгут гумовий	10	2026-06-11 08:45:44.002416+00	1	0	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002417+00	\N	\N	f
84559c67-cb37-4192-b63f-65e107d91f76	Лейкопластир бактерицидний	19	2027-03-04 08:45:44.00233+00	2	0	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002331+00	\N	\N	f
84eda8f0-20ac-4a20-b5d3-5763afa68355	Бісептол 480мг	14	2028-02-11 08:45:44.002316+00	2	3	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002317+00	\N	\N	f
85b54730-d064-4c84-a55c-64d11e4ccce3	Шприц одноразовий 10мл	38	2026-01-19 08:45:44.002404+00	2	0	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002404+00	\N	\N	f
85ef0e79-fe06-443a-b57f-68fd67e6e0c3	Серветки спиртові	8	2027-01-04 08:45:44.002321+00	1	5	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002321+00	\N	\N	f
85fcd467-c278-4e7d-9592-61519fbebbd1	Анальгін 500мг	34	2026-04-29 08:45:44.002263+00	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002264+00	\N	\N	f
87588a0e-221a-400c-864d-aa0475bbb79e	Хлоргексидин 0.05%	347	2028-03-05 08:45:44.002416+00	25	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002416+00	\N	\N	f
875c0cf0-cf1b-4ce7-9c90-408359bc91c6	Хлоргексидин 0.05%	147	2026-04-15 08:45:44.002306+00	25	1	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002306+00	\N	\N	f
87f7ac5d-86ec-45bb-9607-3c7fdd9c433d	Спирт етиловий 70%	477	2026-09-12 08:45:44.002237+00	25	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002238+00	\N	\N	f
8ae7590a-b59f-47fb-b5f9-88f6de030472	Анальгін 50% (амп.)	20	2026-05-02 08:45:44.002374+00	1	4	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002374+00	\N	\N	f
8c551dcd-e9a5-4b31-8185-824b9be97430	Аспірин 500мг	22	2026-05-07 08:45:44.002405+00	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002405+00	\N	\N	f
8df1e150-a7b0-480b-8aa7-f9fcfa41a8be	Дімедрол 1%	23	2026-11-25 08:45:44.002204+00	1	4	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002205+00	\N	\N	f
8e30e1c4-5073-4b8f-adbd-045d43e5502e	Бинт еластичний	14	2026-02-21 08:45:44.002311+00	1	0	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002312+00	\N	\N	f
8e7b5081-c612-415b-9465-47725cb627be	Перекис водню 3%	407	2027-06-17 08:45:44.002419+00	25	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00242+00	\N	\N	f
90aa9336-d3e2-462a-960a-409a548b0a7a	Марля медична	497	2027-05-19 08:45:44.00233+00	25	2	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00233+00	\N	\N	f
92c348eb-f762-4b56-b8a0-1c66beecbda4	Серветки спиртові	5	2026-05-10 08:45:44.002306+00	1	5	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002307+00	\N	\N	f
955cf93c-b869-4c5f-b3c0-c90d3a9fc37d	Корвалол	56	2026-07-07 08:45:44.002423+00	6	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002423+00	\N	\N	f
96612033-9c4a-4ea4-a0fd-f7868fdabf6f	Ібупрофен 200мг	59	2027-10-18 08:45:44.00231+00	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00231+00	\N	\N	f
979e2b8b-ec16-4300-b3a5-cab2c69d922d	Парацетамол 500мг	43	2026-05-18 08:45:44.002417+00	2	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002417+00	\N	\N	f
97bec24f-e7d3-408e-958c-cbdde40a4fc0	Фізіологічний розчин 0.9%	458	2027-11-23 08:45:44.002266+00	50	1	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002266+00	\N	\N	f
9a19d600-c5aa-404b-8002-81513a4fbf89	Диклофенак 50мг	35	2026-05-08 08:45:44.002277+00	2	3	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002277+00	\N	\N	f
9b5d7c32-68d0-4eb4-8880-c694ec7fb282	Лоперамід	29	2026-05-03 08:45:44.002336+00	2	3	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002336+00	\N	\N	f
9c6f1e5e-2280-4020-9cb3-793770b2d05b	Серветки спиртові	1	2026-05-04 08:45:44.002421+00	1	5	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002421+00	\N	\N	f
9d13e948-5a06-4e4d-86bc-71621f42d262	Розчин брильянтового зеленого	81	2026-04-18 08:45:44.002407+00	6	1	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002407+00	\N	\N	f
9e051a78-6bed-4ef0-9379-824df5effd4c	Маска медична	77	2025-10-12 08:45:44.002278+00	5	0	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002279+00	\N	\N	f
9e7bb858-741a-4b7f-bc15-d08512e70bb5	Бісептол 480мг	12	2026-10-20 08:45:44.001619+00	2	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002163+00	\N	\N	f
9e9653aa-c8f1-422f-b5d6-dc266fa1efa0	Адреналін 0.1%	9	2027-01-06 08:45:44.002225+00	1	4	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002225+00	\N	\N	f
9f10c23b-480a-4022-aafd-70192acac43e	Спирт етиловий 70%	500	2027-02-04 08:45:44.002319+00	25	1	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002319+00	\N	\N	f
a29ab445-96e3-44e4-afcd-344aece9fb07	Бинт марлевий (упаковка)	3	2026-11-30 08:45:44.002377+00	1	5	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002378+00	\N	\N	f
a30b25f1-d00c-469b-a773-47b3b54f017c	Розчин брильянтового зеленого	62	2027-05-15 08:45:44.00235+00	6	1	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00235+00	\N	\N	f
a393ce0a-d9d2-48b6-ae94-2a9124265548	Магнію сульфат 25%	22	2026-04-26 08:45:44.002305+00	1	4	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002305+00	\N	\N	f
a4cef153-db9f-4908-a2fd-4671883e20be	Розчин йоду 5%	65	2026-11-07 08:45:44.002207+00	6	1	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002208+00	\N	\N	f
a4f9de98-93a3-45b6-a5eb-78f9bd604a35	Анальгін 500мг	18	2026-09-17 08:45:44.002339+00	2	3	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002339+00	\N	\N	f
a5752622-9bf1-4239-9058-5e94203d9e7a	Маска медична	102	2026-04-20 08:45:44.002337+00	5	0	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002338+00	\N	\N	f
a603f4b6-a904-44e2-9746-f51ecacd7a27	Ібупрофен 200мг	72	2026-12-22 08:45:44.002421+00	2	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002422+00	\N	\N	f
a7d1147c-5389-4886-8fd8-f5b1cde2041c	Преднізолон 30мг	5	2026-04-13 08:45:44.002342+00	1	4	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002342+00	\N	\N	f
a824d4ab-b3cb-4f07-9856-4d97159f4080	Анальгін 50% (амп.)	10	2026-04-18 08:45:44.002387+00	1	4	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002388+00	\N	\N	f
a8320ab9-dc70-4dc3-8b65-4db54bd6f458	Хлоргексидин 0.05%	483	2027-06-09 08:45:44.002237+00	25	1	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002237+00	\N	\N	f
a8d103c6-957f-4b54-bd5c-63dbf561a54d	Шприц одноразовий 10мл	31	2026-03-23 08:45:44.002235+00	2	0	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002236+00	\N	\N	f
a988ed32-061a-4c72-8bad-646fb52353e5	Розчин йоду 5%	43	2026-01-14 08:45:44.002423+00	6	1	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002423+00	\N	\N	f
aa59ac1a-6aa3-4208-a878-465dab632a8f	Хлоргексидин 0.05%	352	2027-12-10 08:45:44.002378+00	25	1	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002378+00	\N	\N	f
aae59774-de93-4e00-b9fe-01e911b12522	Папаверин 2%	11	2025-11-22 08:45:44.002261+00	1	4	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002262+00	\N	\N	f
addba8eb-6505-44f5-8500-e6c86ffa8fa8	Магнію сульфат 25%	21	2026-06-07 08:45:44.002224+00	1	4	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002224+00	\N	\N	f
aed99426-45ce-4dce-ac86-8709f4b96f3e	Дексаметазон 4мг	14	2027-04-17 08:45:44.002407+00	1	4	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002408+00	\N	\N	f
af0a7652-192d-4e56-898f-d365bc56b658	Корвалол	27	2026-08-18 08:45:44.002385+00	6	1	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002386+00	\N	\N	f
afa71bbc-d4ab-494f-a060-2800d2c38e17	Перекис водню 3%	405	2026-04-26 08:45:44.002308+00	25	1	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002308+00	\N	\N	f
b00abe4f-6c25-494e-88ab-87a8fde057e8	Спирт етиловий 70%	325	2028-03-29 08:45:44.002309+00	25	1	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002309+00	\N	\N	f
b1875cd8-b5c9-4aad-8618-d28a36826000	Марля медична	181	2027-02-19 08:45:44.00224+00	25	2	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002241+00	\N	\N	f
b18bfaf8-6489-4606-97be-941292a4d0f8	Диклофенак 50мг	10	2025-11-22 08:45:44.00241+00	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002411+00	\N	\N	f
b287d6aa-81cc-424e-8066-f6542a1bc3a6	Диклофенак 50мг	28	2026-05-26 08:45:44.00226+00	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00226+00	\N	\N	f
b39bf60a-69d6-45fb-93cc-56d0e2a5245b	Папаверин 2%	15	2025-11-27 08:45:44.002222+00	1	4	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002222+00	\N	\N	f
b4163753-bacf-450b-9afd-c5ae92fe5582	Парацетамол 500мг	27	2027-04-25 08:45:44.002205+00	2	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002206+00	\N	\N	f
b6c4a5c8-bc25-49cc-a479-ca45c9c744a6	Спирт етиловий 70%	382	2027-04-25 08:45:44.002261+00	25	1	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002261+00	\N	\N	f
b825b710-041f-453b-ac5b-2804f8a71339	Маска медична	148	2026-06-17 08:45:44.002178+00	5	0	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002179+00	\N	\N	f
b9b90151-485e-4bc9-a42f-a636c90ef842	Анальгін 50% (амп.)	24	2026-04-15 08:45:44.00229+00	1	4	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002291+00	\N	\N	f
ba1659ea-7910-42b9-811e-a66bcb9607e6	Ібупрофен 200мг	10	2026-05-04 08:45:44.002291+00	2	3	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002291+00	\N	\N	f
ba620a1f-c614-4a9f-9d9a-4aa82d95a4dd	Розчин брильянтового зеленого	91	2026-06-24 08:45:44.002226+00	6	1	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002226+00	\N	\N	f
ba6ef5b1-ac65-40ef-b171-8a74bae96b5a	Супрастин 25мг	11	2026-05-02 08:45:44.002303+00	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002303+00	\N	\N	f
bae1014f-38ba-42f0-9ef5-afe31f73a219	Лоратадин 10мг	17	2025-12-16 08:45:44.002221+00	2	3	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002221+00	\N	\N	f
bb0e097d-3a7a-419a-b18f-d1fb5da6f484	Джгут гумовий	9	2027-12-07 08:45:44.002321+00	1	0	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002321+00	\N	\N	f
bc934a6d-19a1-4796-bb96-a815920bc07d	Перекис водню 3%	342	2026-09-18 08:45:44.002338+00	25	1	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002338+00	\N	\N	f
bd43a912-f195-4493-afad-de75350e38b3	Дімедрол 1%	8	2026-06-12 08:45:44.002336+00	1	4	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002337+00	\N	\N	f
be21c96c-b6db-4cb7-beb8-ed6443957b1d	Марля медична	381	2025-11-20 08:45:44.002403+00	25	2	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002403+00	\N	\N	f
bff1f666-d4d4-4de0-b3f4-333eae2a3763	Шприц одноразовий 5мл	40	2028-01-08 08:45:44.002319+00	2	0	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00232+00	\N	\N	f
c007d37d-3a5b-407e-b2b0-54b27a3394b5	Розчин брильянтового зеленого	99	2026-03-10 08:45:44.002375+00	6	1	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002375+00	\N	\N	f
c0672919-b270-4097-bf62-150f0a2eb897	Цитрамон	48	2026-05-05 08:45:44.002372+00	2	3	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002373+00	\N	\N	f
c181872c-02b7-4bda-9f08-ffd2e27d7d0f	Папаверин 2%	23	2027-12-21 08:45:44.00241+00	1	4	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00241+00	\N	\N	f
c1cac15d-69b2-4d85-9222-af30c61a9bcb	Кеторолак 10мг	35	2025-12-22 08:45:44.00222+00	2	3	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00222+00	\N	\N	f
c1df74ea-caea-496c-8a30-02923108dd6b	Хлоргексидин 0.05%	156	2027-12-18 08:45:44.002341+00	25	1	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002342+00	\N	\N	f
c2773ede-36d7-4599-9eb2-c59afda3bcfd	Маска медична	72	2027-06-03 08:45:44.002308+00	5	0	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002308+00	\N	\N	f
c2caeb3d-77b6-4598-8292-873561a7c762	Розчин йоду 5%	70	2026-06-20 08:45:44.00237+00	6	1	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00237+00	\N	\N	f
c39fdca4-180f-468e-8ed2-fefb410fdb37	Ібупрофен 200мг	62	2027-10-03 08:45:44.002265+00	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002265+00	\N	\N	f
c50f2bec-068e-46e5-868e-a4dda02f0c08	Маска медична	35	2026-10-20 08:45:44.00232+00	5	0	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00232+00	\N	\N	f
c623779b-9659-46fc-b58a-84ce6b8c824a	Бинт стерильний 5м×10см	5	2026-06-18 08:45:44.002223+00	1	0	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002223+00	\N	\N	f
c72bf8de-2825-4325-baf6-edf30e2155da	Лейкопластир бактерицидний	47	2027-03-23 08:45:44.002419+00	2	0	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002419+00	\N	\N	f
c7829388-5a4b-47fb-8501-a66d1c151159	Перекис водню 3%	187	2026-04-27 08:45:44.002384+00	25	1	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002384+00	\N	\N	f
c8df7e63-04de-4ad6-9a67-cc4e645f1dc5	Активоване вугілля	35	2026-08-08 08:45:44.002176+00	5	3	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002177+00	\N	\N	f
cccf6d56-57b0-4cb6-9189-fc21e206aae3	Магнію сульфат 25%	13	2028-01-16 08:45:44.002276+00	1	4	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002276+00	\N	\N	f
cf2898c4-32d8-41a7-931b-671259febe3a	Спирт етиловий 70%	157	2026-02-27 08:45:44.002411+00	25	1	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002411+00	\N	\N	f
d0466017-bf0c-40e4-9698-ac0e559c8c1a	Бинт стерильний 5м×10см	22	2028-02-08 08:45:44.002317+00	1	0	2f24781b-5362-408d-8677-8bdd2751e5ec	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002317+00	\N	\N	f
d1365496-329f-4a7c-bf2a-ade7ce1cd95c	Но-шпа 40мг	45	2027-04-19 08:45:44.002414+00	2	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002415+00	\N	\N	f
d1ab5afd-93f8-4dcb-ae42-8f9053782853	Диклофенак 50мг	38	2026-11-28 08:45:44.002304+00	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002305+00	\N	\N	f
d330fb74-43df-486d-9a68-6c2dc4b8fb2c	Бісептол 480мг	22	2027-09-03 08:45:44.002415+00	2	3	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002415+00	\N	\N	f
d36a6005-c434-4a17-90c5-6e0e2fd0536a	Нітрогліцерин	25	2026-05-31 08:45:44.002341+00	5	3	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002341+00	\N	\N	f
d395f736-8519-49a9-be44-de3229a25b0b	Вата стерильна	219	2027-03-28 08:45:44.002384+00	12	2	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002384+00	\N	\N	f
d501a411-9fa8-4f83-a9f4-c466d264f686	Бинт марлевий (упаковка)	4	2026-06-24 08:45:44.002345+00	1	5	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002345+00	\N	\N	f
d86b9e9b-b34a-4b42-8824-f968f585ceec	Перекис водню 3%	282	2026-09-14 08:45:44.002374+00	25	1	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002374+00	\N	\N	f
d87fd0ce-59a2-489e-8f39-667179bba8ac	Корвалол	80	2026-03-06 08:45:44.002403+00	6	1	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002403+00	\N	\N	f
d986535e-8453-4e47-8278-5ae9af768a2d	Адреналін 0.1%	12	2026-12-28 08:45:44.002418+00	1	4	2e84553d-2b1d-4dc9-bf85-46c9c85434e9	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002418+00	\N	\N	f
da3b80d5-12a6-4575-b473-f98b64821d41	Нітрогліцерин	28	2026-04-17 08:45:44.002404+00	5	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002405+00	\N	\N	f
da90d1ca-be53-4513-be71-3dd70534c397	Марля медична	293	2027-11-02 08:45:44.002339+00	25	2	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.00234+00	\N	\N	f
db9e06ff-327d-418f-acf8-2ee075e3fd4e	Ібупрофен 200мг	30	2027-09-01 08:45:44.002402+00	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002402+00	\N	\N	f
dfa00429-c123-431d-af0e-46a3e70ddaa5	Преднізолон 30мг	14	2027-06-05 08:45:44.002383+00	1	4	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002383+00	\N	\N	f
e04e2de0-c190-4c3b-bada-a343b2c170d5	Но-шпа 40мг	18	2028-01-14 08:45:44.002265+00	2	3	3022448e-a09d-4689-8d1d-a4594b5d9102	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002266+00	\N	\N	f
e28fc7aa-30f0-4057-9740-b70763614bec	Корвалол	43	2026-09-14 08:45:44.002346+00	6	1	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002346+00	\N	\N	f
e40b1998-83b7-44a1-8b5d-91b04f2b9f7c	Бинт марлевий (упаковка)	7	2026-12-18 08:45:44.002236+00	1	5	e21fcfed-c37a-4190-adf2-c7aa8ea7c264	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002237+00	\N	\N	f
e86064b1-5c3f-4300-91e4-cb1a0f6a5218	Дімедрол 1%	12	2026-10-05 08:45:44.002383+00	1	4	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002384+00	\N	\N	f
e8b4fda5-d55a-45f4-9ee0-456ef3956cb2	Корвалол	93	2026-05-04 08:45:44.002371+00	6	1	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002371+00	\N	\N	f
ea0d57f7-7d83-4df3-b23b-8cda905c3046	Лоперамід	12	2026-04-14 08:45:44.002307+00	2	3	afe653db-7e14-40c9-8758-0bf4babdf69e	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002307+00	\N	\N	f
ea0ffb42-a3de-4fc8-8bb3-d8afa962bf92	Спирт етиловий 70%	113	2026-05-26 08:45:44.002346+00	25	1	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002346+00	\N	\N	f
eaf3341a-dced-40a6-a132-a1ec9f64246a	Кеторолак 10мг	22	2028-03-26 08:45:44.002295+00	2	3	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002295+00	\N	\N	f
eb9ad785-b0ec-48e3-8c30-48198e8c41b2	Валідол	11	2026-06-26 08:45:44.002402+00	2	3	c36d1c0c-34aa-4bcf-a542-15964da77279	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002402+00	\N	\N	f
ed22f0b5-285d-4a86-abcc-ad290f2a4b28	Спирт етиловий 70%	461	2027-04-09 08:45:44.002209+00	25	1	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002209+00	\N	\N	f
ef04c299-db73-430f-ad74-5fc182b865a0	Лоперамід	24	2026-12-08 08:45:44.002346+00	2	3	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002347+00	\N	\N	f
ef409886-4114-498c-a129-49a181852653	Валідол	29	2028-01-15 08:45:44.002348+00	2	3	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002349+00	\N	\N	f
ef69b4d1-5d06-4339-9b33-cece51a7c2f3	Спирт етиловий 70%	249	2025-12-11 08:45:44.002224+00	25	1	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002225+00	\N	\N	f
efc577c2-7909-4105-9d44-bc3f1a547172	Амоксицилін 500мг	35	2026-05-03 08:45:44.002337+00	2	3	e375ca95-635b-4ca3-b762-27a950bdd006	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002337+00	\N	\N	f
f1ac9421-0aa6-42fa-a19a-799a9a6ce00b	Атропін 0.1%	16	2026-05-24 08:45:44.002222+00	1	4	d7b3f772-167e-4f25-9a85-310e632a4abc	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002223+00	\N	\N	f
f1f27d38-c18d-4282-8c2e-400320457bb7	Серветки спиртові	4	2027-02-03 08:45:44.002294+00	1	5	9bd7c0ce-4ba4-4a1c-aef0-58771f35a460	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002295+00	\N	\N	f
f2114bf8-1571-4cca-a25b-4d7372be8010	Лоратадин 10мг	23	2026-06-23 08:45:44.002378+00	2	3	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002379+00	\N	\N	f
f581e02d-214c-407f-8edb-74ec8a24af83	Магнію сульфат 25%	22	2026-10-27 08:45:44.002382+00	1	4	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002383+00	\N	\N	f
f6268d54-bf5d-4e6b-990d-eca3dfa8932c	Дексаметазон 4мг	20	2028-03-01 08:45:44.002386+00	1	4	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002387+00	\N	\N	f
f760ee41-b888-41c1-8ffb-7a9c44bb6ea4	Атропін 0.1%	8	2026-03-11 08:45:44.002377+00	1	4	0944e862-db47-4840-ba45-fe2e8e8efd08	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002377+00	\N	\N	f
f774498b-b564-48cf-99eb-e763939d41f3	Нітрогліцерин	50	2026-09-07 08:45:44.002385+00	5	3	2e53fef1-346d-4743-a751-fc71275d8c0c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002385+00	\N	\N	f
fe37c5c4-5c66-423a-b79b-f2ee02038d6f	Диклофенак 50мг	12	2027-09-14 08:45:44.002347+00	2	3	855c830b-fee4-4ff1-94a4-3d93122907fe	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002348+00	\N	\N	f
03b3109a-4a77-4861-a9e4-1a5dd259e446	Шприц одноразовий 10мл	31	2025-11-29 08:45:44.763488+00	2	0	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763488+00	\N	\N	f
07219566-1dcc-4473-bde2-fe4cc5297825	Нітрогліцерин	35	2026-05-09 08:45:44.763469+00	5	3	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763469+00	\N	\N	f
0956175f-ef00-4585-8c66-fb330fce6690	Спирт етиловий 70%	277	2026-09-07 08:45:44.763505+00	25	1	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763505+00	\N	\N	f
0b2ebb57-71fc-40f0-ac53-fcf244ee6464	Нітрогліцерин	30	2027-04-14 08:45:44.763511+00	5	3	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763511+00	\N	\N	f
0bc167a6-5a39-4406-936b-1384866eb90f	Корвалол	53	2026-10-02 08:45:44.763456+00	6	1	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763456+00	\N	\N	f
0d5f7a88-d136-497a-b670-83de80349fd9	Анальгін 50% (амп.)	21	2026-04-21 08:45:44.763472+00	1	4	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763472+00	\N	\N	f
0e66424d-c8ac-4c0c-8301-4a12ee58aad6	Нітрогліцерин	22	2028-03-27 08:45:44.763479+00	5	3	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763482+00	\N	\N	f
0e780448-006a-4e2e-b637-ae887a03f4e9	Анальгін 50% (амп.)	10	2026-02-17 08:45:44.76342+00	1	4	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763421+00	\N	\N	f
0eb21f62-bee6-4ca2-95fa-f49dea0ad3ed	Маска медична	121	2027-08-10 08:45:44.763476+00	5	0	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763477+00	\N	\N	f
14fc7131-99c1-412f-8613-0609c5f822ea	Розчин брильянтового зеленого	54	2026-06-19 08:45:44.763515+00	6	1	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763515+00	\N	\N	f
15ee6fdb-dc51-472d-b5f5-c9c964cd6def	Маска медична	39	2027-05-22 08:45:44.763487+00	5	0	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763487+00	\N	\N	f
16bd4788-eb45-438e-9e5f-a5d6830eba49	Лоратадин 10мг	14	2026-04-28 08:45:44.76344+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76344+00	\N	\N	f
1bc04888-e670-4f67-bc1f-d553bb287cd0	Серветки спиртові	4	2026-12-19 08:45:44.763486+00	1	5	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763486+00	\N	\N	f
1c44a8da-e3cb-4927-bc8f-6da61a81d114	Бинт еластичний	9	2027-07-17 08:45:44.763514+00	1	0	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763514+00	\N	\N	f
1d20b6c2-7f3f-4194-bbc4-6dadd8934174	Парацетамол 500мг	87	2027-05-06 08:45:44.763516+00	2	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763516+00	\N	\N	f
212508f8-7cb4-4759-b694-8333dbdde80c	Активоване вугілля	28	2027-01-10 08:45:44.763463+00	5	3	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763464+00	\N	\N	f
21360c0f-7605-4e72-9445-41f0a20b92ba	Преднізолон 30мг	18	2027-02-16 08:45:44.763449+00	1	4	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763449+00	\N	\N	f
233e0c17-654d-4ee3-8ecc-0c5eae0223ff	Серветки спиртові	1	2027-01-09 08:45:44.76345+00	1	5	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76345+00	\N	\N	f
2634e792-d3eb-41a1-9c98-5fd26a1008a2	Перекис водню 3%	121	2026-11-17 08:45:44.763494+00	25	1	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763494+00	\N	\N	f
26e62ef2-e0ba-4f3f-bf14-d0004c1de1ad	Амоксицилін 500мг	14	2028-02-22 08:45:44.763451+00	2	3	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763452+00	\N	\N	f
2751ca41-5232-42f3-906f-2f8251c5ce4e	Марля медична	482	2026-04-30 08:45:44.763476+00	25	2	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763476+00	\N	\N	f
27b7be83-3e17-476b-8438-f6af52013f3a	Атропін 0.1%	10	2027-05-22 08:45:44.763493+00	1	4	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763493+00	\N	\N	f
27f53391-a924-4751-b660-bf5a81d9a8ab	Диклофенак 50мг	40	2026-11-06 08:45:44.76344+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763441+00	\N	\N	f
2aa65471-9cb4-406a-85a3-60f79568faa4	Но-шпа 40мг	19	2027-10-10 08:45:44.763457+00	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763457+00	\N	\N	f
2e1eb683-3685-4623-a3da-c4a7d0416209	Диклофенак 50мг	27	2026-05-30 08:45:44.763486+00	2	3	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763486+00	\N	\N	f
2e399312-b4fd-4507-8e0d-fa9e74ab318b	Бісептол 480мг	26	2028-01-27 08:45:44.763509+00	2	3	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763509+00	\N	\N	f
2e84a605-9543-4222-ab91-a4eeba62eefd	Спирт етиловий 70%	359	2027-07-09 08:45:44.763464+00	25	1	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763464+00	\N	\N	f
30f7646a-1082-48aa-b77b-169815645b55	Бісептол 480мг	11	2026-06-23 08:45:44.763463+00	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763463+00	\N	\N	f
30ff64fd-088b-4c6c-8c20-2b7f4129760c	Фізіологічний розчин 0.9%	556	2025-12-22 08:45:44.763488+00	50	1	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763489+00	\N	\N	f
3121e5d5-cd07-4faa-99e7-42ba61d2af2d	Лоперамід	14	2027-04-02 08:45:44.76349+00	2	3	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76349+00	\N	\N	f
31e80991-b3f1-4ade-9c1e-2a6ba0c72bfc	Супрастин 25мг	28	2027-01-07 08:45:44.763462+00	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763462+00	\N	\N	f
322afa31-dbff-4615-87ab-aa165b94f920	Атропін 0.1%	12	2026-05-09 08:45:44.763518+00	1	4	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763519+00	\N	\N	f
340257f8-2348-44c4-9655-c80be39a79e8	Нітрогліцерин	29	2026-11-27 08:45:44.763505+00	5	3	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763506+00	\N	\N	f
342ff85c-7183-4447-b91d-346d506cc4af	Розчин брильянтового зеленого	94	2027-09-04 08:45:44.763511+00	6	1	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763511+00	\N	\N	f
34ea99c3-3d73-4750-a07e-11ff1507872f	Аспірин 500мг	14	2027-11-29 08:45:44.763505+00	2	3	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763505+00	\N	\N	f
366fb2c8-b35f-45ce-ad93-9aad90c0b002	Бинт еластичний	9	2026-04-26 08:45:44.763442+00	1	0	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763442+00	\N	\N	f
38f234be-5a16-451d-a037-eb1a8981aa0d	Папаверин 2%	23	2028-02-28 08:45:44.763441+00	1	4	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763441+00	\N	\N	f
3b002275-807d-47c1-a697-4968ce18ad43	Лоперамід	14	2025-10-19 08:45:44.763435+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763435+00	\N	\N	f
3b95ec02-f320-40cb-ab56-8a863423ec37	Цитрамон	45	2026-05-28 08:45:44.763516+00	2	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763516+00	\N	\N	f
3d669ee4-eb48-48e3-8d0a-5051d41f839f	Анальгін 50% (амп.)	8	2026-09-22 08:45:44.76349+00	1	4	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76349+00	\N	\N	f
3ddf7a19-118d-4e51-9c49-d68d89114799	Бинт еластичний	12	2026-06-02 08:45:44.763449+00	1	0	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763449+00	\N	\N	f
3e2223fc-00ae-4b06-a40c-1e38e8ae69e8	Анальгін 50% (амп.)	22	2026-09-18 08:45:44.763495+00	1	4	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763495+00	\N	\N	f
3f2c5a8d-f1f3-41fb-9b26-a247ce82a430	Анальгін 500мг	46	2027-07-14 08:45:44.763485+00	2	3	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763486+00	\N	\N	f
3f30cecd-820e-4c97-89b5-ce8fb2655300	Дексаметазон 4мг	19	2026-04-22 08:45:44.763487+00	1	4	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763487+00	\N	\N	f
40315ae1-60d4-4fd4-b644-f3b233afd25a	Серветки спиртові	5	2027-03-15 08:45:44.763514+00	1	5	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763514+00	\N	\N	f
43c0aecc-f153-4b11-87d4-21f08c390729	Парацетамол 500мг	84	2027-07-27 08:45:44.763487+00	2	3	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763488+00	\N	\N	f
4563e13f-4d49-4c2c-b668-835c8419328b	Маска медична	129	2026-10-03 08:45:44.763511+00	5	0	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763511+00	\N	\N	f
46284f1e-a02f-43cb-ad4c-ab13ec610caa	Бинт марлевий (упаковка)	10	2026-02-02 08:45:44.763424+00	1	5	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763425+00	\N	\N	f
487f8d45-787e-4b54-8215-9a45cafa42cb	Атропін 0.1%	13	2026-11-06 08:45:44.763457+00	1	4	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763457+00	\N	\N	f
4a0a75c8-3bbb-4f8c-a31a-2ad651a1ac13	Шприц одноразовий 10мл	43	2025-11-01 08:45:44.763471+00	2	0	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763471+00	\N	\N	f
4a79e832-105e-4181-87c4-47c77ec43f52	Маска медична	122	2027-02-21 08:45:44.763514+00	5	0	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763514+00	\N	\N	f
4e671a4b-cb74-44b8-ad90-350ed50cdedd	Серветки спиртові	9	2027-10-02 08:45:44.763466+00	1	5	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763466+00	\N	\N	f
4f075306-1656-4b91-9572-913141897115	Джгут гумовий	6	2027-04-27 08:45:44.763452+00	1	0	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763453+00	\N	\N	f
4f75eec6-6959-4949-bada-4d58b71b307a	Шприц одноразовий 5мл	44	2026-05-17 08:45:44.763513+00	2	0	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763513+00	\N	\N	f
53f9dfed-786c-4797-a125-851f4e3b3742	Розчин йоду 5%	35	2027-03-20 08:45:44.763494+00	6	1	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763494+00	\N	\N	f
5509dfd8-45a1-48bc-b521-d6778e961aba	Розчин йоду 5%	93	2026-06-28 08:45:44.763467+00	6	1	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763467+00	\N	\N	f
554bbad5-e04a-47db-b723-a6a6b5cd5ef2	Лоратадин 10мг	22	2027-12-12 08:45:44.763478+00	2	3	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763478+00	\N	\N	f
564c5c2e-8108-4657-8df7-7c3ccc395954	Цитрамон	39	2027-09-03 08:45:44.763496+00	2	3	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763504+00	\N	\N	f
57391f0c-adec-4f3b-b807-f03f5325e8a3	Лоратадин 10мг	18	2027-06-01 08:45:44.763518+00	2	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763518+00	\N	\N	f
576d59d6-335d-4a52-a55e-62812ad77f28	Марля медична	278	2026-05-02 08:45:44.763468+00	25	2	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763468+00	\N	\N	f
578af961-de14-4032-8970-f88ca60f7097	Корвалол	37	2027-09-28 08:45:44.763471+00	6	1	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763471+00	\N	\N	f
5a797cc6-8eec-48a7-8085-8ffc8c435f18	Папаверин 2%	24	2027-10-03 08:45:44.763518+00	1	4	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763518+00	\N	\N	f
5dcf816c-2b79-4b5b-a5ae-d58421a138fa	Бинт стерильний 5м×10см	23	2026-05-16 08:45:44.763476+00	1	0	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763476+00	\N	\N	f
5f77073e-56e6-4846-9c1d-75041f40e2cc	Лоперамід	22	2027-02-13 08:45:44.763494+00	2	3	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763495+00	\N	\N	f
601c5a7d-30ec-400c-b040-8cc66fffd53d	Хлоргексидин 0.05%	127	2027-06-27 08:45:44.763489+00	25	1	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763489+00	\N	\N	f
611a28f4-83f7-468a-9af5-433c87734068	Марля медична	470	2027-01-14 08:45:44.763487+00	25	2	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763487+00	\N	\N	f
61ecec24-de21-4efc-a3b9-5bfc29708787	Аспірин 500мг	19	2026-06-24 08:45:44.763429+00	2	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76343+00	\N	\N	f
63775544-34a3-46ab-9044-02731ec8ba38	Но-шпа 40мг	13	2028-01-28 08:45:44.763515+00	2	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763516+00	\N	\N	f
64db7565-7c2b-4575-8334-431c6dba273a	Корвалол	31	2026-09-24 08:45:44.763451+00	6	1	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763451+00	\N	\N	f
65c4382e-f9c2-4ad9-94be-92c40379ced9	Корвалол	73	2027-06-12 08:45:44.763494+00	6	1	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763494+00	\N	\N	f
67779650-fa23-4052-979c-8c47b29a6a07	Перекис водню 3%	320	2027-11-24 08:45:44.763489+00	25	1	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763489+00	\N	\N	f
684510a9-5de9-4dff-9e9e-9ad4d4d160d7	Амоксицилін 500мг	21	2027-12-08 08:45:44.763482+00	2	3	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763482+00	\N	\N	f
68fec8a2-4729-4abc-b2fc-e29d3f2bf5fe	Шприц одноразовий 5мл	31	2028-02-01 08:45:44.76343+00	2	0	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76343+00	\N	\N	f
6abfa92d-b956-4ec4-8414-4105cedabba5	Аспірин 500мг	10	2026-11-19 08:45:44.763478+00	2	3	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763478+00	\N	\N	f
6cf90476-5da2-40be-9e8f-5753a6dabba0	Дексаметазон 4мг	12	2026-03-05 08:45:44.763482+00	1	4	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763482+00	\N	\N	f
6f2d4489-7985-4bcb-a939-d02842881df7	Перекис водню 3%	111	2027-11-26 08:45:44.763458+00	25	1	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763458+00	\N	\N	f
70aabc9d-8ab0-412e-ada2-ca939f3bd222	Ібупрофен 200мг	42	2027-02-13 08:45:44.763451+00	2	3	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763451+00	\N	\N	f
752b5994-91d7-47b1-92e7-6fba43cfe11d	Спирт етиловий 70%	179	2025-11-16 08:45:44.763483+00	25	1	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763483+00	\N	\N	f
75486763-3683-476c-881f-59b7758a4112	Аспірин 500мг	14	2026-06-13 08:45:44.763472+00	2	3	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763472+00	\N	\N	f
79f71bb2-368c-43d4-9a94-33fa08868352	Дімедрол 1%	23	2027-04-05 08:45:44.763458+00	1	4	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763458+00	\N	\N	f
7c9fd8b6-15b9-4f7b-8ee9-aaa12f3f999f	Кеторолак 10мг	35	2027-07-16 08:45:44.763444+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763444+00	\N	\N	f
7e29da00-1b00-4209-b950-3147d68f41a7	Лейкопластир бактерицидний	23	2027-07-26 08:45:44.763453+00	2	0	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763453+00	\N	\N	f
7e7c81d9-34ed-4af3-a6b8-ae0637beaf59	Хлоргексидин 0.05%	329	2027-11-24 08:45:44.76351+00	25	1	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76351+00	\N	\N	f
7e7db47c-ff57-4de2-a53d-7570cf5f59e2	Бісептол 480мг	38	2026-05-17 08:45:44.763479+00	2	3	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763479+00	\N	\N	f
8200faed-9b86-456f-afb3-4329f2f91a6a	Валідол	25	2027-07-03 08:45:44.763504+00	2	3	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763504+00	\N	\N	f
843d106a-4eb5-4b3b-9434-7d2a13662438	Магнію сульфат 25%	6	2027-02-10 08:45:44.763489+00	1	4	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763489+00	\N	\N	f
85725e00-86de-4a67-a584-3a5d8f2ceeea	Маска медична	116	2026-10-09 08:45:44.763506+00	5	0	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763506+00	\N	\N	f
89d240f6-2b3c-4d61-a43f-9bc03ef711c5	Атропін 0.1%	13	2026-05-04 08:45:44.763427+00	1	4	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763428+00	\N	\N	f
8bd1f84c-5847-4cce-be65-26d27c29b8fd	Бинт марлевий (упаковка)	6	2027-02-18 08:45:44.763495+00	1	5	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763495+00	\N	\N	f
8bd62919-278a-485b-9829-e83ccbb7a4e3	Парацетамол 500мг	92	2027-12-19 08:45:44.763457+00	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763458+00	\N	\N	f
8e75c475-b8a0-48e6-91be-06d7d03adf01	Анальгін 500мг	36	2027-09-19 08:45:44.763442+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763442+00	\N	\N	f
8eda28ed-562c-4225-930c-c0b22ae863a0	Амоксицилін 500мг	27	2026-06-26 08:45:44.763517+00	2	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763517+00	\N	\N	f
8f130d61-28bd-4414-b203-4f66e1ec5229	Супрастин 25мг	30	2026-03-08 08:45:44.763429+00	2	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763429+00	\N	\N	f
93b41dd8-857b-44a7-888e-99e19ee2d610	Магнію сульфат 25%	11	2027-04-09 08:45:44.763462+00	1	4	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763463+00	\N	\N	f
940cf482-faee-4040-97f0-e8ceb3b2f08e	Лоперамід	15	2028-02-02 08:45:44.76343+00	2	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763431+00	\N	\N	f
971d727a-fc86-413c-9a6e-113a439a2347	Бинт еластичний	3	2026-09-17 08:45:44.763456+00	1	0	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763456+00	\N	\N	f
98bdb08f-62fd-43db-b1c9-67c1beab412d	Рукавички медичні	176	2027-12-21 08:45:44.763445+00	5	0	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763445+00	\N	\N	f
9a92f924-2568-416f-8183-2337d0f91e5b	Амоксицилін 500мг	22	2026-06-22 08:45:44.763426+00	2	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763426+00	\N	\N	f
9c0d519f-93b9-4fab-8424-159465d548ee	Адреналін 0.1%	20	2027-08-09 08:45:44.763468+00	1	4	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763469+00	\N	\N	f
9cb96c48-f9fe-4342-8a1c-5b6b5d551334	Валідол	30	2027-03-13 08:45:44.763449+00	2	3	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763449+00	\N	\N	f
9e609d7d-22a2-4b7a-9e7f-37b73d2f256b	Хлоргексидин 0.05%	481	2027-07-12 08:45:44.763475+00	25	1	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763476+00	\N	\N	f
9e8e31d5-da1f-472e-bfa6-c373ae98e917	Вата стерильна	396	2026-10-30 08:45:44.763458+00	12	2	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763458+00	\N	\N	f
a094636e-efc6-459c-8c95-f19bb68430fb	Преднізолон 30мг	18	2028-01-19 08:45:44.763467+00	1	4	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763467+00	\N	\N	f
a097102f-d611-40fc-b9dc-44bf6dca1c54	Серветки спиртові	2	2027-09-12 08:45:44.763509+00	1	5	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763509+00	\N	\N	f
a21d8fae-5809-4794-8ae7-be74be8776be	Фізіологічний розчин 0.9%	777	2027-09-03 08:45:44.763463+00	50	1	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763463+00	\N	\N	f
a255061d-c5b5-4ded-81e6-99c8f4e7924b	Перекис водню 3%	393	2027-04-14 08:45:44.76347+00	25	1	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76347+00	\N	\N	f
a2776f95-3842-425c-83cd-53e0eb50e2af	Розчин йоду 5%	96	2026-08-14 08:45:44.76351+00	6	1	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763511+00	\N	\N	f
a4cd6268-4e50-436f-9a8c-7021bc2ee759	Рукавички медичні	112	2027-08-30 08:45:44.763496+00	5	0	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763496+00	\N	\N	f
a52f7d95-d048-41de-92eb-f9ad32258967	Амоксицилін 500мг	24	2026-03-04 08:45:44.76347+00	2	3	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76347+00	\N	\N	f
a74e6735-1b6b-4bab-bb66-a7244f489b55	Розчин брильянтового зеленого	51	2028-02-14 08:45:44.763468+00	6	1	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763468+00	\N	\N	f
a7ccdbe7-201d-44e6-9724-8f3cc5f48a2c	Активоване вугілля	51	2028-03-07 08:45:44.763424+00	5	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763424+00	\N	\N	f
a8d5b89d-81b2-41cb-8e35-21e3e3dc412c	Но-шпа 40мг	48	2027-01-18 08:45:44.763476+00	2	3	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763476+00	\N	\N	f
a8f9595a-8563-4dcf-8007-27e8e766a6a7	Корвалол	46	2026-01-13 08:45:44.763515+00	6	1	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763515+00	\N	\N	f
a9735b11-e3e0-4827-83aa-6314998ff156	Бинт еластичний	8	2027-12-17 08:45:44.763508+00	1	0	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763508+00	\N	\N	f
a9c8eb3b-5266-4b65-98df-4d85f388b4c3	Нітрогліцерин	36	2026-12-30 08:45:44.763448+00	5	3	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763448+00	\N	\N	f
acc1b607-f3fc-407f-8513-19f973c2e9d0	Шприц одноразовий 10мл	41	2027-11-15 08:45:44.763518+00	2	0	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763518+00	\N	\N	f
ae37efd6-5273-4fa6-aee2-6117109599d8	Шприц одноразовий 10мл	12	2027-05-04 08:45:44.763462+00	2	0	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763462+00	\N	\N	f
af547350-1f62-4401-80f5-2388beea2dd9	Вата стерильна	337	2027-12-20 08:45:44.763493+00	12	2	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763494+00	\N	\N	f
b07f6fa3-475a-469b-8ad5-ab852b6f86d1	Маска медична	50	2028-03-10 08:45:44.763451+00	5	0	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763451+00	\N	\N	f
b0b57f95-a7da-4c99-bb3f-c6c6ab4fb054	Бинт марлевий (упаковка)	10	2025-11-13 08:45:44.763479+00	1	5	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763479+00	\N	\N	f
b40f77fb-c09a-4070-a7f8-46edb4c792af	Анальгін 500мг	12	2027-01-28 08:45:44.763427+00	2	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763427+00	\N	\N	f
b4fd73b6-e19b-42c7-a7c1-55b3c90e955d	Серветки спиртові	3	2026-03-04 08:45:44.763431+00	1	5	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763431+00	\N	\N	f
b679b9c5-7204-42d7-b80c-105a6f7abab0	Дімедрол 1%	13	2028-01-25 08:45:44.763467+00	1	4	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763467+00	\N	\N	f
b839ccf5-f029-4b64-a6ee-efc36fc7e2ea	Серветки спиртові	8	2026-06-13 08:45:44.763483+00	1	5	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763483+00	\N	\N	f
b84888fa-5f95-48bc-9009-2b9f11406ca3	Розчин йоду 5%	65	2027-03-26 08:45:44.763478+00	6	1	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763479+00	\N	\N	f
bb026167-3cdd-4473-8dce-7278cafa570c	Валідол	27	2026-12-07 08:45:44.763445+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763445+00	\N	\N	f
bc87a6af-66f2-46fc-8c1d-79803c40e0bd	Атропін 0.1%	19	2027-06-11 08:45:44.763435+00	1	4	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763435+00	\N	\N	f
be877c80-9b68-4cd8-9fab-071717c289d8	Цитрамон	32	2026-04-25 08:45:44.763471+00	2	3	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763472+00	\N	\N	f
bf5f740b-6bd0-4392-b9c3-a9b0148a4bcb	Лоперамід	15	2028-02-25 08:45:44.76345+00	2	3	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76345+00	\N	\N	f
bfafd419-024d-4158-92a3-ee7130117313	Нітрогліцерин	51	2026-01-30 08:45:44.763436+00	5	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76344+00	\N	\N	f
c120d6ec-496c-4dd2-90d4-c367cfcdb276	Марля медична	325	2027-05-20 08:45:44.763455+00	25	2	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763455+00	\N	\N	f
c214c05e-84a4-4a04-a5ec-276f6e196e8c	Хлоргексидин 0.05%	306	2026-04-28 08:45:44.763441+00	25	1	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763442+00	\N	\N	f
c32be0b0-5ef8-4496-b1e5-b0102def1baa	Анальгін 500мг	24	2027-05-11 08:45:44.763509+00	2	3	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76351+00	\N	\N	f
c4cf97ef-5912-4ff5-a320-fa44acd49d1a	Вата стерильна	286	2026-05-05 08:45:44.763515+00	12	2	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763515+00	\N	\N	f
c5669353-c56d-4cd8-a142-63c561c23580	Корвалол	27	2026-01-19 08:45:44.763423+00	6	1	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763423+00	\N	\N	f
c5a1eb1d-8d3c-499d-9761-891370589ee6	Анальгін 500мг	33	2027-09-06 08:45:44.763505+00	2	3	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763505+00	\N	\N	f
c5c3412d-7905-4068-8558-8efe2cdbefbc	Атропін 0.1%	6	2026-05-08 08:45:44.76347+00	1	4	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76347+00	\N	\N	f
c64b543c-a400-4d03-98a0-c4f5ed6c09ac	Аспірин 500мг	16	2028-03-25 08:45:44.763464+00	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763464+00	\N	\N	f
c7ace7af-10c7-418b-badc-1684f9f5d304	Атропін 0.1%	17	2028-02-12 08:45:44.763478+00	1	4	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763478+00	\N	\N	f
c8efaf8f-4a74-4f98-8405-831bc2b83ab9	Диклофенак 50мг	36	2028-01-16 08:45:44.763472+00	2	3	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763473+00	\N	\N	f
cb2bc40c-e88f-4e6d-b389-5180a9263733	Ібупрофен 200мг	53	2027-09-26 08:45:44.763495+00	2	3	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763496+00	\N	\N	f
cb80e720-0c14-4934-9e92-5d3177d055bd	Но-шпа 40мг	25	2026-10-01 08:45:44.763485+00	2	3	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763485+00	\N	\N	f
cb88a607-eebb-47a4-89f5-761ea5934e4c	Атропін 0.1%	6	2027-03-23 08:45:44.763447+00	1	4	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763448+00	\N	\N	f
cbe70ce7-efad-4d1f-9937-c9f27d770053	Розчин брильянтового зеленого	74	2027-07-23 08:45:44.763423+00	6	1	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763424+00	\N	\N	f
ce0d2b22-95e0-4e9f-95c8-e029a2f641c7	Супрастин 25мг	17	2027-11-12 08:45:44.763488+00	2	3	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763488+00	\N	\N	f
ce3e0184-98b7-4601-9066-251dd9a99a56	Магнію сульфат 25%	5	2027-07-03 08:45:44.76351+00	1	4	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76351+00	\N	\N	f
ce47a969-716b-40bd-916e-41c4c0ec726a	Бинт еластичний	4	2027-05-04 08:45:44.763477+00	1	0	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763477+00	\N	\N	f
d08718d3-e00f-42a6-94f8-72c9b3c5a185	Кеторолак 10мг	26	2027-01-21 08:45:44.763455+00	2	3	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763455+00	\N	\N	f
d0d305b2-f575-4312-93c3-6afafb9e483b	Лейкопластир бактерицидний	32	2027-06-07 08:45:44.763456+00	2	0	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763457+00	\N	\N	f
d81c1e33-0626-4d11-9628-92e8a9101afa	Перекис водню 3%	405	2028-02-01 08:45:44.763452+00	25	1	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763452+00	\N	\N	f
d82a2543-c259-477a-b3ca-e8913baa4c90	Преднізолон 30мг	9	2026-05-30 08:45:44.763477+00	1	4	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763477+00	\N	\N	f
df0872e3-d6a9-447f-b2c2-e41bb4451422	Вата стерильна	294	2027-09-29 08:45:44.763452+00	12	2	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763452+00	\N	\N	f
df8bac1f-e5e7-4849-82de-cd8a51655072	Дексаметазон 4мг	12	2027-05-06 08:45:44.763443+00	1	4	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763444+00	\N	\N	f
e0e21e46-43f2-4cb4-be8c-da673f4b9da3	Маска медична	111	2027-12-21 08:45:44.763455+00	5	0	2208e0cd-22d4-4613-b425-18801b7efc51	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763456+00	\N	\N	f
e237fe95-e54b-4309-8384-4b30185da5ae	Парацетамол 500мг	72	2027-04-24 08:45:44.763441+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763441+00	\N	\N	f
e27b765b-0bea-44aa-a967-6261c8d1b256	Бісептол 480мг	20	2025-12-29 08:45:44.763428+00	2	3	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763429+00	\N	\N	f
e3976d71-f7b4-46fa-8148-6dd3f6cb9e7c	Джгут гумовий	5	2026-08-18 08:45:44.763508+00	1	0	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763509+00	\N	\N	f
e39c0222-4922-430d-98f6-82498f01ef2e	Активоване вугілля	72	2027-12-29 08:45:44.763448+00	5	3	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763449+00	\N	\N	f
e46cb99a-778a-4f53-95d1-737cc7ba53e6	Но-шпа 40мг	42	2028-03-26 08:45:44.763448+00	2	3	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763448+00	\N	\N	f
e5c77b62-9a5d-4ab4-8c98-ca6faab3c38f	Дексаметазон 4мг	11	2027-02-11 08:45:44.763516+00	1	4	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763517+00	\N	\N	f
e8327816-3080-487e-a0cd-11fc3b8348e8	Розчин йоду 5%	84	2027-10-19 08:45:44.763442+00	6	1	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763443+00	\N	\N	f
e9f5f3ef-0bbb-4a59-8343-47426909183b	Дімедрол 1%	10	2026-12-10 08:45:44.763486+00	1	4	f79c547f-cee7-466a-86e5-4618a86adbd3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763486+00	\N	\N	f
ea4da304-ac01-4548-ae7d-7a72663f1f52	Бинт еластичний	4	2028-03-17 08:45:44.763504+00	1	0	75760860-1113-46d6-9cfb-9d6b14667b38	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763505+00	\N	\N	f
eae2d40b-13c6-4559-991c-f099bb6a16fb	Аспірин 500мг	55	2026-06-08 08:45:44.763444+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763444+00	\N	\N	f
ec66b93b-bdc8-41b1-a2ab-1c13ebaf1e10	Лоратадин 10мг	13	2027-09-09 08:45:44.763471+00	2	3	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763471+00	\N	\N	f
ec8af5c2-061b-4e96-9ffd-5ff86d3b59ae	Валідол	19	2026-04-16 08:45:44.763469+00	2	3	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76347+00	\N	\N	f
f590cf02-72df-49a5-80f0-3bd3795328e5	Вата стерильна	294	2026-04-28 08:45:44.763422+00	12	2	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763423+00	\N	\N	f
f59f3203-9bcc-4f9d-99a5-aef36edcbd77	Анальгін 50% (амп.)	15	2026-05-30 08:45:44.763436+00	1	4	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763436+00	\N	\N	f
f5f2960c-741c-4089-897d-42bd04f0c745	Бинт еластичний	15	2026-07-01 08:45:44.763429+00	1	0	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763429+00	\N	\N	f
f91d27df-1b8f-44d3-bcaf-d51a9b75e75f	Парацетамол 500мг	50	2027-02-01 08:45:44.763468+00	2	3	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763468+00	\N	\N	f
f9b846ab-eecb-4b83-a31d-4c80e4efd8d0	Джгут гумовий	2	2026-04-16 08:45:44.763426+00	1	0	c38ec754-c644-4b07-8b9a-7b36772da0f3	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763427+00	\N	\N	f
fa36e4d7-8bfc-4d11-a9a5-495e9ec31838	Бинт марлевий (упаковка)	7	2026-09-24 08:45:44.763469+00	1	5	521dd62d-9375-4440-9001-828eb746a50a	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763469+00	\N	\N	f
fb6de3b1-471b-4889-9443-a670b7e75a80	Лоратадин 10мг	20	2027-02-27 08:45:44.763508+00	2	3	9e8f24cc-3649-4841-9f10-72ed2d5d780b	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763508+00	\N	\N	f
fc299961-35e1-4a86-815f-04064e076ee7	Перекис водню 3%	185	2027-10-07 08:45:44.763517+00	25	1	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763517+00	\N	\N	f
fcfe4a6f-cb3a-4b7a-a762-c1d56643e2ad	Розчин брильянтового зеленого	40	2027-04-24 08:45:44.76345+00	6	1	7e435359-29d6-4eb2-8bb5-23362118973f	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.76345+00	\N	\N	f
fef8fa5a-dad8-4c03-8884-9f958bfb20c9	Супрастин 25мг	12	2026-06-02 08:45:44.763444+00	2	3	9bdb768a-f4cd-4362-b8fb-bc29f727af93	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763444+00	\N	\N	f
ff2fe6ff-426c-44d9-97dd-d504be16c0d7	Диклофенак 50мг	14	2027-01-27 08:45:44.763517+00	2	3	9c4054e0-89cd-490d-9ced-dcbfd107537d	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763517+00	\N	\N	f
ff6e5130-835a-416c-ad7f-12b11cacb2e4	Рукавички медичні	20	2027-04-26 08:45:44.763482+00	5	0	cc8b14b5-d9d4-4c41-bbf2-cb28a0290d28	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.763482+00	\N	\N	f
005c3d34-5bdd-4a00-9700-103155f6b10b	Розчин йоду 5%	51	2028-01-09 08:45:45.45628+00	6	1	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456281+00	\N	\N	f
01991920-4bbf-4db6-a54d-9317bfd04887	Лоперамід	19	2027-08-19 08:45:45.45621+00	2	3	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456211+00	\N	\N	f
01ddf639-4985-421b-aeab-be0562eb166e	Лоперамід	16	2026-11-07 08:45:45.456292+00	2	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456292+00	\N	\N	f
023a05ef-dfe8-4efc-953e-4970c9c4a97f	Маска медична	121	2026-04-15 08:45:45.456305+00	5	0	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456306+00	\N	\N	f
040077d9-01a5-4990-8b39-afcdc8f98a96	Дімедрол 1%	22	2026-07-04 08:45:45.456293+00	1	4	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456293+00	\N	\N	f
045b8432-9c94-4eb2-b58a-59f037f50047	Анальгін 500мг	44	2026-06-27 08:45:45.456249+00	2	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456249+00	\N	\N	f
0813fe59-08c8-4fda-a9ce-fa7bc41ba560	Лейкопластир бактерицидний	46	2026-04-29 08:45:45.456223+00	2	0	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456224+00	\N	\N	f
099042bd-c31e-4c79-8fe7-45d2a38fee42	Анальгін 500мг	26	2027-10-19 08:45:45.456255+00	2	3	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456255+00	\N	\N	f
0a6c9ffd-8548-443f-9f2c-4407ce93d7ac	Маска медична	174	2027-10-12 08:45:45.45622+00	5	0	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45622+00	\N	\N	f
0b0d5e6b-8311-4f24-a927-295e295d93dd	Корвалол	74	2027-04-23 08:45:45.456237+00	6	1	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456238+00	\N	\N	f
0bca9dff-53ee-4209-950d-292b2c92c846	Джгут гумовий	4	2027-06-08 08:45:45.456254+00	1	0	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456255+00	\N	\N	f
0c526865-a410-4eaa-b23b-194e9248c48f	Ібупрофен 200мг	57	2027-09-30 08:45:45.456237+00	2	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456237+00	\N	\N	f
0c982a1e-f127-4619-8ec1-9a91965928fb	Вата стерильна	181	2026-10-20 08:45:45.456271+00	12	2	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456272+00	\N	\N	f
0ce79646-a131-4189-97e4-9ca5b1672c33	Спирт етиловий 70%	230	2026-11-26 08:45:45.456284+00	25	1	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456284+00	\N	\N	f
0f12f734-cfc8-4388-9c2e-92ec6a77b21b	Корвалол	53	2026-07-07 08:45:45.456269+00	6	1	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456269+00	\N	\N	f
10b8e1a0-951d-410b-8444-149a1473b836	Розчин йоду 5%	38	2026-10-20 08:45:45.456227+00	6	1	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456227+00	\N	\N	f
119265d6-613b-41a2-95b6-dc0e1d64b9c0	Розчин брильянтового зеленого	39	2027-04-02 08:45:45.456295+00	6	1	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456295+00	\N	\N	f
11b39804-554c-4eb1-bdeb-59154067c245	Лоперамід	10	2027-02-24 08:45:45.456275+00	2	3	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456275+00	\N	\N	f
12f84bd2-7d8c-4d66-bd9b-0b4914a8ba9b	Аспірин 500мг	57	2027-12-05 08:45:45.456232+00	2	3	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456232+00	\N	\N	f
13314374-d3e3-4bee-a5df-6e62ec8461de	Валідол	11	2025-12-17 08:45:45.456226+00	2	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456226+00	\N	\N	f
16162468-6733-415e-8e4d-142b0ffe118a	Супрастин 25мг	17	2026-06-07 08:45:45.456232+00	2	3	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456233+00	\N	\N	f
16648792-be77-411d-8a6b-3c4685ecbce9	Нітрогліцерин	50	2027-03-03 08:45:45.456283+00	5	3	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456283+00	\N	\N	f
169e50a0-d4b1-4dab-96c9-07a7b1613846	Кеторолак 10мг	40	2026-05-19 08:45:45.456282+00	2	3	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456282+00	\N	\N	f
16dc5a5c-27e1-4435-b60d-f25e7c984af2	Амоксицилін 500мг	28	2026-01-01 08:45:45.456226+00	2	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456227+00	\N	\N	f
18b660cb-f14b-495d-b701-7833711b7507	Бинт марлевий (упаковка)	7	2026-04-15 08:45:45.456234+00	1	5	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456235+00	\N	\N	f
1ad47bab-c777-467f-b237-c70be42d8c45	Амоксицилін 500мг	13	2027-02-16 08:45:45.4563+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.4563+00	\N	\N	f
1b8b608d-357a-414b-b0fa-a2b5c43c936f	Спирт етиловий 70%	264	2026-06-03 08:45:45.456247+00	25	1	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456247+00	\N	\N	f
1bdd2720-9440-46cf-8d2b-b1458c055242	Магнію сульфат 25%	15	2026-11-10 08:45:45.456295+00	1	4	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456295+00	\N	\N	f
1c41e7c9-3136-48e5-8e50-b179dc6fabb9	Аспірин 500мг	45	2026-07-07 08:45:45.456213+00	2	3	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456213+00	\N	\N	f
1d2c89c8-3a13-4f60-a793-837db7084676	Цитрамон	33	2026-10-15 08:45:45.456287+00	2	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456287+00	\N	\N	f
1dd75784-1559-484b-8b34-fefd6bd4d9d2	Перекис водню 3%	252	2027-05-21 08:45:45.45629+00	25	1	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45629+00	\N	\N	f
234909a9-d6c7-4f10-b572-b0ebc83c5466	Бісептол 480мг	33	2026-02-13 08:45:45.456305+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456305+00	\N	\N	f
241d0f05-b57b-4bf4-a8ee-923683f4da9a	Парацетамол 500мг	89	2028-03-14 08:45:45.456297+00	2	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456297+00	\N	\N	f
2854ef52-6248-4ca4-85f5-8ab4b941f39f	Анальгін 500мг	51	2026-05-24 08:45:45.456272+00	2	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456272+00	\N	\N	f
2db9980e-fa96-4bf0-aa04-a9d3dec31c8d	Спирт етиловий 70%	341	2026-04-23 08:45:45.45623+00	25	1	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45623+00	\N	\N	f
303a0e3e-c828-44ed-ade1-1b88c498e1f1	Розчин йоду 5%	91	2027-10-23 08:45:45.456304+00	6	1	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456305+00	\N	\N	f
31d13b84-dc27-46d3-92b8-923e802aff95	Дімедрол 1%	8	2027-06-05 08:45:45.456232+00	1	4	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456232+00	\N	\N	f
331c48e1-d7bc-41b3-aedd-c41505dc4751	Ібупрофен 200мг	76	2028-02-06 08:45:45.456257+00	2	3	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456257+00	\N	\N	f
3528e8f1-fc24-4581-b4c7-ae218f3ac8a0	Шприц одноразовий 5мл	35	2026-12-11 08:45:45.456301+00	2	0	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456301+00	\N	\N	f
3628afe7-e450-4ff6-8cf9-5e480d47b39c	Атропін 0.1%	18	2026-06-13 08:45:45.456265+00	1	4	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456266+00	\N	\N	f
378d570f-0c2b-4aa9-8f5b-d3b326bedb1e	Супрастин 25мг	27	2027-03-08 08:45:45.456303+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456303+00	\N	\N	f
38b0013d-457d-4cd2-b564-ca94345a94f7	Адреналін 0.1%	18	2026-05-31 08:45:45.45623+00	1	4	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456231+00	\N	\N	f
39801e1f-09ae-4c29-94fc-af0f13b28359	Рукавички медичні	124	2026-06-03 08:45:45.456299+00	5	0	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.4563+00	\N	\N	f
39de4f0f-4970-4223-a799-3b0591a297d1	Дімедрол 1%	20	2026-11-29 08:45:45.456269+00	1	4	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456269+00	\N	\N	f
3bbe816d-86a0-45db-a4d0-e0cb95ee0754	Папаверин 2%	24	2027-04-19 08:45:45.456237+00	1	4	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456237+00	\N	\N	f
3bcc8d69-b5c2-4a26-af1f-2b1ba8bda751	Супрастин 25мг	17	2026-06-16 08:45:45.456221+00	2	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456221+00	\N	\N	f
3d5bca92-ea45-42bc-94ac-4dce716d2c8f	Преднізолон 30мг	22	2027-09-20 08:45:45.456288+00	1	4	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456288+00	\N	\N	f
3e3c1924-af6a-4e60-a6a2-3deb8ca753bd	Лейкопластир бактерицидний	25	2028-03-16 08:45:45.456288+00	2	0	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456288+00	\N	\N	f
3fff8e36-d023-4013-95ca-f24215b90c4a	Папаверин 2%	22	2026-12-17 08:45:45.456293+00	1	4	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456293+00	\N	\N	f
41c8cc33-02ca-4aed-b8e4-3e668f772910	Цитрамон	10	2027-10-27 08:45:45.456241+00	2	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456242+00	\N	\N	f
41e2e178-f706-4031-9164-6093e05d0b9d	Маска медична	49	2027-10-31 08:45:45.456216+00	5	0	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456216+00	\N	\N	f
41fef9b4-b321-4780-bf0a-0e92dd738eaa	Диклофенак 50мг	16	2027-07-02 08:45:45.456296+00	2	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456296+00	\N	\N	f
428f307c-5413-45b5-a9f9-1f2cfbe4e41c	Лейкопластир бактерицидний	11	2027-01-18 08:45:45.456295+00	2	0	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456295+00	\N	\N	f
43621baf-37a5-49e2-8830-e7674f4ebad2	Вата стерильна	245	2028-01-25 08:45:45.456213+00	12	2	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456213+00	\N	\N	f
4396580d-29df-4dff-a4e3-08e108cf4d07	Перекис водню 3%	342	2026-10-11 08:45:45.456284+00	25	1	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456285+00	\N	\N	f
464e7155-fa79-41ce-a356-1b5e13a50bd6	Хлоргексидин 0.05%	471	2026-01-14 08:45:45.456224+00	25	1	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456225+00	\N	\N	f
479d9424-168d-4397-a446-9e8effd91229	Магнію сульфат 25%	5	2027-01-01 08:45:45.456233+00	1	4	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456233+00	\N	\N	f
48bf761f-fead-4f3c-b445-b662df3caf7b	Марля медична	206	2026-05-06 08:45:45.45622+00	25	2	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456221+00	\N	\N	f
4ae09e3a-2f90-4a28-a3a9-72c500ccea84	Дексаметазон 4мг	24	2027-08-30 08:45:45.456296+00	1	4	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456296+00	\N	\N	f
4c21d9e4-6066-439e-b5d8-b7cd22f7a991	Вата стерильна	199	2027-04-07 08:45:45.456245+00	12	2	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456246+00	\N	\N	f
4c91d580-2568-41b8-848c-6db99b9b4e43	Спирт етиловий 70%	351	2028-02-24 08:45:45.456289+00	25	1	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456289+00	\N	\N	f
4ca2bcdd-b191-4402-94ff-5c8a7c0d0048	Валідол	18	2027-06-29 08:45:45.456286+00	2	3	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456286+00	\N	\N	f
4e1d0f7a-3eda-402d-87cf-f778459e6f0f	Кеторолак 10мг	17	2027-12-04 08:45:45.456268+00	2	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456269+00	\N	\N	f
4f585d6d-693b-4b15-ad36-e4d2907c1aba	Лейкопластир бактерицидний	12	2026-10-24 08:45:45.456285+00	2	0	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456285+00	\N	\N	f
4f720d02-c878-42ae-8f14-07b604d1bd7e	Джгут гумовий	7	2028-02-06 08:45:45.456278+00	1	0	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456278+00	\N	\N	f
4fd2e997-52d7-44df-9f6f-ce73f18e21d6	Анальгін 50% (амп.)	20	2027-12-22 08:45:45.456253+00	1	4	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456253+00	\N	\N	f
4fdb03e3-f9cb-4dbb-ba54-67101b87fd87	Спирт етиловий 70%	344	2026-01-27 08:45:45.456239+00	25	1	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456239+00	\N	\N	f
516e7a35-54ec-46ec-8f62-65d206345713	Джгут гумовий	6	2027-07-21 08:45:45.456243+00	1	0	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456243+00	\N	\N	f
52095f6f-c600-46f6-b6c3-b7b76a6188dd	Нітрогліцерин	40	2027-09-20 08:45:45.456304+00	5	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456304+00	\N	\N	f
560a7aaa-6200-4374-855c-f9c6b55b7f1b	Преднізолон 30мг	8	2025-11-18 08:45:45.456285+00	1	4	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456285+00	\N	\N	f
58afd42f-dafd-40e1-91bf-48069b28d938	Папаверин 2%	14	2026-10-11 08:45:45.456277+00	1	4	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456278+00	\N	\N	f
5dd08e00-edab-4021-9cc0-f2da4aadc606	Серветки спиртові	1	2028-03-03 08:45:45.456297+00	1	5	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456298+00	\N	\N	f
5e7cfa36-29af-4cd6-872c-e742471c7cbc	Амоксицилін 500мг	26	2026-11-19 08:45:45.456231+00	2	3	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456231+00	\N	\N	f
5ffdfdbe-7910-4956-8895-e31f054394d0	Преднізолон 30мг	18	2027-02-20 08:45:45.456306+00	1	4	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456306+00	\N	\N	f
609ab533-2f16-4297-81e8-208ef995c0bc	Шприц одноразовий 10мл	45	2026-01-18 08:45:45.456302+00	2	0	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456302+00	\N	\N	f
613b541a-1ef9-4f33-8d72-b509e0f7d84b	Хлоргексидин 0.05%	468	2027-01-01 08:45:45.456215+00	25	1	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456215+00	\N	\N	f
6348f069-0614-4bb6-aa59-82a5acd8c98a	Аспірин 500мг	60	2027-06-05 08:45:45.45628+00	2	3	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45628+00	\N	\N	f
671f93bb-80d6-4be1-ba3a-80a01541e328	Цитрамон	41	2025-10-16 08:45:45.456281+00	2	3	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456281+00	\N	\N	f
67610a55-9de8-4056-8db8-f9b4bdd340fb	Дексаметазон 4мг	23	2027-05-24 08:45:45.456247+00	1	4	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456247+00	\N	\N	f
6983b6ac-1e2e-4645-8316-a7075222263f	Нітрогліцерин	45	2026-05-29 08:45:45.456271+00	5	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456271+00	\N	\N	f
6a11cce6-2a3a-4761-8a96-2766b38584c0	Бинт марлевий (упаковка)	3	2026-11-27 08:45:45.456296+00	1	5	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456297+00	\N	\N	f
6a360f55-279d-4247-b18a-9cd32ad9d4f3	Рукавички медичні	196	2027-03-11 08:45:45.456222+00	5	0	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456222+00	\N	\N	f
6ac2ec7c-4656-4ef5-b3f9-a333a99c9fb4	Но-шпа 40мг	11	2026-08-16 08:45:45.4563+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.4563+00	\N	\N	f
6afc8cbe-51b2-4f41-ad89-c3cb16f973b1	Лейкопластир бактерицидний	28	2027-01-01 08:45:45.456276+00	2	0	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456276+00	\N	\N	f
6bab7186-3ecf-4a9e-9542-2a3ede64b901	Фізіологічний розчин 0.9%	808	2027-10-09 08:45:45.456274+00	50	1	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456274+00	\N	\N	f
6c4169b0-a71d-4a25-aeb2-b504b4c6b6cb	Атропін 0.1%	17	2025-12-19 08:45:45.456305+00	1	4	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456305+00	\N	\N	f
6cb84437-df50-4fd8-81f1-06deda7e655e	Маска медична	82	2027-06-29 08:45:45.456233+00	5	0	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456234+00	\N	\N	f
6dca1e88-ac04-483b-a507-b7469a8a3d34	Серветки спиртові	3	2026-11-05 08:45:45.456224+00	1	5	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456224+00	\N	\N	f
71ef09b9-be8a-4c29-8702-37f3364f0e32	Шприц одноразовий 5мл	46	2028-02-03 08:45:45.456252+00	2	0	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456252+00	\N	\N	f
729a5de0-3100-45ab-9cdf-fa96ac490a6e	Диклофенак 50мг	29	2027-02-12 08:45:45.456228+00	2	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456229+00	\N	\N	f
73325c31-3db9-4276-98dd-25f73b6b266b	Кеторолак 10мг	35	2028-01-22 08:45:45.456214+00	2	3	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456215+00	\N	\N	f
73395ca0-9c12-4b09-bb0b-2f5f9682c9b5	Ібупрофен 200мг	10	2027-09-29 08:45:45.456215+00	2	3	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456215+00	\N	\N	f
77061346-8ed2-43ae-99f6-bdbe723a2f1c	Валідол	20	2027-05-04 08:45:45.45627+00	2	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456271+00	\N	\N	f
78109eee-3ec5-4578-a590-a6cb97fc5d55	Шприц одноразовий 10мл	26	2027-03-01 08:45:45.456245+00	2	0	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456245+00	\N	\N	f
7833b178-c1be-46ac-85a8-3b489d3cdcdc	Бинт марлевий (упаковка)	10	2025-11-02 08:45:45.45627+00	1	5	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45627+00	\N	\N	f
78fa59bf-e79b-4998-b7bc-c2daf3000c82	Амоксицилін 500мг	40	2027-08-15 08:45:45.456266+00	2	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456266+00	\N	\N	f
7a168a58-4c07-44ee-9418-441cde788e55	Розчин йоду 5%	89	2027-03-07 08:45:45.45627+00	6	1	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45627+00	\N	\N	f
7dbb5c83-4e27-4cff-a093-8f9f37a09530	Фізіологічний розчин 0.9%	621	2026-02-18 08:45:45.456303+00	50	1	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456303+00	\N	\N	f
80a65e6f-acea-4053-bef5-18aee5bad96b	Преднізолон 30мг	6	2028-03-07 08:45:45.456248+00	1	4	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456249+00	\N	\N	f
81d68c17-e7f7-4cdc-8e16-4e948f32b37e	Нітрогліцерин	57	2027-10-30 08:45:45.45625+00	5	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45625+00	\N	\N	f
8315e6d1-d8d1-4383-8e92-878e55f3f745	Ібупрофен 200мг	71	2026-06-10 08:45:45.456225+00	2	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456226+00	\N	\N	f
8389f94a-88c2-436b-a524-b9c4bfa7f64d	Бісептол 480мг	27	2027-08-17 08:45:45.45629+00	2	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45629+00	\N	\N	f
8622cfe2-7a6d-4bcd-a471-e446f90e24ca	Лейкопластир бактерицидний	43	2025-11-23 08:45:45.456269+00	2	0	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456269+00	\N	\N	f
86912be7-0901-4b92-b84b-0335aee2193b	Фізіологічний розчин 0.9%	922	2026-12-17 08:45:45.456272+00	50	1	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456273+00	\N	\N	f
8932449c-08ea-499b-a6ce-f866165ab78e	Парацетамол 500мг	89	2026-02-12 08:45:45.456304+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456304+00	\N	\N	f
89e1a5ea-fbc6-4217-a89c-c359d383cac6	Анальгін 500мг	21	2026-04-20 08:45:45.456285+00	2	3	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456286+00	\N	\N	f
8a401987-c1b1-4525-8b4d-d3db24c7fe51	Бинт еластичний	3	2027-08-27 08:45:45.456255+00	1	0	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456255+00	\N	\N	f
8c6c7f63-d455-4552-8bf9-286502a14432	Амоксицилін 500мг	21	2027-03-01 08:45:45.456241+00	2	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456241+00	\N	\N	f
8d41687e-a27a-4940-88cb-cfca7c58840f	Валідол	23	2027-03-26 08:45:45.456277+00	2	3	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456277+00	\N	\N	f
8eee575b-efcc-45f0-a717-0d0cbe9570eb	Но-шпа 40мг	27	2026-03-06 08:45:45.456239+00	2	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456239+00	\N	\N	f
93b7689c-8d65-422d-9222-f37c692bf37a	Бинт еластичний	12	2026-09-16 08:45:45.456212+00	1	0	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456213+00	\N	\N	f
959d3fbd-b035-4345-a58a-ac7d89123e8f	Магнію сульфат 25%	9	2026-09-12 08:45:45.456241+00	1	4	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456241+00	\N	\N	f
960134f0-fe13-4af2-8634-b044b3210fe5	Валідол	21	2028-02-13 08:45:45.456294+00	2	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456294+00	\N	\N	f
9612917a-7b3c-4c1c-b038-f494865d2d66	Ібупрофен 200мг	38	2027-02-01 08:45:45.456305+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456305+00	\N	\N	f
971a21f5-0691-47ca-aa4b-f478792d1637	Активоване вугілля	23	2027-10-06 08:45:45.456267+00	5	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456267+00	\N	\N	f
97f552cb-45cc-4e89-948a-cb2c73a2a544	Марля медична	425	2027-12-18 08:45:45.456267+00	25	2	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456267+00	\N	\N	f
996629b6-b6da-49a5-b0da-e16992e2b1d3	Бинт еластичний	4	2027-11-17 08:45:45.456228+00	1	0	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456228+00	\N	\N	f
9a015a91-62de-444c-b3a5-eb97c2d04f34	Бинт еластичний	3	2027-06-03 08:45:45.456293+00	1	0	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456293+00	\N	\N	f
9ba4860c-3594-46bd-ae6f-6d45f6e945a2	Лоперамід	27	2027-01-06 08:45:45.45624+00	2	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456241+00	\N	\N	f
9bb34046-a4be-4580-8776-766bfe78ab36	Папаверин 2%	19	2026-06-02 08:45:45.456266+00	1	4	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456266+00	\N	\N	f
9c38db4d-4847-4349-823b-c13dd8ef6824	Бинт еластичний	13	2028-01-18 08:45:45.456242+00	1	0	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456242+00	\N	\N	f
9cb67d47-fca7-4f33-b36e-d9a89f99a20c	Парацетамол 500мг	38	2027-11-13 08:45:45.456243+00	2	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456243+00	\N	\N	f
9e9fd07c-c530-4f83-b0b6-bbdab6ff466d	Диклофенак 50мг	24	2027-09-06 08:45:45.456282+00	2	3	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456283+00	\N	\N	f
9feb85a2-7709-4eab-8a5b-dbabf814c5fe	Марля медична	132	2027-08-10 08:45:45.456214+00	25	2	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456214+00	\N	\N	f
a025e768-5b5d-4abc-b5f5-b59c57024617	Бинт марлевий (упаковка)	1	2027-07-22 08:45:45.456254+00	1	5	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456254+00	\N	\N	f
a374b9ec-cd78-4c37-9b4e-2386f2fc3809	Дексаметазон 4мг	20	2028-02-29 08:45:45.456277+00	1	4	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456277+00	\N	\N	f
a3de03ae-2342-4e6f-8445-0e644b1ff88e	Лоперамід	19	2026-06-30 08:45:45.456222+00	2	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456222+00	\N	\N	f
a7d21c76-4d57-4b07-beeb-1deec81eb5bc	Адреналін 0.1%	8	2028-02-28 08:45:45.456224+00	1	4	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456224+00	\N	\N	f
a99d2ab2-c82b-4adf-8f94-842d5e3b1cc8	Корвалол	43	2027-02-04 08:45:45.45628+00	6	1	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45628+00	\N	\N	f
aa5e4d8a-d4a8-4f49-9ad6-fa810905ee80	Розчин брильянтового зеленого	78	2028-01-03 08:45:45.456271+00	6	1	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456271+00	\N	\N	f
aab630c7-c81e-4170-933d-1fff6dbd8d02	Кеторолак 10мг	28	2027-04-05 08:45:45.456233+00	2	3	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456233+00	\N	\N	f
ad035f78-21ed-4fbf-bb4b-8fdefda63682	Парацетамол 500мг	84	2027-08-04 08:45:45.456266+00	2	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456266+00	\N	\N	f
ae65b268-88f3-4c79-b8bf-0b7a6ddab38f	Бинт марлевий (упаковка)	5	2028-02-16 08:45:45.456301+00	1	5	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456301+00	\N	\N	f
af3d7f7e-4730-4494-8e90-1042a8837b4b	Дімедрол 1%	23	2026-09-26 08:45:45.456254+00	1	4	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456254+00	\N	\N	f
b0bfe7ea-a738-4bc8-9172-0159b23aaa10	Магнію сульфат 25%	10	2027-07-16 08:45:45.456281+00	1	4	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456281+00	\N	\N	f
b1130c16-119b-472c-8a32-a3cb92d8d0ec	Ібупрофен 200мг	55	2025-11-10 08:45:45.456268+00	2	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456268+00	\N	\N	f
b11e3090-3d37-461d-a4fa-63e038369bc0	Марля медична	250	2027-07-29 08:45:45.456257+00	25	2	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456257+00	\N	\N	f
b194bb36-4f91-4408-ba3f-762113256114	Розчин брильянтового зеленого	66	2028-01-15 08:45:45.456287+00	6	1	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456288+00	\N	\N	f
b2e8c970-9fd9-4c8c-b424-ae812458cffe	Дімедрол 1%	14	2027-02-06 08:45:45.456225+00	1	4	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456225+00	\N	\N	f
b3044b48-04c2-4d93-ab4b-48d4b2fa2d0a	Лоратадин 10мг	13	2027-05-22 08:45:45.456225+00	2	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456225+00	\N	\N	f
b489c330-e126-41f2-b37d-fcf8c552e3fe	Розчин брильянтового зеленого	61	2027-08-10 08:45:45.456253+00	6	1	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456254+00	\N	\N	f
b6ac428e-b17d-47e3-9f00-d3d561ea40b0	Хлоргексидин 0.05%	410	2028-02-29 08:45:45.456256+00	25	1	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456256+00	\N	\N	f
b788fa92-015b-4fa6-9da3-c2f4d10112c8	Цитрамон	45	2027-07-21 08:45:45.456302+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456302+00	\N	\N	f
b82ec481-8f3f-446d-a197-9cb57a1183e8	Парацетамол 500мг	88	2027-05-07 08:45:45.456276+00	2	3	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456276+00	\N	\N	f
b8d1b876-6d0b-4948-af8c-d3c47aa38caf	Диклофенак 50мг	38	2026-10-06 08:45:45.456238+00	2	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456238+00	\N	\N	f
b92cb796-e4e2-4838-808d-64e62c5d0db9	Амоксицилін 500мг	10	2028-02-25 08:45:45.456255+00	2	3	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456256+00	\N	\N	f
bcd7394a-62c4-4cbf-aa5f-abe883cc7839	Парацетамол 500мг	45	2027-04-07 08:45:45.456248+00	2	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456248+00	\N	\N	f
beb0e804-3d58-4a51-bf18-460d92d33974	Маска медична	150	2026-06-05 08:45:45.456257+00	5	0	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456258+00	\N	\N	f
c116782f-1263-4a16-bca8-41da959a2ed2	Супрастин 25мг	17	2026-09-08 08:45:45.456212+00	2	3	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456212+00	\N	\N	f
c1492267-e543-4cc0-87b4-fe9770d2405d	Розчин брильянтового зеленого	51	2027-01-17 08:45:45.456221+00	6	1	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456221+00	\N	\N	f
c1fe1250-7c10-43ed-b86e-ffb623405f6c	Амоксицилін 500мг	11	2027-05-25 08:45:45.456283+00	2	3	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456283+00	\N	\N	f
c451e9cf-4a25-470b-a962-a3ebf689474b	Лейкопластир бактерицидний	21	2027-07-24 08:45:45.456253+00	2	0	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456253+00	\N	\N	f
c661ce3b-390e-4e1a-830a-6fdea04c87b1	Нітрогліцерин	29	2028-02-22 08:45:45.456228+00	5	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456228+00	\N	\N	f
c6b88424-54e7-45a2-b164-27d71cb5564f	Активоване вугілля	40	2027-08-25 08:45:45.45624+00	5	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45624+00	\N	\N	f
c75e270e-60c6-415f-aef7-e109996db74f	Нітрогліцерин	27	2027-05-08 08:45:45.456294+00	5	3	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456294+00	\N	\N	f
c9b9380f-7128-4ef0-8c5a-3e2552d5fdb7	Кеторолак 10мг	16	2027-07-31 08:45:45.456238+00	2	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456239+00	\N	\N	f
ca9a5c24-aa28-41d9-bb11-6f3c56e93c60	Валідол	26	2027-07-13 08:45:45.456214+00	2	3	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456214+00	\N	\N	f
cae06c48-4fa7-4b35-8710-183d896aab6a	Фізіологічний розчин 0.9%	302	2027-01-24 08:45:45.45624+00	50	1	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45624+00	\N	\N	f
ccab8b71-6718-497f-bcde-e7ea33cd227c	Розчин йоду 5%	26	2026-11-21 08:45:45.456295+00	6	1	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456296+00	\N	\N	f
cf630ebf-b01c-4b4f-a4aa-289976f47c47	Кеторолак 10мг	21	2027-06-24 08:45:45.456252+00	2	3	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456253+00	\N	\N	f
cf9368a7-4799-462a-b368-363ec9b06bae	Дексаметазон 4мг	15	2026-08-27 08:45:45.456289+00	1	4	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456289+00	\N	\N	f
d07eeeb3-5840-4bff-a553-d476dbbee8ce	Перекис водню 3%	263	2027-02-15 08:45:45.456264+00	25	1	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456265+00	\N	\N	f
d222c074-c5a0-4a5a-ad3b-986922b7b733	Спирт етиловий 70%	166	2027-02-17 08:45:45.456293+00	25	1	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456294+00	\N	\N	f
d50c2dc4-07b6-4ae3-9e35-627c9c68dca6	Хлоргексидин 0.05%	189	2027-10-16 08:45:45.45629+00	25	1	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45629+00	\N	\N	f
d5721bd7-593d-49bf-be01-287c84cedef7	Анальгін 50% (амп.)	20	2026-06-28 08:45:45.456223+00	1	4	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456223+00	\N	\N	f
d599d921-a472-416c-84d0-68dd7247e4bf	Лоперамід	21	2026-03-03 08:45:45.456231+00	2	3	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456232+00	\N	\N	f
d83fa7c2-3311-416f-93da-94b6eb37360c	Рукавички медичні	29	2026-03-24 08:45:45.456249+00	5	0	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456249+00	\N	\N	f
d865acf4-5366-4848-9fbe-40854921b029	Серветки спиртові	7	2028-01-12 08:45:45.456276+00	1	5	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456276+00	\N	\N	f
d86a78d8-66a4-4338-b668-cb61413a716c	Хлоргексидин 0.05%	191	2028-01-25 08:45:45.456306+00	25	1	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456306+00	\N	\N	f
d87b31b6-9daa-451f-b6f3-885a4da15ffe	Атропін 0.1%	16	2026-11-13 08:45:45.456212+00	1	4	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456212+00	\N	\N	f
d90a0c8e-d857-456e-be7c-91ee6c9dddf2	Анальгін 50% (амп.)	21	2027-02-03 08:45:45.456281+00	1	4	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456282+00	\N	\N	f
d944a9de-6ecd-4df8-8a95-b2c071bde058	Джгут гумовий	2	2027-02-12 08:45:45.456246+00	1	0	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456246+00	\N	\N	f
d94e69d3-9a12-4ced-b5cd-e935146208f9	Валідол	12	2026-04-30 08:45:45.456249+00	2	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456249+00	\N	\N	f
dbfce386-352b-4168-bce6-f5fb2854fa14	Лоперамід	24	2026-10-08 08:45:45.456289+00	2	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456289+00	\N	\N	f
dd9dcda1-c381-4c51-9302-c260d8c6471d	Бинт еластичний	3	2026-05-26 08:45:45.456273+00	1	0	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456273+00	\N	\N	f
df56e12a-8747-4ffe-aef8-c9d119dd4cc4	Диклофенак 50мг	11	2027-09-14 08:45:45.456256+00	2	3	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456256+00	\N	\N	f
e06707c8-6253-47a1-a3c0-223c88a96836	Лейкопластир бактерицидний	14	2026-12-07 08:45:45.456216+00	2	0	44457538-eed8-40d0-9186-dca9e4ed9f9f	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456216+00	\N	\N	f
e2609b16-2c58-4d57-af50-486b443d4cea	Бинт стерильний 5м×10см	29	2025-11-04 08:45:45.456246+00	1	0	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456246+00	\N	\N	f
e2ccc763-186e-441d-89a7-677db28b4de9	Бинт марлевий (упаковка)	7	2027-11-20 08:45:45.456222+00	1	5	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456222+00	\N	\N	f
e39605bc-e01a-4d22-889b-28ea96994975	Валідол	27	2026-10-03 08:45:45.456302+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456303+00	\N	\N	f
e4497836-a15c-4a3c-9d7d-5d4e85d34b6f	Серветки спиртові	7	2026-09-26 08:45:45.456255+00	1	5	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456255+00	\N	\N	f
e672696a-5923-4c34-a10d-038cecb3ca6c	Активоване вугілля	22	2027-05-11 08:45:45.456291+00	5	3	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456291+00	\N	\N	f
e754d94a-b409-4ce7-a07f-f06f3f482d66	Лейкопластир бактерицидний	11	2027-12-07 08:45:45.456237+00	2	0	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456237+00	\N	\N	f
e81c391b-3e13-447a-8f5e-cdc11a131ec2	Марля медична	108	2026-11-14 08:45:45.456243+00	25	2	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456243+00	\N	\N	f
e82a2017-aa35-43fd-82db-d72fa31b3659	Джгут гумовий	5	2026-05-15 08:45:45.456272+00	1	0	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456272+00	\N	\N	f
e87a8ea0-c59c-41c1-9e9f-26ee74d16912	Хлоргексидин 0.05%	158	2027-06-29 08:45:45.456238+00	25	1	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456238+00	\N	\N	f
e9ae504e-f41d-4408-a9d4-03fb7eb14ec2	Рукавички медичні	104	2028-01-21 08:45:45.456257+00	5	0	e666c0dc-34e4-41a4-884c-5c4d7a98caed	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456257+00	\N	\N	f
ea0ca3f8-e6b7-4f12-853a-f0714053bb7a	Перекис водню 3%	362	2027-09-19 08:45:45.456233+00	25	1	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456233+00	\N	\N	f
ebfc09a6-9807-47f8-992b-66c9a1d2a9fa	Бинт стерильний 5м×10см	15	2026-05-20 08:45:45.456267+00	1	0	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456267+00	\N	\N	f
ec97388a-9141-446a-8752-898ed0d8ad4f	Вата стерильна	62	2026-11-22 08:45:45.456275+00	12	2	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456275+00	\N	\N	f
ed902559-46fe-4d5e-8dc2-3f0afeb66bb7	Активоване вугілля	72	2028-02-20 08:45:45.4563+00	5	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456301+00	\N	\N	f
edb9bd7e-2e41-424e-83eb-3f9968a570c2	Марля медична	111	2027-05-14 08:45:45.456234+00	25	2	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456234+00	\N	\N	f
f00228e2-35dd-44a6-b5ea-5268d58b8f91	Активоване вугілля	94	2025-11-29 08:45:45.456227+00	5	3	fbe7fcd2-1037-426a-a2c2-107eddad006e	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456228+00	\N	\N	f
f00fd78c-e62d-4280-a46a-4c9f07e12c8c	Фізіологічний розчин 0.9%	997	2026-04-25 08:45:45.456283+00	50	1	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456283+00	\N	\N	f
f0262e20-9ed6-466c-a752-a63db8d2d744	Диклофенак 50мг	34	2028-01-26 08:45:45.456303+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456304+00	\N	\N	f
f0dc1ba4-d948-43de-8341-8dcb005bcd71	Спирт етиловий 70%	203	2027-07-01 08:45:45.456276+00	25	1	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456277+00	\N	\N	f
f18457f6-7c47-4234-ba86-8d6225bf09a1	Фізіологічний розчин 0.9%	816	2026-08-15 08:45:45.456292+00	50	1	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456292+00	\N	\N	f
f1f617e4-7f8e-4cc1-ae16-bc3cd9ef36cb	Дексаметазон 4мг	17	2026-11-14 08:45:45.456284+00	1	4	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456284+00	\N	\N	f
f38d3880-6343-4eac-87b4-e83a2a45072b	Анальгін 50% (амп.)	20	2026-09-13 08:45:45.456231+00	1	4	93091039-76bb-4740-868c-4421685ad968	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456231+00	\N	\N	f
f4d4f0d4-9dfc-478c-a8ea-9e572a076f87	Корвалол	62	2026-09-10 08:45:45.456297+00	6	1	2b7e4daf-cbc9-4ef9-acab-0eefdbcb06fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456297+00	\N	\N	f
f4e486af-f466-4070-8bc4-c236d5d34ca8	Активоване вугілля	61	2027-08-03 08:45:45.456248+00	5	3	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456248+00	\N	\N	f
f731dd62-d319-4731-899b-ded92cba49e8	Магнію сульфат 25%	13	2027-06-21 08:45:45.456288+00	1	4	8b53369c-6b48-45fd-b4df-ce0eb1bdfc03	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456288+00	\N	\N	f
f7b467dd-69af-4097-b258-644a7531cfcb	Марля медична	164	2026-04-12 08:45:45.456282+00	25	2	d999009f-9975-473c-b50b-2e795c35271c	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456282+00	\N	\N	f
f912bb00-9eac-4e71-869e-834752f67208	Анальгін 50% (амп.)	13	2027-05-06 08:45:45.456245+00	1	4	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456245+00	\N	\N	f
fa0045d0-006f-4a85-85e1-05b459a20724	Цитрамон	49	2027-09-15 08:45:45.45627+00	2	3	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45627+00	\N	\N	f
fa4ab3e7-e7f3-4c1d-b00b-c1f85b2b2476	Магнію сульфат 25%	12	2026-06-21 08:45:45.456247+00	1	4	a07b8cb1-b942-4cac-9c94-3f70c71e35ec	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456247+00	\N	\N	f
fd157949-6a08-46e9-980d-7402656d3f33	Аспірин 500мг	51	2027-12-26 08:45:45.456301+00	2	3	c95c544b-7c9e-4c22-8ac8-eef5aed3d662	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456302+00	\N	\N	f
fda8f3d4-b8af-49ca-a13c-0da9c8e16ab8	Нітрогліцерин	23	2026-01-14 08:45:45.45624+00	5	3	618a3475-904f-466b-a192-52be990ea7fe	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.45624+00	\N	\N	f
feb3c7b8-84b9-4d7a-ae3e-4f4a08f99b36	Амоксицилін 500мг	26	2027-08-28 08:45:45.456275+00	2	3	d129b3c4-be09-4e82-bb40-3af9ab8181c9	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456275+00	\N	\N	f
ff199926-ac30-44cc-a032-eb266610da9c	Шприц одноразовий 5мл	13	2027-02-09 08:45:45.456268+00	2	0	f1d00635-0565-4eaf-b4cf-228beb6a8dca	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:45.456268+00	\N	\N	f
00d2a41e-8133-4cdb-adc7-d312c5db1d71	Бинт стерильний 5м×10см	21	2027-11-20 08:45:46.091812+00	1	0	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091812+00	\N	\N	f
0233f84c-117a-4e31-a2ad-2f1fbf27a6f1	Амоксицилін 500мг	38	2027-03-04 08:45:46.091902+00	2	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091902+00	\N	\N	f
0366c314-24b2-498f-87f9-27952338560f	Хлоргексидин 0.05%	342	2026-04-24 08:45:46.091905+00	25	1	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091905+00	\N	\N	f
059fabba-a1e4-4a68-9a76-2b973b72b595	Бинт стерильний 5м×10см	28	2026-08-30 08:45:46.091902+00	1	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091902+00	\N	\N	f
0652bb00-a3f2-47a3-9209-ea4799ace4d5	Анальгін 50% (амп.)	24	2028-02-25 08:45:46.091892+00	1	4	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091893+00	\N	\N	f
08176e1d-540d-4cc6-ba08-f67588b24cd7	Бісептол 480мг	12	2026-12-20 08:45:46.091911+00	2	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091911+00	\N	\N	f
0832b845-d5c3-4c22-8428-321c748be3f5	Парацетамол 500мг	16	2027-02-25 08:45:46.091888+00	2	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091888+00	\N	\N	f
08f3b569-de90-490d-92e0-8a65bef7ea34	Бинт стерильний 5м×10см	28	2026-07-01 08:45:46.091909+00	1	0	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091909+00	\N	\N	f
098b23c8-9e26-4955-acdf-3ddee853bed1	Анальгін 50% (амп.)	25	2026-06-29 08:45:46.091884+00	1	4	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091884+00	\N	\N	f
0a2d4fa9-5fc0-4fae-89c1-1a22841773c0	Цитрамон	20	2027-03-26 08:45:46.091909+00	2	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09191+00	\N	\N	f
0a51b395-eed0-4cbb-aaf0-15502b04fec3	Корвалол	94	2025-11-23 08:45:46.091903+00	6	1	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091903+00	\N	\N	f
0a661afc-3453-4d3d-a4fc-dd78b5b498c6	Дексаметазон 4мг	14	2027-01-29 08:45:46.091911+00	1	4	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091911+00	\N	\N	f
0ab0cec0-ec9b-4caf-9ae4-a48a7437d4af	Парацетамол 500мг	13	2027-08-24 08:45:46.091866+00	2	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091866+00	\N	\N	f
0ab1a7a4-6312-4291-be4e-a70fc71f33ef	Анальгін 50% (амп.)	23	2027-04-15 08:45:46.0918+00	1	4	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.0918+00	\N	\N	f
0f168f01-e54f-497a-bad3-4a19d8b7b7fa	Марля медична	116	2026-11-11 08:45:46.091907+00	25	2	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091907+00	\N	\N	f
0fd360c2-0bad-41a1-8cc9-921ea01f1b9c	Аспірин 500мг	49	2028-03-22 08:45:46.091914+00	2	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091914+00	\N	\N	f
1473ce33-fb53-447b-b262-dc7dff5d6c88	Супрастин 25мг	19	2027-07-07 08:45:46.091908+00	2	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091908+00	\N	\N	f
14cc34a3-e520-4cf6-93c0-3bb0e5c2a15c	Атропін 0.1%	8	2027-02-22 08:45:46.09189+00	1	4	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09189+00	\N	\N	f
18755ff3-cb8a-4692-801b-7076881f7025	Спирт етиловий 70%	317	2027-10-28 08:45:46.091884+00	25	1	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091884+00	\N	\N	f
18ac0224-2e06-453d-9213-707d974ca4dc	Марля медична	391	2026-04-28 08:45:46.091883+00	25	2	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091884+00	\N	\N	f
198e9f5a-e072-4e13-8f57-18525fbd8ff8	Диклофенак 50мг	36	2027-05-26 08:45:46.091873+00	2	3	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091873+00	\N	\N	f
1c93dbae-ce42-4177-8599-7a1c14b29e29	Шприц одноразовий 5мл	37	2026-04-28 08:45:46.091883+00	2	0	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091883+00	\N	\N	f
1dd9a25e-0f93-4dce-992a-3a383a9fdc56	Папаверин 2%	19	2026-11-17 08:45:46.091812+00	1	4	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091812+00	\N	\N	f
1fe34928-a9f8-4985-9c20-88d7d2ca1906	Марля медична	255	2026-07-03 08:45:46.091874+00	25	2	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091874+00	\N	\N	f
20cff5c1-1528-4856-bef2-7216c847d50e	Рукавички медичні	63	2027-10-24 08:45:46.091903+00	5	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091903+00	\N	\N	f
224845da-aa02-4177-9070-7b1f674185e4	Бісептол 480мг	27	2027-01-11 08:45:46.091901+00	2	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091902+00	\N	\N	f
255185f0-370b-4e3c-9c17-36ae0b555976	Нітрогліцерин	31	2027-12-27 08:45:46.091864+00	5	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091865+00	\N	\N	f
2642b544-0fe2-4806-bee6-c9dd087969ea	Серветки спиртові	6	2026-06-10 08:45:46.091885+00	1	5	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091885+00	\N	\N	f
2760e11e-f4d9-4a9a-a375-5f6403795ab7	Розчин йоду 5%	79	2027-01-31 08:45:46.091798+00	6	1	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091798+00	\N	\N	f
285350b4-b8cd-4c8f-b3d0-3c5322d8397a	Анальгін 500мг	60	2026-05-19 08:45:46.091883+00	2	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091883+00	\N	\N	f
28878b0b-1ce7-449c-a1e8-cc136a8eab59	Корвалол	63	2027-07-24 08:45:46.091864+00	6	1	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091864+00	\N	\N	f
28ac84a8-11f7-43d0-a9fd-ec3f2261c402	Валідол	30	2026-08-29 08:45:46.09181+00	2	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09181+00	\N	\N	f
28d0ca73-9224-4968-9ff5-0b58667a9dc8	Бинт стерильний 5м×10см	7	2026-08-23 08:45:46.091919+00	1	0	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09192+00	\N	\N	f
2b2376bd-eb97-4f04-bf20-51469306d0b6	Ібупрофен 200мг	71	2026-11-02 08:45:46.091811+00	2	3	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091811+00	\N	\N	f
2cc510f8-128d-4149-a49c-00baf590f382	Шприц одноразовий 5мл	24	2027-04-23 08:45:46.091815+00	2	0	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091816+00	\N	\N	f
2e5b0556-8664-40fc-a85a-e0e3dcb5d44e	Аспірин 500мг	27	2027-10-26 08:45:46.091814+00	2	3	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091814+00	\N	\N	f
2ee1ab1e-bee3-4b76-81e3-f031f5308968	Но-шпа 40мг	19	2026-09-09 08:45:46.091817+00	2	3	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091817+00	\N	\N	f
3064c34a-f01b-48c4-8c1b-03fec1a615b5	Шприц одноразовий 10мл	11	2026-06-19 08:45:46.091912+00	2	0	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091912+00	\N	\N	f
31495287-e273-48f4-ad85-1fa43890684b	Шприц одноразовий 10мл	46	2026-05-22 08:45:46.091867+00	2	0	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091867+00	\N	\N	f
320260b5-6283-412c-b037-ade284d4892b	Маска медична	37	2028-03-10 08:45:46.091904+00	5	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091905+00	\N	\N	f
33801614-4005-4913-a103-c07ecd3eefca	Розчин йоду 5%	85	2027-10-18 08:45:46.091864+00	6	1	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091864+00	\N	\N	f
34bfbb8e-2eca-4991-b0d7-7c993711b662	Амоксицилін 500мг	39	2027-10-20 08:45:46.091801+00	2	3	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091801+00	\N	\N	f
393d8e57-59ee-4f55-a711-fedf238ace56	Папаверин 2%	22	2027-04-05 08:45:46.091821+00	1	4	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091823+00	\N	\N	f
39890da2-d76f-4efc-a960-82f46038a286	Серветки спиртові	8	2026-12-03 08:45:46.091918+00	1	5	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091918+00	\N	\N	f
3aea1059-a906-4f96-a079-6ac17833853f	Лоратадин 10мг	24	2027-09-25 08:45:46.091823+00	2	3	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091823+00	\N	\N	f
3b3233f2-f096-4b5a-827e-265543913beb	Рукавички медичні	178	2027-05-13 08:45:46.091813+00	5	0	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091813+00	\N	\N	f
3b700cb3-012a-4a9b-872b-c16770209b75	Кеторолак 10мг	18	2025-11-11 08:45:46.091884+00	2	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091885+00	\N	\N	f
3d1e3fc1-d15e-4bda-a5b7-97ae63608ba9	Преднізолон 30мг	17	2027-01-07 08:45:46.091908+00	1	4	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091908+00	\N	\N	f
3d35bf66-a2d1-4e6f-b875-0651b9248756	Дексаметазон 4мг	15	2026-10-03 08:45:46.091904+00	1	4	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091904+00	\N	\N	f
405b737f-42bd-4579-899b-ada40216ddfd	Амоксицилін 500мг	36	2026-11-17 08:45:46.091908+00	2	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091908+00	\N	\N	f
44683f97-a19d-4722-bab5-7cddb55e3cfe	Джгут гумовий	3	2027-05-31 08:45:46.091816+00	1	0	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091816+00	\N	\N	f
44d8c59a-0e43-4444-85f2-96e7297003c2	Спирт етиловий 70%	392	2026-06-11 08:45:46.091908+00	25	1	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091908+00	\N	\N	f
46215089-1d6c-4b74-91cf-d790eb84eb94	Маска медична	85	2026-12-05 08:45:46.09191+00	5	0	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09191+00	\N	\N	f
49d503cf-c57b-4b89-bd68-5aecf234dc65	Джгут гумовий	4	2027-01-10 08:45:46.091813+00	1	0	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091813+00	\N	\N	f
4b4a16a9-dc17-495a-858f-64fa37dadadf	Супрастин 25мг	19	2028-03-11 08:45:46.091868+00	2	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091868+00	\N	\N	f
4c85204c-ae24-4420-8593-4aaa9eddfdcf	Атропін 0.1%	5	2028-02-22 08:45:46.091817+00	1	4	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091817+00	\N	\N	f
4d5976b9-077c-4189-a805-4c0ca05032e2	Корвалол	72	2026-04-28 08:45:46.091809+00	6	1	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09181+00	\N	\N	f
4fb8d214-318d-482c-bfb9-e255aa3f52d0	Маска медична	78	2028-02-22 08:45:46.091814+00	5	0	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091814+00	\N	\N	f
501b46b1-50cd-4af7-a6d0-d91e3251d5c3	Папаверин 2%	17	2027-01-27 08:45:46.091882+00	1	4	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091882+00	\N	\N	f
51672616-b5f1-4bd6-9227-14fc2ab12bcb	Дімедрол 1%	18	2027-05-09 08:45:46.091818+00	1	4	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091818+00	\N	\N	f
5236a153-28ec-41c9-84f5-8665317f6db2	Фізіологічний розчин 0.9%	788	2026-07-08 08:45:46.091868+00	50	1	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091868+00	\N	\N	f
5440a79c-89b8-4edd-9d73-9412707ae0ca	Парацетамол 500мг	31	2026-06-04 08:45:46.091885+00	2	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091886+00	\N	\N	f
54a50431-7569-483b-a325-9a58d5b511ae	Перекис водню 3%	365	2027-10-06 08:45:46.091819+00	25	1	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091819+00	\N	\N	f
556a89af-2616-4112-b2a0-e64e153193f7	Рукавички медичні	186	2028-01-23 08:45:46.091817+00	5	0	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091818+00	\N	\N	f
56691272-970c-4524-9310-9072c6cb911e	Серветки спиртові	10	2027-02-09 08:45:46.091812+00	1	5	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091813+00	\N	\N	f
5afd8068-72c9-4d71-8669-da55c157d310	Но-шпа 40мг	41	2028-01-18 08:45:46.091893+00	2	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091893+00	\N	\N	f
5bf126da-b135-450a-b777-6bde81df8508	Лейкопластир бактерицидний	46	2026-06-25 08:45:46.091919+00	2	0	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091919+00	\N	\N	f
5cebf38c-aaca-42ba-9388-844218c94aac	Магнію сульфат 25%	6	2026-01-13 08:45:46.091885+00	1	4	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091885+00	\N	\N	f
5ea9cba3-70a8-435e-8f0d-a7279d26ed50	Кеторолак 10мг	21	2027-07-15 08:45:46.091913+00	2	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091913+00	\N	\N	f
5f580286-3018-4132-a823-2bd449e82b87	Шприц одноразовий 10мл	18	2026-03-23 08:45:46.091823+00	2	0	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091824+00	\N	\N	f
618e832b-315a-404c-b82d-6997c9187e56	Анальгін 500мг	23	2028-02-07 08:45:46.091808+00	2	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091808+00	\N	\N	f
626580d6-7ee3-40d7-a7e8-d07a0938f75f	Ібупрофен 200мг	72	2027-01-06 08:45:46.091909+00	2	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091909+00	\N	\N	f
63b63257-fb80-4a6d-bd97-6a5c31555ed1	Джгут гумовий	9	2027-11-07 08:45:46.091807+00	1	0	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091807+00	\N	\N	f
640b302f-7632-4158-a468-a8fff313dd5c	Розчин йоду 5%	55	2026-04-17 08:45:46.091907+00	6	1	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091907+00	\N	\N	f
654f828c-bee0-4464-82ab-0619edfc88ba	Амоксицилін 500мг	18	2027-12-31 08:45:46.091892+00	2	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091892+00	\N	\N	f
65e754a9-eef8-4f52-8f87-d7ce63ea6f2f	Бісептол 480мг	40	2026-06-29 08:45:46.091802+00	2	3	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091802+00	\N	\N	f
6988e942-d4e8-498e-821b-905e93944059	Розчин йоду 5%	81	2027-01-06 08:45:46.09189+00	6	1	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091891+00	\N	\N	f
6acd418b-9de4-4c89-809e-4fbb051745bc	Вата стерильна	256	2027-06-07 08:45:46.091918+00	12	2	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091918+00	\N	\N	f
6b00e940-3430-4120-8250-523a3b7096f7	Бинт еластичний	11	2026-10-04 08:45:46.091919+00	1	0	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091919+00	\N	\N	f
6c6539e6-82fc-4b08-9910-c92c26fbf1bd	Перекис водню 3%	221	2026-07-08 08:45:46.091912+00	25	1	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091912+00	\N	\N	f
739d46e7-f992-4962-b0b2-2eea1fd6a412	Преднізолон 30мг	23	2025-12-09 08:45:46.091871+00	1	4	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091871+00	\N	\N	f
73fb2700-0de1-4814-9322-5fb8f9b37f51	Шприц одноразовий 10мл	49	2027-07-09 08:45:46.091892+00	2	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091892+00	\N	\N	f
7475625f-c3e5-406a-8fa3-2a2714274ec1	Розчин йоду 5%	68	2026-05-08 08:45:46.091874+00	6	1	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091875+00	\N	\N	f
75b2132a-9983-4fdd-b5f0-0460bf752be3	Шприц одноразовий 10мл	42	2026-09-03 08:45:46.091919+00	2	0	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091919+00	\N	\N	f
76d9b61c-8a13-41da-8301-990fc0fa6e78	Диклофенак 50мг	15	2027-05-11 08:45:46.091813+00	2	3	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091813+00	\N	\N	f
7a7962bc-f15f-46b5-ac5b-d360396ec493	Папаверин 2%	7	2027-06-13 08:45:46.091891+00	1	4	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091891+00	\N	\N	f
7afa2cf0-7e85-442b-9a45-3823dfa6d17c	Вата стерильна	218	2027-11-09 08:45:46.091873+00	12	2	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091873+00	\N	\N	f
7c40c267-bdfd-45f9-816e-cce09c4a0f91	Вата стерильна	477	2027-09-27 08:45:46.091889+00	12	2	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091889+00	\N	\N	f
7de9f540-a0f2-4f8e-8189-8aa8ae5970f8	Рукавички медичні	166	2026-06-13 08:45:46.09191+00	5	0	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09191+00	\N	\N	f
7e533643-a755-4fda-ae0d-6a06364873e8	Корвалол	72	2027-09-01 08:45:46.09182+00	6	1	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09182+00	\N	\N	f
80a69b72-1791-4d92-87f5-ae4129cf9a20	Спирт етиловий 70%	185	2026-04-11 08:45:46.09181+00	25	1	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09181+00	\N	\N	f
812400b5-91c9-44d0-a270-eef76f4d96fc	Магнію сульфат 25%	25	2026-08-14 08:45:46.091819+00	1	4	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091819+00	\N	\N	f
81931a05-38c3-43a3-9461-13a8a0ca842a	Вата стерильна	486	2026-04-11 08:45:46.091865+00	12	2	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091865+00	\N	\N	f
821baf2f-eb48-4e22-b88b-847262b8f458	Активоване вугілля	63	2027-04-21 08:45:46.091874+00	5	3	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091874+00	\N	\N	f
82f9a848-37f5-4d7b-9252-7876cdda3fc2	Бинт еластичний	4	2027-11-13 08:45:46.091906+00	1	0	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091907+00	\N	\N	f
8312bff5-3664-423e-b7c5-911f5c5afa4c	Хлоргексидин 0.05%	235	2027-08-16 08:45:46.091872+00	25	1	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091872+00	\N	\N	f
831adab6-a913-4939-917f-187cede7d67b	Лейкопластир бактерицидний	17	2027-12-05 08:45:46.091888+00	2	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091888+00	\N	\N	f
83d2f173-e076-466d-a54e-3122c22a7b1c	Валідол	22	2026-06-02 08:45:46.091873+00	2	3	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091873+00	\N	\N	f
878c64bb-5097-4caa-bb0b-8dbd1fabc5dc	Спирт етиловий 70%	381	2026-12-28 08:45:46.091904+00	25	1	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091904+00	\N	\N	f
88f52710-9a02-4993-938c-d91284cf4ef9	Спирт етиловий 70%	460	2027-04-21 08:45:46.091798+00	25	1	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091799+00	\N	\N	f
89f8e123-50e0-46b6-8a17-a52783d152e7	Лоратадин 10мг	25	2025-10-21 08:45:46.091882+00	2	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091882+00	\N	\N	f
8b3f7e9c-b56f-4f1c-84fa-fb4e44d42dd8	Но-шпа 40мг	17	2027-02-07 08:45:46.091809+00	2	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091809+00	\N	\N	f
8c04968d-6fd5-4e6f-97db-8e616035864f	Валідол	24	2026-10-04 08:45:46.091905+00	2	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091905+00	\N	\N	f
8c87f099-57fb-49d0-bce0-5f0d178a10f1	Марля медична	366	2027-12-18 08:45:46.09189+00	25	2	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09189+00	\N	\N	f
8cf81c93-159a-4197-bab9-606577a37b0d	Бинт еластичний	10	2028-03-16 08:45:46.091891+00	1	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091891+00	\N	\N	f
8d1bd813-3198-4fd8-b247-07fd866948f1	Атропін 0.1%	14	2026-06-05 08:45:46.091867+00	1	4	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091867+00	\N	\N	f
8dffbeba-8be5-4e09-a57b-7f579917108f	Парацетамол 500мг	38	2026-04-18 08:45:46.09191+00	2	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091911+00	\N	\N	f
8fc4a8da-f6fe-462d-8132-8fb6c4f16bca	Корвалол	72	2026-08-29 08:45:46.09189+00	6	1	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09189+00	\N	\N	f
8fffe69a-810e-4a80-9965-b5750517b323	Лоперамід	17	2027-08-11 08:45:46.091807+00	2	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091808+00	\N	\N	f
91ca539c-dcd2-47ca-b974-8e37b3003466	Нітрогліцерин	22	2026-02-12 08:45:46.091806+00	5	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091807+00	\N	\N	f
920da960-584a-4784-ad25-972c60ed00b7	Вата стерильна	481	2028-02-09 08:45:46.091821+00	12	2	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091821+00	\N	\N	f
935a316c-da1b-4e1d-8f04-1e6e6c469749	Маска медична	52	2026-12-01 08:45:46.091889+00	5	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091889+00	\N	\N	f
9367f6fa-860d-468c-a4a9-e3040b8ddba1	Вата стерильна	142	2026-01-08 08:45:46.091882+00	12	2	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091882+00	\N	\N	f
9399efbf-5e35-4401-b410-fed9ed9f6098	Лоперамід	14	2026-05-24 08:45:46.091911+00	2	3	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091912+00	\N	\N	f
941ff52a-b6da-4437-a765-c0c9da84c170	Магнію сульфат 25%	17	2027-03-10 08:45:46.091892+00	1	4	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091892+00	\N	\N	f
94f56a95-5b20-4174-b289-1ce0aef8bb4f	Марля медична	182	2026-06-01 08:45:46.091816+00	25	2	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091816+00	\N	\N	f
96f9c2ff-0caf-4382-837f-ba821a1d64d8	Амоксицилін 500мг	40	2026-10-13 08:45:46.091873+00	2	3	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091874+00	\N	\N	f
972e4aad-031c-4740-bb58-9be23b5e38b3	Спирт етиловий 70%	219	2026-06-18 08:45:46.091869+00	25	1	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091869+00	\N	\N	f
99ce64ef-0787-4ac0-adbd-80b818ec7a1b	Лоперамід	21	2027-06-29 08:45:46.091905+00	2	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091905+00	\N	\N	f
99eddb55-77fc-468e-b922-e5d09198ae12	Джгут гумовий	7	2026-08-26 08:45:46.091799+00	1	0	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.0918+00	\N	\N	f
99f037ef-d4b6-46a6-b79e-ade2f8464793	Серветки спиртові	3	2026-12-06 08:45:46.091871+00	1	5	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091872+00	\N	\N	f
9a4c1490-0c78-4963-9899-2c43d499f96a	Маска медична	193	2026-11-27 08:45:46.0918+00	5	0	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091801+00	\N	\N	f
9b61a217-9f40-475e-be5a-29d7962631a9	Парацетамол 500мг	37	2027-12-28 08:45:46.091816+00	2	3	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091816+00	\N	\N	f
9e153dcc-0277-4ed9-a5d1-02ddf0a374f6	Анальгін 500мг	52	2027-09-20 08:45:46.091816+00	2	3	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091817+00	\N	\N	f
9ed99e4f-cbb6-44a3-8f98-1fc521a84fa6	Рукавички медичні	52	2026-06-25 08:45:46.091885+00	5	0	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091885+00	\N	\N	f
a2511a81-f29b-4b47-9d30-e8cec6b1173f	Рукавички медичні	67	2026-11-28 08:45:46.091889+00	5	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091889+00	\N	\N	f
a251778e-654b-4934-9d21-14bd030dc089	Адреналін 0.1%	16	2027-09-21 08:45:46.091819+00	1	4	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09182+00	\N	\N	f
a3bfb4ab-9ad8-4cd2-ae8b-14b3ed83bfa7	Шприц одноразовий 10мл	48	2026-04-12 08:45:46.091884+00	2	0	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091884+00	\N	\N	f
a4d6a826-7244-4b99-add8-c9a333167d7b	Рукавички медичні	137	2026-10-30 08:45:46.091799+00	5	0	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091799+00	\N	\N	f
a52e84a3-5a24-45d5-9657-b9438e5f59e0	Анальгін 500мг	21	2026-08-29 08:45:46.0919+00	2	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.0919+00	\N	\N	f
a5e93dc9-6067-454a-897d-1234c7de5f5e	Дімедрол 1%	11	2026-05-08 08:45:46.091909+00	1	4	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091909+00	\N	\N	f
a88491b6-c5a5-410f-951d-e360d5937061	Серветки спиртові	2	2026-05-05 08:45:46.091818+00	1	5	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091818+00	\N	\N	f
a9080ba2-70b9-48b5-bed8-2c72dd602414	Валідол	14	2028-02-17 08:45:46.091913+00	2	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091913+00	\N	\N	f
a9d96f8d-74d1-460b-a9ad-255df06a5891	Ібупрофен 200мг	65	2028-02-09 08:45:46.091868+00	2	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091868+00	\N	\N	f
ab132c6b-3b1c-492e-b4e7-8eef9090c8a5	Бинт марлевий (упаковка)	1	2026-09-09 08:45:46.091801+00	1	5	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091801+00	\N	\N	f
ab43f033-ccb2-4ce7-bd88-d02575658c7c	Ібупрофен 200мг	15	2026-12-25 08:45:46.091893+00	2	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091893+00	\N	\N	f
af3d7852-bdbe-471d-bd9e-efbfa729ddf0	Джгут гумовий	9	2027-02-07 08:45:46.091863+00	1	0	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091863+00	\N	\N	f
afca9e76-ea9c-4bdd-8517-cacea3e185f6	Серветки спиртові	6	2026-05-31 08:45:46.091907+00	1	5	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091907+00	\N	\N	f
b0ce57c4-c6e6-4422-b51f-d131d5f48aba	Бинт еластичний	15	2028-03-25 08:45:46.0918+00	1	0	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.0918+00	\N	\N	f
b0ee81f4-252b-444a-81ec-8751dee436a9	Диклофенак 50мг	37	2026-05-28 08:45:46.091817+00	2	3	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091817+00	\N	\N	f
b1c9bf80-ebb5-4626-a137-455ea71e4514	Бісептол 480мг	19	2026-01-25 08:45:46.091867+00	2	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091868+00	\N	\N	f
b2e1430c-2ca5-457f-868e-3da4cf2d2c22	Бісептол 480мг	12	2027-05-22 08:45:46.091808+00	2	3	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091808+00	\N	\N	f
b4345ac6-3330-40f1-8edb-645410273aee	Серветки спиртові	2	2028-01-24 08:45:46.091802+00	1	5	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091802+00	\N	\N	f
b44289f9-67f1-4f6e-ad1c-089175922930	Активоване вугілля	35	2027-09-04 08:45:46.09182+00	5	3	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091821+00	\N	\N	f
b4923685-49b9-4b23-8271-0b495c8b45fc	Спирт етиловий 70%	476	2027-12-07 08:45:46.091893+00	25	1	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.0919+00	\N	\N	f
ba02a1ce-5e12-4e0a-8728-0fcd67e95b55	Розчин брильянтового зеленого	48	2026-10-17 08:45:46.091811+00	6	1	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091811+00	\N	\N	f
be9f387d-74c2-4b8e-afe6-2c8e70c4c407	Цитрамон	39	2026-06-02 08:45:46.091902+00	2	3	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091902+00	\N	\N	f
bebae3af-d99e-4992-8da0-c46c5a1a49a2	Корвалол	86	2026-10-02 08:45:46.091801+00	6	1	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091801+00	\N	\N	f
c41351c8-d85e-4020-bcb2-420a854cfd7f	Атропін 0.1%	19	2028-01-12 08:45:46.091797+00	1	4	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091797+00	\N	\N	f
c4ac4d30-3c33-477e-b610-496771bacb5d	Но-шпа 40мг	39	2026-08-27 08:45:46.091812+00	2	3	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091812+00	\N	\N	f
c4ec9508-3ecd-45c2-a48b-0f8d1a3b336d	Папаверин 2%	24	2027-06-28 08:45:46.091797+00	1	4	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091797+00	\N	\N	f
c5611aaf-bc9e-40de-91cc-b6b12455aaee	Марля медична	266	2027-09-13 08:45:46.091868+00	25	2	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091869+00	\N	\N	f
c5ff54a4-fffc-48c4-b651-c90d63a12ad1	Преднізолон 30мг	19	2027-10-05 08:45:46.091889+00	1	4	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091889+00	\N	\N	f
c80a7770-23c4-4476-b9b0-e91908016cf0	Перекис водню 3%	451	2027-11-30 08:45:46.091901+00	25	1	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091901+00	\N	\N	f
c9c9e236-f458-47e9-8a8f-0380d8110094	Дексаметазон 4мг	24	2027-03-03 08:45:46.091808+00	1	4	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091808+00	\N	\N	f
cd6c7d16-c577-4fc4-9747-cffd80fe19a8	Диклофенак 50мг	22	2027-07-17 08:45:46.091865+00	2	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091865+00	\N	\N	f
ce2ec85b-0cb2-4b8a-9cef-5918c524d46d	Дексаметазон 4мг	17	2027-05-14 08:45:46.091818+00	1	4	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091819+00	\N	\N	f
d410e8df-dbd4-4cfa-b482-293e6df9f293	Нітрогліцерин	33	2026-06-01 08:45:46.091872+00	5	3	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091873+00	\N	\N	f
da1050e1-aeb2-40d2-acf0-bddf0b1f42ee	Розчин йоду 5%	53	2025-11-14 08:45:46.091819+00	6	1	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091819+00	\N	\N	f
db51c874-f91a-4f18-bed6-527c722f3aad	Шприц одноразовий 5мл	30	2028-01-07 08:45:46.091893+00	2	0	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091893+00	\N	\N	f
dbd94429-7cb3-41ae-b35b-b42dc0d25681	Рукавички медичні	92	2027-01-26 08:45:46.091866+00	5	0	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091866+00	\N	\N	f
dc96e01c-5435-4fc5-a5d2-2be0fe92524b	Супрастин 25мг	21	2026-05-27 08:45:46.091913+00	2	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091914+00	\N	\N	f
dd0f0957-0804-4f76-845b-4380275217de	Перекис водню 3%	262	2026-04-19 08:45:46.091883+00	25	1	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091883+00	\N	\N	f
dd2d1eb1-64a7-4590-939c-8a6f027be965	Активоване вугілля	38	2026-05-03 08:45:46.091866+00	5	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091866+00	\N	\N	f
e27fb8ab-19d4-4339-b318-5e83a6efc829	Адреналін 0.1%	13	2027-10-18 08:45:46.091814+00	1	4	96cfdf35-e54e-4785-ae4b-0bac61199794	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091814+00	\N	\N	f
e3180bf6-e3da-4cd7-a0d1-203c7cf82c3e	Лейкопластир бактерицидний	36	2027-08-21 08:45:46.091904+00	2	0	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091904+00	\N	\N	f
e41c227c-ff79-478b-9d38-c20c21a3f083	Аспірин 500мг	48	2027-04-20 08:45:46.091865+00	2	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091865+00	\N	\N	f
e49ef411-700a-45eb-8db0-e3ee57dc9a97	Активоване вугілля	47	2027-05-27 08:45:46.091891+00	5	3	a4ad4bf8-435b-44ec-87fd-6b9cea759b36	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091891+00	\N	\N	f
e752a1b3-f26a-4e06-8914-e55697f560eb	Но-шпа 40мг	21	2027-01-01 08:45:46.091799+00	2	3	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091799+00	\N	\N	f
e7ade211-8827-4797-bf5c-a164f89c14dd	Серветки спиртові	7	2026-04-28 08:45:46.091903+00	1	5	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091903+00	\N	\N	f
e8c3c2ee-b505-4333-ad26-3b5c197e05b4	Розчин брильянтового зеленого	80	2026-06-16 08:45:46.091867+00	6	1	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091867+00	\N	\N	f
e8f27bc2-11ed-45fd-a5c4-99555d708003	Магнію сульфат 25%	7	2026-04-28 08:45:46.091809+00	1	4	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091809+00	\N	\N	f
ea0acfb8-68c6-4211-959d-c23fec252073	Розчин йоду 5%	87	2026-09-28 08:45:46.091807+00	6	1	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091807+00	\N	\N	f
ece29b49-9c81-4173-b6d3-bc7a70179402	Анальгін 500мг	59	2026-12-07 08:45:46.091918+00	2	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091919+00	\N	\N	f
ed304ee4-3901-4fc2-9b55-b3dab0e49c4b	Лоперамід	25	2027-10-25 08:45:46.091874+00	2	3	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091874+00	\N	\N	f
ee448f85-24ad-4c5f-a7c1-f3fc97492c1b	Лоперамід	16	2027-02-18 08:45:46.091863+00	2	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091864+00	\N	\N	f
ef3cf8ac-cb94-4602-9c67-f387327b636f	Кеторолак 10мг	38	2026-08-12 08:45:46.09182+00	2	3	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09182+00	\N	\N	f
efee114e-3707-4b7e-9637-fba8613d7898	Бісептол 480мг	13	2027-01-24 08:45:46.091824+00	2	3	0241c840-f709-4030-a7c3-4780bc84e743	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091824+00	\N	\N	f
f2194af4-056a-4f1b-90a7-b903986e2b7a	Лоперамід	18	2027-08-10 08:45:46.091795+00	2	3	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091796+00	\N	\N	f
f2da7d61-558d-42ec-9d9a-2625b3ade7fe	Вата стерильна	177	2028-02-01 08:45:46.091797+00	12	2	03c26c05-1356-48b7-9f81-e802098016e0	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091798+00	\N	\N	f
f32624c3-9d0e-49cc-a3cd-34b999da6e77	Парацетамол 500мг	74	2027-04-20 08:45:46.091914+00	2	3	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091914+00	\N	\N	f
f336e052-53e9-4c1d-8b78-858910316de6	Магнію сульфат 25%	9	2026-06-05 08:45:46.091903+00	1	4	57f31d29-fb5e-4cfa-ab47-0318d16efaac	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091903+00	\N	\N	f
f3a7de1b-7104-45fb-9507-53cce062c30a	Супрастин 25мг	21	2026-05-03 08:45:46.091872+00	2	3	4b92861f-c987-4786-a375-f284f41e658c	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091872+00	\N	\N	f
f96a7566-1c37-4868-9720-a3bce5033dec	Хлоргексидин 0.05%	177	2026-05-24 08:45:46.091808+00	25	1	dd2fb9ff-a18c-4c22-8f15-3be96e14d554	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091809+00	\N	\N	f
f98fec6a-721d-407d-b342-0cd24ebd7575	Лоратадин 10мг	20	2026-05-08 08:45:46.091865+00	2	3	e8ab6cc3-8374-4102-b680-0e8cc0354cb3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091866+00	\N	\N	f
fadcc57b-3085-4705-8573-97446bb612ea	Магнію сульфат 25%	15	2027-03-26 08:45:46.09191+00	1	4	f6e6f5d3-630b-4902-8358-7b6e3af39038	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.09191+00	\N	\N	f
fc872dee-effa-4a20-aa0c-3256c121f420	Хлоргексидин 0.05%	488	2027-02-19 08:45:46.091914+00	25	1	c6e912f5-28db-4b92-80a1-f5e3d7819846	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091918+00	\N	\N	f
fd1b7611-3daa-4e18-90eb-a85142c86868	Бісептол 480мг	15	2026-05-16 08:45:46.091882+00	2	3	5878a5da-6011-4ff8-bec3-b56cee1ea7f5	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:46.091882+00	\N	\N	f
00291cc5-cb5d-4121-8125-cb7572da1f7f	Супрастин 25мг	24	2026-11-25 08:45:46.766222+00	2	3	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766223+00	\N	\N	f
002e6bbd-5cec-49bb-8a90-808245c3bd97	Спирт етиловий 70%	435	2028-01-26 08:45:46.766204+00	25	1	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766205+00	\N	\N	f
007f6df1-77c0-47af-b275-601ad21f45f5	Парацетамол 500мг	60	2026-05-20 08:45:46.766233+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766233+00	\N	\N	f
01ad7ba7-a3e7-4343-a035-14b005c3ccf4	Активоване вугілля	20	2026-04-04 08:45:46.766189+00	5	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76619+00	\N	\N	f
0341b0bf-6d71-4180-8735-8fdb9ff95f1e	Активоване вугілля	85	2027-01-05 08:45:46.766184+00	5	3	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766184+00	\N	\N	f
034261d1-a8f5-46c1-bb41-c663a3eb54a5	Нітрогліцерин	52	2027-10-23 08:45:46.766213+00	5	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766214+00	\N	\N	f
0354b116-29f4-455f-b0fe-729ba73dbe44	Дімедрол 1%	19	2026-05-17 08:45:46.76622+00	1	4	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766221+00	\N	\N	f
0369c7ab-c603-421c-af8f-0a20328a46f6	Анальгін 500мг	11	2027-12-15 08:45:46.766234+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766234+00	\N	\N	f
0502fb91-d08a-42b4-add6-cafccdcfbe80	Папаверин 2%	9	2027-01-24 08:45:46.766239+00	1	4	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76624+00	\N	\N	f
05b32500-f506-4dc5-9e89-9dc31c255823	Кеторолак 10мг	20	2026-06-01 08:45:46.766237+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766237+00	\N	\N	f
05ee352b-5724-4c06-a430-dcd3c7e0d7be	Бинт еластичний	12	2026-09-14 08:45:46.766233+00	1	0	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766233+00	\N	\N	f
0617f19a-b654-40f6-91c1-53e30c94f3f1	Бинт марлевий (упаковка)	2	2027-12-14 08:45:46.766175+00	1	5	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766175+00	\N	\N	f
0744e7ef-02ca-41b0-86fb-ffd2e387497e	Папаверин 2%	17	2026-05-08 08:45:46.766144+00	1	4	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766144+00	\N	\N	f
090ad19f-091d-4556-a62b-c432c870f37e	Но-шпа 40мг	12	2026-04-27 08:45:46.766181+00	2	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766181+00	\N	\N	f
099e05df-e653-4e85-b6a3-b1b8fd33c7da	Анальгін 50% (амп.)	16	2028-03-30 08:45:46.766176+00	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766176+00	\N	\N	f
0adbe4c1-39e5-4f0f-8b11-2516cd026d99	Анальгін 500мг	60	2026-03-23 08:45:46.76619+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76619+00	\N	\N	f
0bac0e0d-db9a-4195-be28-716950c05c76	Магнію сульфат 25%	8	2025-12-13 08:45:46.766193+00	1	4	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766193+00	\N	\N	f
0c6dc1cc-8fe2-4270-9807-451bb811d3de	Джгут гумовий	10	2026-06-29 08:45:46.76623+00	1	0	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76623+00	\N	\N	f
0d10cad2-a2bd-4a30-8d46-afc278a8f48e	Атропін 0.1%	7	2026-08-28 08:45:46.766199+00	1	4	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766199+00	\N	\N	f
0d1bf9f9-b9bc-4c14-81f2-33f8bf788399	Марля медична	380	2026-05-01 08:45:46.76615+00	25	2	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76615+00	\N	\N	f
0ee395ed-b441-4286-846a-1be0374c8941	Шприц одноразовий 10мл	12	2026-06-13 08:45:46.766237+00	2	0	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766237+00	\N	\N	f
1324626f-ffb2-4c8d-ab9f-a27b1c46250d	Кеторолак 10мг	13	2026-06-22 08:45:46.766216+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766216+00	\N	\N	f
14583606-3847-41e2-bbd8-2b0208f6e3ea	Бинт еластичний	5	2027-01-02 08:45:46.766201+00	1	0	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766201+00	\N	\N	f
1537f79d-638b-454e-b7f7-2dccfb82d5d1	Папаверин 2%	14	2027-04-08 08:45:46.766217+00	1	4	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766217+00	\N	\N	f
18bfcc8f-8fd0-4fd3-8140-85be60816397	Адреналін 0.1%	18	2027-02-10 08:45:46.766199+00	1	4	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.7662+00	\N	\N	f
197ef348-c95f-42e0-8533-0abdb266eceb	Цитрамон	47	2026-06-02 08:45:46.766146+00	2	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766146+00	\N	\N	f
1a51a5e9-0136-4e0a-bc5e-a6b49d699705	Атропін 0.1%	16	2025-11-02 08:45:46.766191+00	1	4	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766191+00	\N	\N	f
1abff39c-b244-43c0-8da8-7528ae09673d	Амоксицилін 500мг	21	2027-10-22 08:45:46.766236+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766236+00	\N	\N	f
1ba31f70-de55-4a2a-a610-6d87962e068b	Кеторолак 10мг	10	2026-07-08 08:45:46.766153+00	2	3	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766154+00	\N	\N	f
1be5db61-6bf7-4bff-b17b-05b804dab585	Папаверин 2%	23	2026-08-22 08:45:46.766208+00	1	4	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766209+00	\N	\N	f
1cb36e2a-cb1a-44c1-8721-66ab51d8e7d2	Розчин йоду 5%	85	2026-10-20 08:45:46.766229+00	6	1	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76623+00	\N	\N	f
1dd5be0f-ad7c-47d0-98f3-8a0a331b9fac	Хлоргексидин 0.05%	241	2026-03-13 08:45:46.766191+00	25	1	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766191+00	\N	\N	f
1f35927c-160e-473f-b2b8-a8eed7404319	Спирт етиловий 70%	274	2026-04-28 08:45:46.766162+00	25	1	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766163+00	\N	\N	f
1fbd89de-219e-4ae0-af21-9ab304f7f348	Вата стерильна	437	2027-09-21 08:45:46.766176+00	12	2	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766177+00	\N	\N	f
20b79c6b-e71b-4219-9662-248fa8f61271	Корвалол	59	2027-08-27 08:45:46.766218+00	6	1	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766218+00	\N	\N	f
20d46aab-9a7d-4311-8c05-0f403c1a8017	Атропін 0.1%	8	2027-03-29 08:45:46.766232+00	1	4	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766233+00	\N	\N	f
2661a2ce-7c99-40aa-908a-cc68a3c0f144	Лоперамід	23	2026-06-05 08:45:46.766187+00	2	3	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766187+00	\N	\N	f
27f0a409-c0de-439f-8f09-0c6e8c0c527d	Шприц одноразовий 10мл	28	2028-03-17 08:45:46.766221+00	2	0	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766222+00	\N	\N	f
28ab9adf-ab70-4a6f-ae49-c59977689730	Шприц одноразовий 5мл	13	2026-06-30 08:45:46.766164+00	2	0	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766164+00	\N	\N	f
2a2e2ccc-4870-44da-8978-61f5f32da67d	Супрастин 25мг	27	2026-05-09 08:45:46.766187+00	2	3	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766187+00	\N	\N	f
2aac9dee-c79d-47cd-928c-8680f8e90c32	Шприц одноразовий 5мл	30	2025-12-22 08:45:46.766153+00	2	0	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766153+00	\N	\N	f
2ee911ff-6a83-4ee0-b5c3-d4af7e8d405f	Вата стерильна	391	2028-01-17 08:45:46.766217+00	12	2	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766217+00	\N	\N	f
2f57d3eb-4293-4a35-b3e5-d0affb09de19	Бісептол 480мг	22	2026-07-09 08:45:46.766189+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766189+00	\N	\N	f
3132a3d2-c424-491a-bb32-198738446ddc	Шприц одноразовий 5мл	39	2026-03-12 08:45:46.766172+00	2	0	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766173+00	\N	\N	f
31abdff8-ba1a-4f90-a0ca-7473005db07f	Кеторолак 10мг	30	2027-04-28 08:45:46.7662+00	2	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.7662+00	\N	\N	f
32c21b65-36de-44e6-b698-be64486f305c	Розчин брильянтового зеленого	86	2026-04-22 08:45:46.766172+00	6	1	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766172+00	\N	\N	f
3331936b-7c9d-4611-b3d5-37a994b6002d	Бинт марлевий (упаковка)	3	2026-05-27 08:45:46.766149+00	1	5	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76615+00	\N	\N	f
34adb844-d92e-4d5f-bde9-b00d4dd0b8a5	Папаверин 2%	17	2027-12-01 08:45:46.766236+00	1	4	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766237+00	\N	\N	f
352a16a8-359d-4136-8f6b-22ab6f947dda	Розчин йоду 5%	45	2025-10-26 08:45:46.766238+00	6	1	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766238+00	\N	\N	f
37586a22-4dcd-4733-aad6-da8ce4645072	Амоксицилін 500мг	14	2026-05-10 08:45:46.76624+00	2	3	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76624+00	\N	\N	f
376e9ca9-3a0c-4c74-9a18-eb0925dd6098	Бісептол 480мг	25	2027-01-06 08:45:46.766226+00	2	3	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766227+00	\N	\N	f
3783adb8-b732-4809-b852-74a60f15b032	Нітрогліцерин	50	2027-10-30 08:45:46.766147+00	5	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766147+00	\N	\N	f
3801af7f-e960-4ff4-8f2c-2645f18d19b7	Корвалол	100	2026-06-28 08:45:46.766185+00	6	1	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766185+00	\N	\N	f
39b5cdb3-b8d3-4521-920d-3183c8a3b24a	Шприц одноразовий 10мл	18	2026-01-13 08:45:46.766159+00	2	0	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766159+00	\N	\N	f
3b1e5e54-62c3-477e-984d-45c99ec77770	Хлоргексидин 0.05%	278	2028-03-12 08:45:46.766222+00	25	1	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766222+00	\N	\N	f
3b6082a9-e9b1-45cb-a823-bb8edf11611a	Диклофенак 50мг	16	2026-05-22 08:45:46.766162+00	2	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766162+00	\N	\N	f
3d976f1a-6900-4125-ace3-60f6ea7e9b8d	Бинт еластичний	11	2026-08-08 08:45:46.766226+00	1	0	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766226+00	\N	\N	f
3deaf843-850b-4961-9466-091cd674aff9	Папаверин 2%	20	2027-03-17 08:45:46.766201+00	1	4	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766201+00	\N	\N	f
3e1e3102-fc1d-4be3-8c17-bd0a85728d89	Цитрамон	24	2026-07-01 08:45:46.766186+00	2	3	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766186+00	\N	\N	f
3f3a9605-2896-42d0-b7b4-d5be76d95317	Рукавички медичні	93	2026-04-20 08:45:46.766242+00	5	0	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766242+00	\N	\N	f
3f7639eb-6b3f-459b-b24a-c8c1b20a8c85	Дексаметазон 4мг	25	2026-04-19 08:45:46.766147+00	1	4	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766148+00	\N	\N	f
40473f79-f3c2-442d-8f51-e0abc0a31067	Анальгін 50% (амп.)	12	2026-04-28 08:45:46.766162+00	1	4	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766162+00	\N	\N	f
414035e0-22d9-48a8-b562-9282b3fdf261	Бинт еластичний	5	2027-02-17 08:45:46.766207+00	1	0	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766207+00	\N	\N	f
42247443-5b99-4418-80d3-b4a28bd7a96b	Лоперамід	17	2026-05-27 08:45:46.766181+00	2	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766181+00	\N	\N	f
42b5b57a-24c9-48ef-ba9d-96bb33325b46	Анальгін 50% (амп.)	22	2026-12-31 08:45:46.766222+00	1	4	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766222+00	\N	\N	f
42e292b8-82a5-4ef2-8645-2106db8502d6	Атропін 0.1%	17	2026-09-24 08:45:46.766209+00	1	4	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766212+00	\N	\N	f
4323d5d3-9d2b-4bc2-ae50-949c355bf31f	Серветки спиртові	4	2027-04-29 08:45:46.766221+00	1	5	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766221+00	\N	\N	f
43a4ba98-7f7c-454d-a188-08550a14a3d1	Перекис водню 3%	260	2027-06-29 08:45:46.766202+00	25	1	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766202+00	\N	\N	f
44d0c03b-b9ce-4a30-8cd8-458393e5d35e	Лоперамід	27	2026-11-29 08:45:46.766225+00	2	3	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766225+00	\N	\N	f
47012c23-aaf9-4435-9cff-6dd671241279	Супрастин 25мг	24	2025-10-31 08:45:46.766173+00	2	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766174+00	\N	\N	f
472097f7-03bc-4ae7-8d0a-f31c843d0f62	Марля медична	364	2027-11-24 08:45:46.76619+00	25	2	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76619+00	\N	\N	f
47b9d091-047f-4550-851e-4baadaf849bf	Фізіологічний розчин 0.9%	681	2027-07-07 08:45:46.766207+00	50	1	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766207+00	\N	\N	f
48170bb2-14f9-4817-8c6a-a22d367f9a1d	Маска медична	129	2027-06-30 08:45:46.766218+00	5	0	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766219+00	\N	\N	f
48ad7a07-2ffe-4573-8107-0a6b8b2be65c	Атропін 0.1%	11	2026-05-18 08:45:46.766147+00	1	4	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766147+00	\N	\N	f
4932f665-1b0b-4d82-b879-3e74fd9cb049	Нітрогліцерин	31	2026-06-10 08:45:46.766152+00	5	3	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766152+00	\N	\N	f
49acfee5-303d-4d29-8983-3ff3881075fb	Атропін 0.1%	20	2026-11-03 08:45:46.766181+00	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766181+00	\N	\N	f
4aadd7d8-f129-4dc8-ad75-e955108dc0cd	Валідол	13	2027-05-13 08:45:46.766148+00	2	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766148+00	\N	\N	f
4c827684-faa9-40a0-a345-9508ebf2c386	Перекис водню 3%	258	2027-04-08 08:45:46.766219+00	25	1	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766219+00	\N	\N	f
4c8e820f-1424-447a-bbf6-ea3129f84b74	Бинт марлевий (упаковка)	3	2027-06-23 08:45:46.766214+00	1	5	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766214+00	\N	\N	f
4fa8e490-121c-4691-92bb-4c4263f815f5	Рукавички медичні	115	2027-10-25 08:45:46.766217+00	5	0	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766217+00	\N	\N	f
4fe4312b-6b7e-477b-b52e-04c998002f3a	Адреналін 0.1%	20	2027-06-01 08:45:46.766248+00	1	4	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766249+00	\N	\N	f
50986e92-0be7-44f4-8076-d0c317c28c59	Дімедрол 1%	12	2026-05-31 08:45:46.766175+00	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766175+00	\N	\N	f
50df8bff-7370-4af8-88d2-84ed885f238a	Серветки спиртові	6	2027-05-30 08:45:46.766225+00	1	5	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766226+00	\N	\N	f
50edd8ad-7577-4eca-affb-3719ca02d0b0	Шприц одноразовий 10мл	46	2026-12-11 08:45:46.766204+00	2	0	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766204+00	\N	\N	f
51b1adfc-2d1d-4613-ac18-f18f342823c4	Цитрамон	25	2027-06-25 08:45:46.766199+00	2	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766199+00	\N	\N	f
5258113c-7e9f-4fd1-9c68-1416f894b187	Перекис водню 3%	413	2025-12-25 08:45:46.766183+00	25	1	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766184+00	\N	\N	f
528f01c6-49e8-48d2-98c0-5c3a13f7658f	Анальгін 500мг	42	2028-02-28 08:45:46.766199+00	2	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766199+00	\N	\N	f
52c6ad8f-a5a7-4755-8f44-7f98ddd91205	Ібупрофен 200мг	21	2026-10-21 08:45:46.766203+00	2	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766204+00	\N	\N	f
5419bb52-7687-409b-80f1-3845eabc6f5a	Аспірин 500мг	19	2025-10-23 08:45:46.766185+00	2	3	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766185+00	\N	\N	f
545fa611-5a2f-4f1a-bc84-eabd9c3d7402	Адреналін 0.1%	11	2027-12-19 08:45:46.766207+00	1	4	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766207+00	\N	\N	f
5582359c-2537-4554-9f43-752e125801e5	Диклофенак 50мг	33	2027-07-31 08:45:46.766208+00	2	3	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766208+00	\N	\N	f
55dd186a-134f-4a99-a90c-feaab12041b8	Ібупрофен 200мг	46	2027-06-19 08:45:46.766192+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766192+00	\N	\N	f
56a8056b-84f4-4535-be01-4d3ce70dc80a	Бинт стерильний 5м×10см	7	2027-03-12 08:45:46.76616+00	1	0	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76616+00	\N	\N	f
56bb291e-6903-4fdd-9e03-6e063ef14b01	Бісептол 480мг	24	2026-10-16 08:45:46.76624+00	2	3	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766241+00	\N	\N	f
57fc18ec-efc3-46c8-b210-80b6871ef982	Кеторолак 10мг	38	2027-05-01 08:45:46.766192+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766193+00	\N	\N	f
595540aa-b3de-433c-9e58-59687dd3229e	Супрастин 25мг	30	2026-06-12 08:45:46.76624+00	2	3	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76624+00	\N	\N	f
5a1367b7-150f-4677-9fea-f14ac863d34c	Спирт етиловий 70%	321	2026-07-08 08:45:46.766234+00	25	1	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766234+00	\N	\N	f
5b941b60-84fe-4cad-8f28-b25bbb4a7a45	Ібупрофен 200мг	32	2026-03-28 08:45:46.766165+00	2	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766165+00	\N	\N	f
5c708b70-33e7-4fb6-b374-8942239d32ac	Дімедрол 1%	23	2026-10-05 08:45:46.766203+00	1	4	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766203+00	\N	\N	f
5d1545b5-69e1-4015-953f-7532b7dd9a61	Бісептол 480мг	34	2027-12-13 08:45:46.766148+00	2	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766149+00	\N	\N	f
5dc53dfd-4c9b-48f7-833a-8d00ae889b98	Анальгін 50% (амп.)	18	2027-10-19 08:45:46.766208+00	1	4	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766208+00	\N	\N	f
5dfa498e-ac07-467d-a956-7f0c06747340	Нітрогліцерин	25	2026-05-07 08:45:46.766165+00	5	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766166+00	\N	\N	f
5e217364-61c0-4af1-af7c-2d652603c012	Дексаметазон 4мг	17	2027-01-31 08:45:46.766226+00	1	4	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766226+00	\N	\N	f
5f2414c1-5108-47ee-85fe-d369bc5fdc05	Дімедрол 1%	18	2026-04-16 08:45:46.766235+00	1	4	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766235+00	\N	\N	f
60e75533-eb24-41ec-bf92-f79015625efa	Маска медична	102	2027-10-14 08:45:46.766164+00	5	0	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766165+00	\N	\N	f
62c28739-a067-4db7-9132-8d621c9397fb	Рукавички медичні	24	2027-11-16 08:45:46.766208+00	5	0	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766208+00	\N	\N	f
64f8806b-9773-407b-9fab-6349a8736ce3	Корвалол	79	2026-12-06 08:45:46.766231+00	6	1	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766231+00	\N	\N	f
680b18e7-6c21-4244-ac09-b32cf0a03573	Магнію сульфат 25%	9	2026-04-21 08:45:46.766173+00	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766173+00	\N	\N	f
6847abae-026b-49e2-8acd-ce0cf56c2609	Лоратадин 10мг	12	2027-04-20 08:45:46.766243+00	2	3	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766246+00	\N	\N	f
6899b23b-2ef7-46b1-aa36-a1a7ea39bc70	Фізіологічний розчин 0.9%	823	2026-10-21 08:45:46.766186+00	50	1	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766186+00	\N	\N	f
68c106a2-dfa3-4029-8515-5336c9284261	Серветки спиртові	2	2026-09-03 08:45:46.766186+00	1	5	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766186+00	\N	\N	f
68e88e27-dd00-4df2-9a7b-23ab54016048	Лоратадин 10мг	15	2026-06-30 08:45:46.766174+00	2	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766175+00	\N	\N	f
6989eadc-d4ad-41ff-81f3-7203e496c88c	Розчин йоду 5%	70	2027-05-28 08:45:46.766241+00	6	1	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766241+00	\N	\N	f
69bcbd1d-2eb3-4842-a9ca-41a501c95df0	Дімедрол 1%	21	2027-08-30 08:45:46.766226+00	1	4	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766226+00	\N	\N	f
6ae873d9-57f7-40af-984a-58ac3ac26f15	Серветки спиртові	9	2026-04-28 08:45:46.766194+00	1	5	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766194+00	\N	\N	f
6af29d62-c542-4b70-abf0-3cd311da90fa	Серветки спиртові	9	2027-02-07 08:45:46.766175+00	1	5	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766175+00	\N	\N	f
6c675d01-3e4d-4dc4-9ab3-23e616691036	Корвалол	94	2027-01-28 08:45:46.766161+00	6	1	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766161+00	\N	\N	f
6cb0ebcc-0970-4a9f-9461-b18281b26857	Марля медична	192	2027-05-28 08:45:46.766242+00	25	2	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766242+00	\N	\N	f
6d216417-1f9c-4e88-88a1-a9f411496d19	Ібупрофен 200мг	67	2027-07-25 08:45:46.766177+00	2	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76618+00	\N	\N	f
6d43be90-7e85-4bfd-9ef8-6887ebe9c40d	Атропін 0.1%	12	2026-06-06 08:45:46.766216+00	1	4	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766216+00	\N	\N	f
6ef6c603-36d6-464c-b06a-d833b706166d	Рукавички медичні	73	2026-03-17 08:45:46.766193+00	5	0	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766193+00	\N	\N	f
7059df30-dfaa-439a-b36b-db6d36293466	Парацетамол 500мг	21	2027-01-11 08:45:46.766243+00	2	3	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766243+00	\N	\N	f
707fcc55-b818-4592-a796-2a160af377dd	Диклофенак 50мг	28	2026-04-27 08:45:46.766144+00	2	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766144+00	\N	\N	f
70a3a118-0aa9-492c-8cf8-5f6b858b8214	Перекис водню 3%	319	2026-06-21 08:45:46.766238+00	25	1	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766238+00	\N	\N	f
70e43dc8-7764-4879-9d4d-f8aa49b97fdf	Парацетамол 500мг	28	2027-05-31 08:45:46.766193+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766193+00	\N	\N	f
70efb7f3-d072-4700-a151-1c0e2b0104d9	Розчин брильянтового зеленого	58	2027-06-19 08:45:46.766235+00	6	1	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766235+00	\N	\N	f
72cde6be-9896-4e98-9f80-5476d7c36820	Серветки спиртові	4	2027-07-17 08:45:46.766144+00	1	5	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766145+00	\N	\N	f
72f07ad0-96fd-43e9-b4ad-bc46a5af6eb0	Но-шпа 40мг	14	2026-08-13 08:45:46.766201+00	2	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766202+00	\N	\N	f
73b19324-ed29-416b-a179-748610964b3e	Хлоргексидин 0.05%	335	2026-06-24 08:45:46.766174+00	25	1	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766174+00	\N	\N	f
74765c30-f3ae-450f-b317-2be10ee4577a	Рукавички медичні	166	2027-12-27 08:45:46.766229+00	5	0	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766229+00	\N	\N	f
747967fd-b170-4f1e-b977-d3052392361f	Марля медична	419	2026-05-20 08:45:46.766215+00	25	2	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766216+00	\N	\N	f
75575f8c-3f73-4244-8711-c0569f56e673	Марля медична	223	2027-02-10 08:45:46.766204+00	25	2	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766204+00	\N	\N	f
76334304-7810-4dd6-87d4-898f1b357c28	Вата стерильна	76	2027-11-24 08:45:46.766235+00	12	2	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766235+00	\N	\N	f
77ca91eb-fac6-4ce9-908b-3fa12987751a	Дімедрол 1%	18	2027-12-06 08:45:46.766154+00	1	4	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766158+00	\N	\N	f
78732037-4455-451f-9ff5-5041d198ffa0	Магнію сульфат 25%	21	2026-12-14 08:45:46.766146+00	1	4	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766146+00	\N	\N	f
7c6f5dd0-105d-4dd9-9672-f4a8ce235505	Лоперамід	20	2026-05-20 08:45:46.766241+00	2	3	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766241+00	\N	\N	f
7e8aa30a-affa-4595-8cbf-937cbbec720a	Бинт марлевий (упаковка)	10	2027-12-27 08:45:46.766237+00	1	5	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766237+00	\N	\N	f
7ffe1aaa-2683-4c4f-9af9-6582a4260475	Анальгін 500мг	49	2027-06-29 08:45:46.766206+00	2	3	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766206+00	\N	\N	f
834f0f04-5188-4ac3-8726-bfc85e954d7b	Маска медична	95	2027-01-24 08:45:46.7662+00	5	0	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.7662+00	\N	\N	f
83da18f2-0518-4024-83aa-a7a1050b03bd	Рукавички медичні	121	2027-05-01 08:45:46.766152+00	5	0	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766152+00	\N	\N	f
856399fc-902f-4ff5-8f17-3d47d3fdabba	Джгут гумовий	4	2027-05-03 08:45:46.766202+00	1	0	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766202+00	\N	\N	f
85ff227f-3f77-44a3-83a4-5bbeedc79332	Папаверин 2%	17	2027-06-02 08:45:46.766181+00	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766181+00	\N	\N	f
862b7cb1-6258-4cfc-a6d5-a5ba7c7de0a9	Атропін 0.1%	7	2026-06-09 08:45:46.766163+00	1	4	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766164+00	\N	\N	f
87e16a2e-3e40-4c7d-bc3d-eb0889091cb3	Лейкопластир бактерицидний	20	2028-01-05 08:45:46.766143+00	2	0	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766143+00	\N	\N	f
88467a6b-9477-4f15-8c16-5f9a660a65c0	Рукавички медичні	55	2025-10-15 08:45:46.766165+00	5	0	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766165+00	\N	\N	f
895acd88-0251-4a59-b0bc-c6c41a6bb7da	Дексаметазон 4мг	15	2026-12-17 08:45:46.766216+00	1	4	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766216+00	\N	\N	f
8e41e3c6-57e0-4f2d-8da5-e1bcb69008ba	Розчин брильянтового зеленого	98	2027-05-16 08:45:46.766246+00	6	1	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766247+00	\N	\N	f
8f0a56cb-05a9-43c3-877b-42256e45aeda	Анальгін 500мг	22	2027-03-01 08:45:46.766161+00	2	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766162+00	\N	\N	f
8f2691db-603f-4278-b91e-77d502b39af0	Нітрогліцерин	44	2027-12-22 08:45:46.766202+00	5	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766202+00	\N	\N	f
8f366eee-2226-44ee-acb3-d8d516deb987	Лоперамід	22	2026-04-12 08:45:46.766191+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766192+00	\N	\N	f
8f9b55ab-bbb8-4db0-9147-1d6a06606b3a	Фізіологічний розчин 0.9%	240	2026-05-07 08:45:46.76616+00	50	1	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766161+00	\N	\N	f
91782f86-7f43-47e3-8b07-3fde170895ea	Маска медична	90	2026-04-12 08:45:46.766151+00	5	0	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766152+00	\N	\N	f
9207a947-b38a-44c3-92bd-7c7cfda5a603	Лоперамід	18	2027-04-29 08:45:46.766206+00	2	3	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766206+00	\N	\N	f
9300bf46-d42f-480b-8ac9-609a4df76e59	Бісептол 480мг	17	2028-01-03 08:45:46.766174+00	2	3	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766174+00	\N	\N	f
949fce48-cac5-47db-a4cc-3bc243fcdd92	Серветки спиртові	8	2026-09-13 08:45:46.766204+00	1	5	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766204+00	\N	\N	f
94d5bb6c-d47d-47a2-90df-05d8389e22fc	Папаверин 2%	9	2025-11-13 08:45:46.766165+00	1	4	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766165+00	\N	\N	f
97118676-3450-4dfd-a1b8-30dc3f477c19	Нітрогліцерин	26	2026-06-22 08:45:46.76622+00	5	3	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76622+00	\N	\N	f
9816549e-0cc3-45e9-a6e1-c8d4a289cab0	Спирт етиловий 70%	398	2026-09-18 08:45:46.766152+00	25	1	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766152+00	\N	\N	f
988307a2-4317-4852-9362-159fb5e7c872	Лоперамід	28	2026-05-17 08:45:46.766164+00	2	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766164+00	\N	\N	f
99a97a58-c50d-4450-b6c0-3ad390fa0510	Бинт стерильний 5м×10см	7	2027-07-30 08:45:46.766149+00	1	0	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766149+00	\N	\N	f
99d88115-91b9-4b6e-8276-12733929ea33	Лоратадин 10мг	30	2026-07-01 08:45:46.766189+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766189+00	\N	\N	f
9be3afa4-042d-4a6e-b2e7-5c3fe04dc77a	Анальгін 50% (амп.)	11	2026-04-03 08:45:46.766183+00	1	4	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766183+00	\N	\N	f
9c1ba645-c689-4fb9-ae5a-72b490687296	Цитрамон	27	2027-12-01 08:45:46.766206+00	2	3	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766207+00	\N	\N	f
9c829425-14e6-4bce-b485-f531cfd14c4d	Преднізолон 30мг	6	2027-07-04 08:45:46.766142+00	1	4	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766143+00	\N	\N	f
9cab5658-1339-44b2-80d2-9642aa091048	Валідол	29	2026-11-06 08:45:46.766246+00	2	3	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766246+00	\N	\N	f
9d3fe8d7-a1b6-445e-a248-c5e60894cbf4	Корвалол	56	2026-04-11 08:45:46.766158+00	6	1	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766159+00	\N	\N	f
9d8121fa-55b0-4ed6-aad5-cec126abc4c4	Бісептол 480мг	18	2027-10-03 08:45:46.766214+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766214+00	\N	\N	f
9dc5016b-d325-40be-bb99-4c0e14e6b1c8	Маска медична	121	2026-03-28 08:45:46.766173+00	5	0	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766173+00	\N	\N	f
a0043bae-93aa-46d5-a5f9-da0e207cf148	Ібупрофен 200мг	20	2026-08-27 08:45:46.766209+00	2	3	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766209+00	\N	\N	f
a02b27d3-f6c8-46ee-8cd5-e1f63556f165	Дімедрол 1%	24	2026-09-18 08:45:46.766242+00	1	4	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766242+00	\N	\N	f
a1fa196c-4a30-4c72-8a0b-c3d28ebaf1c8	Кеторолак 10мг	11	2026-04-25 08:45:46.766163+00	2	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766163+00	\N	\N	f
a285c63e-4545-405b-aaf1-71f9f75d46e0	Но-шпа 40мг	32	2025-11-22 08:45:46.766166+00	2	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766166+00	\N	\N	f
a28782e9-86b6-4cb1-bcac-08ea3a42462a	Корвалол	64	2026-04-13 08:45:46.766175+00	6	1	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766175+00	\N	\N	f
a4dc22c2-8cc9-435c-b218-bac52e2e7d69	Фізіологічний розчин 0.9%	994	2026-01-20 08:45:46.766189+00	50	1	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766189+00	\N	\N	f
a5c1c530-9fa9-4c1b-9568-0bcd789889b2	Лоратадин 10мг	17	2026-10-20 08:45:46.766219+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766219+00	\N	\N	f
a6d046d2-d34b-43e3-97a7-8dc359217f44	Джгут гумовий	9	2027-06-16 08:45:46.766242+00	1	0	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766242+00	\N	\N	f
a832e7ca-6c41-4521-8cec-1110ad971719	Бісептол 480мг	25	2027-01-30 08:45:46.766161+00	2	3	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766161+00	\N	\N	f
a84bbae4-a309-4fff-a2c5-a16716fb1255	Лейкопластир бактерицидний	33	2027-04-23 08:45:46.766229+00	2	0	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766229+00	\N	\N	f
abbe7d22-71d5-4957-867c-0288362b9140	Но-шпа 40мг	16	2026-08-31 08:45:46.76623+00	2	3	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76623+00	\N	\N	f
ac07c428-0bd2-496c-8746-843da31e8451	Преднізолон 30мг	25	2027-05-14 08:45:46.766194+00	1	4	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766194+00	\N	\N	f
acab24d8-d6c7-4b4e-ae66-c88f584d053f	Аспірин 500мг	27	2027-06-26 08:45:46.766217+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766218+00	\N	\N	f
ae78b50f-4ca2-4192-9644-87847b22c950	Шприц одноразовий 10мл	32	2026-06-06 08:45:46.766144+00	2	0	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766144+00	\N	\N	f
aece5775-3ff8-467c-a2fa-834769aede7f	Диклофенак 50мг	26	2026-04-15 08:45:46.766241+00	2	3	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766242+00	\N	\N	f
aef9e5e7-26e5-447e-b03a-bca0d1d3cd47	Перекис водню 3%	117	2027-11-29 08:45:46.766231+00	25	1	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766231+00	\N	\N	f
b0e378a2-42d5-4698-9335-e7061d741810	Корвалол	61	2026-10-03 08:45:46.766239+00	6	1	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766239+00	\N	\N	f
b214a034-ef35-451c-b105-7754d76ca7a3	Валідол	14	2027-07-09 08:45:46.766215+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766215+00	\N	\N	f
b352fba1-9a2c-4a85-ac4a-6d7972c87b57	Папаверин 2%	18	2028-03-02 08:45:46.766222+00	1	4	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766222+00	\N	\N	f
b3df164d-0191-4c71-9859-859c34309ff9	Амоксицилін 500мг	24	2026-01-06 08:45:46.766192+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766192+00	\N	\N	f
b3e566c7-c940-4b1f-8d1c-14df4e77ece7	Но-шпа 40мг	22	2027-10-03 08:45:46.766215+00	2	3	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766215+00	\N	\N	f
d11b16a5-db85-49e0-b389-e092ba60164d	Джгут гумовий	0	2026-05-07 08:45:44.002167+00	1	0	4886163b-e61f-4357-9b8f-097d50a821cd	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:44.002169+00	2026-04-16 08:46:23.062942+00	\N	f
b4ae1a58-6cc0-4e3a-8c58-4e2ae5796c61	Перекис водню 3%	229	2027-11-02 08:45:46.766206+00	25	1	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766206+00	\N	\N	f
b4c7b212-ab88-4e40-8e10-90640485b52f	Цитрамон	28	2026-06-15 08:45:46.76619+00	2	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76619+00	\N	\N	f
b5778239-65ea-4033-a69b-2758dc058f04	Нітрогліцерин	35	2026-06-11 08:45:46.766194+00	5	3	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766194+00	\N	\N	f
b83c9ee9-009e-42ca-8f9b-f29e356a283a	Супрастин 25мг	22	2026-05-15 08:45:46.766237+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766237+00	\N	\N	f
b85bc18c-748c-45db-83e7-518fbee9796f	Маска медична	90	2026-03-14 08:45:46.76619+00	5	0	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766191+00	\N	\N	f
b8bfefc8-a98d-43cf-8a08-3b9b5b14016e	Джгут гумовий	2	2028-03-30 08:45:46.766222+00	1	0	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766222+00	\N	\N	f
b98f158c-d5df-4dde-a68a-be9b934e3a51	Бинт еластичний	4	2027-12-11 08:45:46.766184+00	1	0	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766184+00	\N	\N	f
b98fabc7-8fba-4687-a518-8c48b07372ad	Корвалол	93	2027-10-04 08:45:46.766236+00	6	1	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766236+00	\N	\N	f
b9f1a3f5-220a-4637-8c46-4b1f734225b7	Фізіологічний розчин 0.9%	325	2026-06-06 08:45:46.766201+00	50	1	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766201+00	\N	\N	f
bc515de6-6604-419a-b06b-7b373ba79fe3	Лоратадин 10мг	13	2026-05-19 08:45:46.766146+00	2	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766146+00	\N	\N	f
bc53aefa-89e6-49d1-9846-9305011cab87	Ібупрофен 200мг	54	2026-11-15 08:45:46.766223+00	2	3	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766223+00	\N	\N	f
bd03dbda-da7e-4467-bb65-95856b4bbe78	Парацетамол 500мг	44	2025-11-10 08:45:46.766154+00	2	3	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766154+00	\N	\N	f
bdfbb58d-72cd-4e6e-b389-c985c50dd644	Парацетамол 500мг	22	2027-02-13 08:45:46.7662+00	2	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.7662+00	\N	\N	f
bf66a29f-df42-48fb-9721-ce6e4a0f34ad	Ібупрофен 200мг	17	2027-01-22 08:45:46.766229+00	2	3	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766229+00	\N	\N	f
c1a90e38-6574-435c-9858-c9820b2fe7bf	Супрастин 25мг	11	2027-04-04 08:45:46.766145+00	2	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766145+00	\N	\N	f
c22e26d7-29d0-4e91-aaa5-77f1bc5cb4bb	Диклофенак 50мг	18	2027-10-29 08:45:46.766225+00	2	3	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766225+00	\N	\N	f
c379500a-a410-4596-a170-77b098cd126b	Спирт етиловий 70%	297	2027-01-08 08:45:46.766231+00	25	1	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766231+00	\N	\N	f
c487cb5c-c11a-4e60-a718-7fc54684b9b4	Преднізолон 30мг	6	2027-02-26 08:45:46.766224+00	1	4	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766225+00	\N	\N	f
c523436a-8095-4f5d-94ba-9a6e89026839	Преднізолон 30мг	25	2027-10-26 08:45:46.766161+00	1	4	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766161+00	\N	\N	f
c568970b-051f-4f7c-bdb3-f43262a04339	Атропін 0.1%	13	2027-06-01 08:45:46.766152+00	1	4	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766153+00	\N	\N	f
c7e5e7a7-de63-4565-bea6-e6334a08289e	Анальгін 50% (амп.)	11	2028-01-30 08:45:46.766219+00	1	4	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766219+00	\N	\N	f
c92c95d7-cbbc-400a-a977-e318ca8eaa2b	Ібупрофен 200мг	49	2026-06-07 08:45:46.766233+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766234+00	\N	\N	f
ca64c018-b6b5-441c-ba2d-82fe57168c0c	Магнію сульфат 25%	5	2027-11-13 08:45:46.766186+00	1	4	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766186+00	\N	\N	f
cbddf4c8-e311-49b9-8498-5e9367e5944d	Вата стерильна	190	2026-12-08 08:45:46.766246+00	12	2	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766246+00	\N	\N	f
cc7eb40a-e055-4c59-9ab0-41d28bf17974	Джгут гумовий	7	2026-02-10 08:45:46.766176+00	1	0	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766176+00	\N	\N	f
cdc8bcda-87e9-41d4-bdbe-bc6775eb9020	Цитрамон	17	2026-04-16 08:45:46.766153+00	2	3	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766153+00	\N	\N	f
d033e888-54b3-492c-8eba-dc9d28883778	Маска медична	163	2027-12-05 08:45:46.766146+00	5	0	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766146+00	\N	\N	f
d24bd754-96b9-4e51-ba79-b780eaaa991a	Фізіологічний розчин 0.9%	834	2028-03-09 08:45:46.766154+00	50	1	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766154+00	\N	\N	f
d5c8d911-d067-422d-b4e9-1fb64791bc38	Бинт еластичний	14	2026-11-22 08:45:46.766223+00	1	0	9bca0fd9-75cf-4ebe-ad4e-babc7e5bbb4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766223+00	\N	\N	f
d6523d34-3cd6-46f4-9b32-184a0d2b0c3b	Хлоргексидин 0.05%	415	2026-05-22 08:45:46.766164+00	25	1	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766164+00	\N	\N	f
d6f2cfab-90d2-428e-8ee9-fe093b2c4d8d	Бинт еластичний	5	2028-03-04 08:45:46.766218+00	1	0	5574e047-35eb-46f3-a453-9c5fdf488c87	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766218+00	\N	\N	f
d904a6e2-5ecd-4ea2-bdc1-e033272d7c6a	Фізіологічний розчин 0.9%	592	2026-04-13 08:45:46.76624+00	50	1	8992ed22-2f1d-44ab-958c-a1785f7da058	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76624+00	\N	\N	f
d924f158-976b-4f62-bd6a-fccdcd8af95f	Розчин брильянтового зеленого	68	2028-01-06 08:45:46.766151+00	6	1	23d89a46-4b24-4c7e-9e64-3e027577dec1	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766151+00	\N	\N	f
d9bc7966-9e5b-4ae3-bc9b-5837b5ca84d4	Дексаметазон 4мг	15	2026-05-10 08:45:46.766188+00	1	4	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766189+00	\N	\N	f
dac75e27-c336-4da1-9fff-48730ccf23c9	Аспірин 500мг	24	2027-01-12 08:45:46.766227+00	2	3	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766229+00	\N	\N	f
db57f91d-6ad6-4da9-876e-569a8c6a5f62	Перекис водню 3%	171	2026-05-07 08:45:46.766147+00	25	1	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766147+00	\N	\N	f
dc596d84-7b8d-4d0c-b6f6-f920dad0483b	Папаверин 2%	7	2026-06-20 08:45:46.766191+00	1	4	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766191+00	\N	\N	f
dd80f8ee-3606-41f7-adab-98a30a3c95d9	Корвалол	31	2027-08-04 08:45:46.766203+00	6	1	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766203+00	\N	\N	f
dd931b25-7404-48e4-86b2-f4d7fbc102a6	Лоперамід	17	2028-02-23 08:45:46.766235+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766235+00	\N	\N	f
de8aed0c-c7fa-4489-a101-dfb0b8284771	Диклофенак 50мг	37	2026-02-10 08:45:46.766234+00	2	3	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766235+00	\N	\N	f
ded2a3a7-e85b-4df0-a3be-7c7fe243d867	Рукавички медичні	79	2027-06-16 08:45:46.76618+00	5	0	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.76618+00	\N	\N	f
e35d72da-0bb4-4931-8b64-580b23b02164	Вата стерильна	67	2027-12-17 08:45:46.766148+00	12	2	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766148+00	\N	\N	f
e6ced2a8-7bdf-4e7b-8335-eec526ae9dfd	Дексаметазон 4мг	25	2026-06-24 08:45:46.766163+00	1	4	f1ce3185-25b4-4096-8362-be811b916e3d	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766163+00	\N	\N	f
e7d7a10c-2971-4160-a01b-adb521f0f346	Адреналін 0.1%	17	2027-02-02 08:45:46.766176+00	1	4	8e9cb6de-c285-4b1b-afd1-8b4c1c02aba8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766176+00	\N	\N	f
e89d5bdc-f7cc-4a52-9567-cde01e5d297e	Амоксицилін 500мг	24	2027-01-20 08:45:46.766203+00	2	3	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766203+00	\N	\N	f
e907b0bc-f946-447d-b0de-d7cab4aedb89	Диклофенак 50мг	40	2027-01-20 08:45:46.766184+00	2	3	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766185+00	\N	\N	f
e9105bda-c30d-42dc-93ea-0db2298f1056	Папаверин 2%	5	2027-08-29 08:45:46.766225+00	1	4	6acd5b88-42f5-4612-a475-469a220c1b17	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766225+00	\N	\N	f
e91f90d5-1ea7-42e8-b5e1-2fbdd3462bfc	Бісептол 480мг	38	2027-03-01 08:45:46.766207+00	2	3	6b47cfd0-6948-493c-ba26-2305d73679a8	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766207+00	\N	\N	f
eb7bd101-fc75-48e3-9f2b-e83b39b21806	Марля медична	291	2026-04-23 08:45:46.766185+00	25	2	f3b82c93-17b4-4ceb-9964-b577b5707105	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766186+00	\N	\N	f
ecb13e77-cbb5-41f0-a49c-89a6bb5dda37	Аспірин 500мг	42	2028-02-26 08:45:46.766145+00	2	3	06302277-15e6-4ecf-85bd-cae11f170372	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766145+00	\N	\N	f
ef047cc7-c7a4-47a1-8068-2542472fc15a	Шприц одноразовий 5мл	15	2028-01-05 08:45:46.7662+00	2	0	06931566-89d2-4933-8551-6b4fb796afc7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766201+00	\N	\N	f
f0445382-e151-4a33-b761-02abc0a9ceb2	Дімедрол 1%	10	2026-04-09 08:45:46.766192+00	1	4	41f7cb7b-019f-414c-afec-81f375a50e57	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766192+00	\N	\N	f
f05445d5-cbbd-46d7-aabb-c54f4798ffb1	Джгут гумовий	10	2026-09-20 08:45:46.766233+00	1	0	b6292e00-9c92-40ae-a4b5-a73f306cd665	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.766233+00	\N	\N	f
\.


--
-- Data for Name: Organizations; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."Organizations" ("Id", "Name", "Address", "CreatedDate", "UpdatedDate", "DeletedAt", "IsDeleted") FROM stdin;
69d1796a-d3cb-4761-b636-873c46de50ad	Клініка "Добробут"	м. Київ, вул. Хрещатик, 22	2026-04-10 08:45:43.234331+00	\N	\N	f
8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	Медичний центр "Оберіг"	м. Львів, пр. Свободи, 8	2026-04-10 08:45:44.24746+00	\N	\N	f
82ada3f9-55db-4ef1-9e08-0e66d08e92c1	Лікарня "Святої Катерини"	м. Одеса, вул. Дерибасівська, 14	2026-04-10 08:45:44.863699+00	\N	\N	f
0fcb59c3-f80b-43dc-b4f6-25c876836ab4	Поліклініка №3 м. Києва	м. Київ, вул. Антоновича, 102	2026-04-10 08:45:45.548877+00	\N	\N	f
80ae5be4-384d-4c59-bace-7165043a8b73	Медцентр "Здоров'я родини"	м. Харків, вул. Сумська, 56	2026-04-10 08:45:46.137248+00	\N	\N	f
\.


--
-- Data for Name: RefreshTokens; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."RefreshTokens" ("Id", "Token", "ExpiresAt", "IsRevoked", "CreatedAt", "UserId") FROM stdin;
9fbde835-455c-4eb2-bfd0-133b540e15d9	Ny5M7VwfMAvwkqjvqe4bTut7njcXkOVwPAr+F/7LV6XjvhG8LdO7NxfPvm/cjPDrA91P6YjvEEtp/qfZcwkmHw==	2026-05-10 08:52:10.776344+00	f	2026-04-10 08:52:10.776328+00	0f8ed8de-312a-498a-84fa-3ef04e663455
40c1439f-3ac2-4204-8c80-38f0196d2bfc	oHUwKgj11oj8xZ0qu4400zOhdjrYIrGaAa3ILv/XIYRWFQu/oBgranR9xWPh8OA4Tzxb4NiTEd/rlcdsp3HfUw==	2026-05-10 08:56:00.790549+00	f	2026-04-10 08:56:00.790511+00	063a708f-4471-488e-81e4-fa4617696898
cd95b195-8536-4a12-86eb-99e53c8f618d	/IcMzbCxwDAdFuhMcQxY4p/WQRYSxvhuU97VB2Hfl6jSSSxagF5cbdQ0aE6wNRxoLpKfO8F8VPuB2aQrZgPiug==	2026-05-10 09:11:53.930647+00	f	2026-04-10 09:11:53.930612+00	0f8ed8de-312a-498a-84fa-3ef04e663455
7c243cc9-ed17-48da-96dd-6177fbedc2cb	7Q73/i6XWJlpOkOnPUgD/QBAiLCV/89pEintI0rO/PKHK/OpGk7C6nZ2UI18F2ieArJj1w0et6nB3CyykHjG1w==	2026-05-10 09:12:55.878782+00	f	2026-04-10 09:12:55.878746+00	063a708f-4471-488e-81e4-fa4617696898
139af743-6513-4650-862a-6974f0e3065e	QO4D3wa01sjxBpn02t/McD8eCOxBRubrkNLnSnJ5/i/nTiTmLdZe4IBk3suVTx570eiuNCSAX7mS27EEBf62bA==	2026-05-10 09:13:29.29431+00	f	2026-04-10 09:13:29.294278+00	0f8ed8de-312a-498a-84fa-3ef04e663455
2bc317f1-ddcc-4c6d-8dcc-bedede098841	GYz7doHfolq8IV2Uhwq+5JU7KZASvAXLI9/CCjNlCKu1g6DU7Dyoz3om3bLF36FaEbdxhuxwj5AoUbYn52vfHw==	2026-05-10 09:13:46.851488+00	f	2026-04-10 09:13:46.851473+00	063a708f-4471-488e-81e4-fa4617696898
7163fe0f-125d-46b0-b1ab-6cc4f42efcaa	YuCwLJKXIM+q2OZs8tCb65R0hpU+oeRwGp6a6NSyTaVNx6JjCKnWDL56dPhEWv2wt2y3vX+ZYu5sh/qRfNehEg==	2026-05-10 12:29:55.427286+00	f	2026-04-10 12:29:55.427051+00	0f8ed8de-312a-498a-84fa-3ef04e663455
4486646e-03ad-44a1-986f-4e8fb2cfc9d8	0uCLME+nNMxQC8WSf/HZ3v8kMfjyBGR7POYTXt0cX5CcxcP79EVylYe2OsIDKtacF5yNX45gg8fLfU6ie+tWuQ==	2026-05-10 12:30:24.638631+00	f	2026-04-10 12:30:24.638616+00	063a708f-4471-488e-81e4-fa4617696898
fa778cfa-f44f-4d4e-9721-68b3ae5713f5	xtGBuw47ErUQMk8vvjy/QXTY3SFWQgdFifXkzP6QCXz2LQ1Ly7L13M0UO9PS3CrC7NecnPCAzEDDn476X5UeOw==	2026-05-10 17:25:49.155539+00	f	2026-04-10 17:25:49.155496+00	063a708f-4471-488e-81e4-fa4617696898
3fc9806c-0bec-4b6d-bf49-461ab5af30c1	L64yYQ0MTGvVkFZkXuVt9fgjFfzcotxrva4ryVDneK0IJbR7Ph3D/nI9gIjGtmYRdboLeN5SdyfVGbSsAouydg==	2026-05-10 22:18:24.571839+00	f	2026-04-10 22:18:24.571758+00	063a708f-4471-488e-81e4-fa4617696898
a52090b1-eb89-4fec-8b21-5459eff5c969	QMGbjuXfJ9k2pz1Sfv2O4l59omqasTfscaAmJ2LVjWYk0iMRwtyki93mw8PkkF4BwIAZxOstCus3ba5pR6zNGw==	2026-05-10 22:57:37.334691+00	f	2026-04-10 22:57:37.334641+00	063a708f-4471-488e-81e4-fa4617696898
cece2ca8-61a8-4c69-a1dd-757778187107	tYgtbSItTjJiGhaw6EFOQDllkIe9QyJjVanaCOd2RMqPLFheMqTEXjLwCZhenmWPpTCPnpcarmkGa59EvnNQHg==	2026-05-10 23:15:15.045066+00	f	2026-04-10 23:15:15.04498+00	063a708f-4471-488e-81e4-fa4617696898
810ce395-dad7-464b-81f7-d96588f46be1	C81VFTnKqzVVI9qBLMy8zgaJiNquNCiXusPZtg6VjbCY3iwex87j3FLU4JtfFgceutu62XlQN07yVGt4pZgpcg==	2026-05-10 23:25:06.481939+00	f	2026-04-10 23:25:06.481908+00	063a708f-4471-488e-81e4-fa4617696898
ba89f65e-df24-49f3-8374-5190bbb087a6	h7+NkLzivmMAKgAETT0JwOWoKF6y6Fdvpc7LWI2UGRy3SsuNrj1geVQ8ux5f+evhMAYlWTr4t5RS3QFGdVrEqA==	2026-05-10 23:52:01.763377+00	f	2026-04-10 23:52:01.763345+00	063a708f-4471-488e-81e4-fa4617696898
8ef22022-e557-4206-a782-a26fd2424443	Oxc3OfYMpIlqWKvtw9XiNU+oCWqzmpguwkuYpsdeYKQFpJ0kJrrmilDhj/UKeGw3ElmlOhQY//qVnTG6F5+ssA==	2026-05-11 08:51:32.907989+00	f	2026-04-11 08:51:32.907972+00	063a708f-4471-488e-81e4-fa4617696898
5507ce31-4982-4928-abd8-9205511a74f9	j4EyPNN4ObepfGtugWCwhucUSEWL3q+eNfJzr67bnM6n2Ev/7b0AKB4beAPc9mxxCDMm08gE+HwcSh4Sh8shMA==	2026-05-11 08:51:32.894967+00	f	2026-04-11 08:51:32.894935+00	063a708f-4471-488e-81e4-fa4617696898
cd84a349-dc74-4fde-99e8-0d1f0800f60f	wDOEV5Oh6/Tl1fijQQO/t4WMOuT8X0eepZG7tZoi0bicczq8eeesQ7jj/6tgqHKlYyKKeed+AhH1T82Cn3OQpA==	2026-05-14 08:35:02.007303+00	f	2026-04-14 08:35:02.007273+00	063a708f-4471-488e-81e4-fa4617696898
e195ccc6-80cf-4a1b-bcee-7000f3bdb4bf	BOJ+Yy5JECE4Y8EQWWYf2LFlykVc81Sis374dlv9qXjJPWTGy5W0SPqmelaSOG15ErZDGMvavL+1Sm4oXoXKnw==	2026-05-14 08:46:23.936113+00	f	2026-04-14 08:46:23.936078+00	063a708f-4471-488e-81e4-fa4617696898
f0789fce-eba5-475c-a3fe-154a0f416253	CchAEpX+UO2n9oOVXvu955GrgOqoYijq2oH/K0PE8RommDgXGh/kiLaqkD/r6mKTsJBBZwtgK6MzceCJfvF/tg==	2026-05-15 09:57:26.614016+00	f	2026-04-15 09:57:26.613951+00	063a708f-4471-488e-81e4-fa4617696898
6d97fb6f-3b4b-4443-afa6-f6fd3c0f0aa8	C/jTyjxRTp+XC7kclOLMbOVgSbMdGsIbdWR3okLHi7jsVq16eO4/ez77Vq8qCsyDVZyBojeprJH3ovSsMTkfrQ==	2026-05-15 18:58:51.41461+00	f	2026-04-15 18:58:51.414187+00	063a708f-4471-488e-81e4-fa4617696898
e9063b97-5741-4856-8357-fc983d0b27e9	5DyN4COf4tcEu+/nDrB6yRvdfAa8d5sqWL0PtUG6+w5SGNjEcW5u/SPJmact4jeO5TQxVQvHGPrIPa+w39nIgw==	2026-05-15 19:47:33.596616+00	f	2026-04-15 19:47:33.596447+00	063a708f-4471-488e-81e4-fa4617696898
6fda5995-99d9-4048-bf88-eb4700a5dfa0	S/hTcBoWCe27NRcy2U+/9HT1eU6mdt5OoQYtOvwnLBc03nztOI/7tpfNtstqLDG9ZZeXXGDrnbpP/vKS3IrIiA==	2026-05-15 20:00:32.175138+00	f	2026-04-15 20:00:32.174987+00	063a708f-4471-488e-81e4-fa4617696898
76b51a17-08e4-4543-966a-fbedf4b49cfa	jf4vUEu2DkZ+2NeqnrKBuh+LGedKxUBKYdXNMVdxLR5huTi2O/s2QZr+tzmN/2NhVQWptrhgxkRqpoE54QswAg==	2026-05-15 20:14:39.885082+00	f	2026-04-15 20:14:39.885018+00	063a708f-4471-488e-81e4-fa4617696898
0a2f1eca-0f99-455f-a559-4f3608a51eaf	q+j4QzZOtuGexkTWFivFO0/znugvKvOs88cLy/Gt1kK7bYWUd11y5+a/1xypycAF7pb3zilH/RbhIkeL4uoMrg==	2026-05-15 20:15:55.510618+00	f	2026-04-15 20:15:55.510584+00	0f8ed8de-312a-498a-84fa-3ef04e663455
11fcb52f-a00e-42db-ae31-ae209257b322	heT5JDBCNCrbaunYZlyAygUC773+xGFFD4w4qSPTyhhUeznW5WnGAS+fUFg7P9K2saSmN3B7QSkRXXbwxCsgmA==	2026-05-15 20:16:59.232114+00	f	2026-04-15 20:16:59.232066+00	063a708f-4471-488e-81e4-fa4617696898
2dacb230-f6d3-496e-bbcc-56348f7f1051	nIXcgsvRZMpfw9DsLUJ/mvVnKn5jC8s2q97rFWbhov5dOEpjhwip4eKpw4RRLFoZzeIcYZVa+wlfZJjaFmOcnw==	2026-05-15 20:18:23.656841+00	f	2026-04-15 20:18:23.656825+00	0f8ed8de-312a-498a-84fa-3ef04e663455
a676b2de-211d-4f15-988b-918d16626032	QpkMbh+RiHdAAddBF6YWk+9XS4LPOOOO9bpgneAKE39YoBlA+fpPXU9I/JgxuvoY8z85UvhQnkp85W5IaaQcKg==	2026-05-15 20:19:35.131188+00	f	2026-04-15 20:19:35.13115+00	0f8ed8de-312a-498a-84fa-3ef04e663455
8c7d28ec-285f-42a9-8aa5-35913ebaad35	96YjqL7/DPgCAuB+F4hd9uFvj7iPnCj8K86SRt/U02fxCx/rBFWAnM9mpSXbkrfKimVdshWjQvlhynd8f3BJHw==	2026-05-15 20:21:03.960989+00	f	2026-04-15 20:21:03.960971+00	0f8ed8de-312a-498a-84fa-3ef04e663455
dd578a6e-777e-4192-88e1-5b08751ff72b	ERGfKEoWgxhaE6cv2+SapQLcIkYnmU4tvlFp6KAGmLKlM2zrMtP18FN5Gkvet+lYFM4UEdfSAgOVx72MPqI31Q==	2026-05-15 20:22:29.011214+00	f	2026-04-15 20:22:29.011178+00	0f8ed8de-312a-498a-84fa-3ef04e663455
b7a468cb-35f2-4c4d-b618-8a1546a01ac6	FE1mzXYxMOKf0/xGXtB/gbLBQVcdw9Tymnexl8vlVigoQRpc/rvUFVtWQ+wxgZFvAcMZitIC9R11koSx/oRuzQ==	2026-05-15 20:23:58.907292+00	f	2026-04-15 20:23:58.907208+00	0f8ed8de-312a-498a-84fa-3ef04e663455
eb7dd807-e51e-4645-8142-46bf353a073b	Lm75XWbd0+28ghYe7mGNCzEyraU7rZ4yj+qqjvVqJlEjNgh4N449oBIVj+VSWfc+i+zhBxUTob7ANuWC6RYdGA==	2026-05-15 20:25:10.376307+00	f	2026-04-15 20:25:10.376271+00	0f8ed8de-312a-498a-84fa-3ef04e663455
2616b4d8-9ca3-4648-b06d-edc2bff2644e	54cWZR8Lsshk/RkHd4L3Zywp1CPoyPICJPMZhmcHu9kfuYRVAR2pRn97/pcjyGShQ56YkD35TPp+rhvPuOvedw==	2026-05-15 20:26:46.779018+00	f	2026-04-15 20:26:46.778984+00	0f8ed8de-312a-498a-84fa-3ef04e663455
4d34e907-6e94-40a3-8e53-96c40e05514d	B5wqpeIbVlyhdX3A62RBTg/C/HuwpfvlQSPYWyuaXaakKih2kh/m7R3SWkUPFzZBRjx1JDZHhkz5O54//CN+Gg==	2026-05-15 20:28:07.29671+00	f	2026-04-15 20:28:07.296692+00	0f8ed8de-312a-498a-84fa-3ef04e663455
fba16ac3-5e83-40d4-a259-52602a9c5f76	FHg4JN/udzgU9WYq4aiqk+7OUV+Hl0rC0FbRUEJY7gO+xJFE1XhRG7b/6MGiRkUF3/q0i6JZWW2X85QsMd9PzA==	2026-05-15 20:29:27.955141+00	f	2026-04-15 20:29:27.954952+00	0f8ed8de-312a-498a-84fa-3ef04e663455
7972b710-ed6c-4168-aa75-aed2a0f88abe	CB5AdtKHdvUzJNomifuxUmcurN04cDNJacONGWvgSCyuaS0Q5e1LexiU1p11Wd9qmiGsR5o7uqjxQyMzsIr2DA==	2026-05-15 20:31:40.995557+00	f	2026-04-15 20:31:40.995463+00	063a708f-4471-488e-81e4-fa4617696898
00bcfd85-0156-4a28-8c0e-374cd2212685	kEruuftZLueTx+sjaMX5ZXdo5mROqyJeFCrqkc7NruPrNZ4thx3JeqMdcSgRShPnU63ax1fn0VfuDzdFWEYqPg==	2026-05-15 20:32:56.119688+00	f	2026-04-15 20:32:56.119651+00	063a708f-4471-488e-81e4-fa4617696898
305a6e43-936b-4277-a317-603175cf7b64	TuVXAJD7I4Zwvvf25D1a16v8s5vglhdNt/GN1vmsG/ekf9tdu7ehsVR9Z/icbaByZZoKOG4Uy2SO7UVyXClmGw==	2026-05-15 20:34:27.673623+00	f	2026-04-15 20:34:27.668598+00	063a708f-4471-488e-81e4-fa4617696898
6c235c6d-5800-4012-9c86-91d0ad3d55e0	5y6e58jT3im9Qa67tsaMTd+SgZYgurDFuVMWeV3TUI/YduHrLqRhL2jmclVAD4G+NwlDEfqgAGKB94ALnYRSAw==	2026-05-15 20:36:11.360828+00	f	2026-04-15 20:36:11.360792+00	063a708f-4471-488e-81e4-fa4617696898
f9d29aed-5f20-4d88-939b-4a172dec96dd	jhqWHRECQXFoEXcJdu7gSHAbhiymvH2cgglcsUsD4Ky6Im9LVsW/J38ASAZgwriPPRf3dq8ieHRHfBb/GCjjqA==	2026-05-15 20:37:42.707337+00	f	2026-04-15 20:37:42.707304+00	063a708f-4471-488e-81e4-fa4617696898
140b7bc5-0228-4cd8-aa5f-75f6c0e2bdba	3Rk0KWoeui+ikXfFLZcTUspTTPPUfHyJgMza7+xTyXtbl7RvoqmMdbFdW/gB9ZbjxgDL5/r7Xxef79PgpkFtYA==	2026-05-15 20:39:14.204148+00	f	2026-04-15 20:39:14.204115+00	063a708f-4471-488e-81e4-fa4617696898
05fe4dcd-104a-404f-8200-bc5202cbbe99	8nqYDb8uRoTw+fdIix0lnATTCT62WF0gYqprnYstHOALC+/TURA7q2RR9Nqr16ZJFxJ0R2CSZSnBCrIedd9KZQ==	2026-05-15 20:40:45.574455+00	f	2026-04-15 20:40:45.574421+00	063a708f-4471-488e-81e4-fa4617696898
363cd209-5f8f-42b0-8117-18bffbd24e4f	CdC/j5N2Jhxn75bF7UiAfFndwDiLTdDJ0LowmNm1Wv0jjUHouURP3lMEvqZs5b83eHB4OS16ugohRvazNAnTRA==	2026-05-15 20:42:23.952759+00	f	2026-04-15 20:42:23.952726+00	063a708f-4471-488e-81e4-fa4617696898
738c6af1-dce1-4cd1-8a23-76776840d0f0	Nabd2lm/Qp8+9DDluFhrX+otureyVi89KwWtiJPr4moJvNEfBEqJ0/cBfAHdVa2ahw2sbXBSmgNkt7LR0Rj9Sg==	2026-05-15 20:43:55.328255+00	f	2026-04-15 20:43:55.328186+00	063a708f-4471-488e-81e4-fa4617696898
92f91cdd-3716-4eef-83cd-308d991a0fce	Rf6E1voQ5VRU1fOvCfIJ5lv/uzqWLBEZ4BRaVKdkjbC0eORlDP1hGoTPBA2QB7xe1KdUoR4CtOw/MGMvS2HtrA==	2026-05-15 20:45:26.590612+00	f	2026-04-15 20:45:26.590598+00	063a708f-4471-488e-81e4-fa4617696898
20a6fd83-420e-4cf9-ada2-c10f33e1d8d5	YhZdRCOUSJhHwybJujPspIhHy5T3WTxwrPhCf8qTCEw+AD/aBiPp4BIoKZyRL78ySlUaTfFB8cz+nPmlNsfaSw==	2026-05-15 20:47:10.189142+00	f	2026-04-15 20:47:10.189056+00	063a708f-4471-488e-81e4-fa4617696898
0a181631-5524-4d89-8edd-72a3384dd095	knyXxnjoArHLh934yBAuC0qTbFB61fbyR/WueYB2ampmvo9tq53zWEPHlSMnRnk9aaT2qEWmqURzwIpTrILTGg==	2026-05-15 20:48:41.598574+00	f	2026-04-15 20:48:41.598501+00	063a708f-4471-488e-81e4-fa4617696898
5ca5499b-ae2c-4cec-ab9c-b20adfd1a3fc	sFIf3wYH+vF/O/TCpakTjzCcBuUFXboDKMhE8fdmnosqu9PaBfaNkZoZJSx7Gvtn1512sYL0uIy5r4njDQeJPQ==	2026-05-15 20:50:16.429367+00	f	2026-04-15 20:50:16.429297+00	063a708f-4471-488e-81e4-fa4617696898
936d8a1b-9a5d-4235-9526-dd46f1b0d6d0	ibalgDZaaNl7WWbsnDqdhdzKmdIXcVP6FcO4nGLwMi6gDXh5W44359v8zdLTzJTBVZfl5CETyIKAtvcID0lDzQ==	2026-05-15 20:52:04.876541+00	f	2026-04-15 20:52:04.876439+00	063a708f-4471-488e-81e4-fa4617696898
39bea13b-26ca-495a-8919-fd02385214a9	Yoz9DgvC0CZrAp6YoC7ZgoN7v98ZbncBcWujTDCLGtGfNRXuvQkz5fcPlhWRcxyvFg+tqpwGzFWaJZhLFjmzSw==	2026-05-15 20:53:29.094215+00	f	2026-04-15 20:53:29.094129+00	063a708f-4471-488e-81e4-fa4617696898
4b255d0c-93b4-479d-9daa-334b24edf3a4	07lpbITk1nXxcZ8BpMfxplYu6K3L/sYx0i3l8+3R4F3Jo5HONVFwOToe3sFODfYgukbASfBbM9X0S5pNJ/SVyw==	2026-05-15 20:54:59.637595+00	f	2026-04-15 20:54:59.637506+00	063a708f-4471-488e-81e4-fa4617696898
34cd1967-362d-40dd-b692-b680bc7d4f69	3qMbb1IYT/joqKs23WpmVW6LRlXU/4XwTK8XB11LZY6PpItC3CXeP+qXUSosdqiiydEcHvhP5X5MZQO/yZESKA==	2026-05-15 20:56:14.833894+00	f	2026-04-15 20:56:14.83388+00	063a708f-4471-488e-81e4-fa4617696898
da281956-076b-435a-950c-d86b37d705e4	BmN12Zm2NiHhk/Ig4eCc0zbDuD7glYn6rpuZq6iUIP1IlIVM1OPfDS6ObteWJkqg0EkjgQxmxXQ8/UJZp+72Ig==	2026-05-15 20:57:39.152801+00	f	2026-04-15 20:57:39.152734+00	063a708f-4471-488e-81e4-fa4617696898
ba725234-49d5-40bf-9863-97ab1a8d2d24	oCOIdR6Afbid9x1JB4FkcayiHJtwp9xZEtegDYzxFe/w23C4AbdqI1QwJv4tqngyNGOctpvky6CQ9YYMZj770A==	2026-05-15 20:58:54.274893+00	f	2026-04-15 20:58:54.274798+00	063a708f-4471-488e-81e4-fa4617696898
80a54795-0334-4ba6-8b02-9444b163dd48	t7czsqfZB0bqkn6k93bvzZSFCNuxAaoV4OZwjgWHVa0kYbVbxklU9UTv3ox1xRgkyorI/5ayzfUbFsOPMwlGdA==	2026-05-15 21:00:09.412092+00	f	2026-04-15 21:00:09.411921+00	063a708f-4471-488e-81e4-fa4617696898
058427b1-c527-476d-98c4-3b7e3e68bce0	7XYg0odB0SO0x/7QFDAIxoJq9+IEjpvVdi4DVAFhmF3IO2uwowLBjOiWrdntMfNX3zeIgbmCEQHW4GiWDHk3gQ==	2026-05-16 07:38:46.248076+00	f	2026-04-16 07:38:46.248045+00	063a708f-4471-488e-81e4-fa4617696898
4cbc6462-f81d-48f7-87f9-766f89d9af72	qcLNZshDEoyG/fq7NQFiLX8VD0G/0DIQNiFov4X1/WQMMUDPB9WFCZl3T8v/gJDdFHZU1UVoPBHCLKCcshPt4w==	2026-05-16 07:48:52.858084+00	f	2026-04-16 07:48:52.858065+00	3b77085b-d895-4074-9e32-2022c609b673
40eb534b-2d19-44e8-8e67-94292b580e55	/Zz3bPV7t1GhKFLb6qNJm29wWjAi1zvrQrC3grNwrQURHoto8NHxVDdvMhbUomcoYtWA4HVLfWg0LerXcHhjCA==	2026-05-16 08:32:25.862267+00	f	2026-04-16 08:32:25.862178+00	0f8ed8de-312a-498a-84fa-3ef04e663455
312d2b60-6ac2-4c6c-abf8-629b09b5f518	fuwfvYVNeVI7eOieP2ZilEd5pKVzwiKdRKz28qL4EbTxAjSWyw89BT4Tz44PbCIizTVcdz1nZtLPYNtOwnUQkQ==	2026-05-16 08:47:07.543644+00	f	2026-04-16 08:47:07.543604+00	3b77085b-d895-4074-9e32-2022c609b673
98f62fcd-ab89-4bfb-9ea4-a14c1b72f836	mB0Gy2mRW0Gh/v8fs3tsLL46Hnvi0hCjewyIW5Ju7O3a0tXA/u3dSDuaE3BocXNp1Ncuc8wfZCC25jeEbcxqEQ==	2026-05-16 08:57:19.114278+00	f	2026-04-16 08:57:19.114242+00	0f8ed8de-312a-498a-84fa-3ef04e663455
6770bde6-8e96-4601-a87c-36b796574a30	mUe3cUB2CL4Vza0aNWolMlIlONQ8u1N76R8xBXtOYCncPjgEs+Nvd7dWOvKzpc63FKqxPzf0DTvxBRF0pgQM5Q==	2026-05-16 10:17:07.228995+00	f	2026-04-16 10:17:07.228964+00	3b77085b-d895-4074-9e32-2022c609b673
ae928d23-2128-4db2-b302-80d7794adfa9	xT5pR+Pfmjo7qlbg2RMNBbfHb2oP/s/sq2JTN48f8sB/XTrURwORcRgD1NHEW1hyK4Pm2etplZRZ3Mm5Qq43WA==	2026-05-16 12:10:43.701543+00	f	2026-04-16 12:10:43.701442+00	3b77085b-d895-4074-9e32-2022c609b673
2dd34cf4-f94a-4a3e-adf0-4eaec631832d	1VLnmOsuF3QzwVjtcUATm35WVMDpD/r+aXECRir3WO4zP9NRcpGifIcSZhaOuCJzIJ+Y2Jof5CGu4POYeDwxqQ==	2026-05-16 12:14:04.580522+00	f	2026-04-16 12:14:04.580477+00	019d9634-10f6-7e3d-8898-a05a0de01bd7
beef0aa0-ccfa-4cb0-8404-227ba513190b	UxKQGVD/sdcX1NujMyYL2OPUSDFp0y/AdxqC1Mgls6eU1rNba7otP5jPphU4UqG2MVdIf0KgSQd+DOY68uTnKw==	2026-05-16 12:14:55.118594+00	f	2026-04-16 12:14:55.118534+00	3b77085b-d895-4074-9e32-2022c609b673
49c2fc46-8d39-4211-b829-b3e2fae77533	k6ZYxT9J74HyRKvEr3hVaTS5U7e9h3rebyllMOPgw9pZVeC8D0VznE9nNzSF6wcO2yLqescmNhsZWvb/hUw/pg==	2026-05-16 12:15:06.666614+00	f	2026-04-16 12:15:06.66659+00	3b77085b-d895-4074-9e32-2022c609b673
22a11987-ecaf-4281-8e07-0aecb9a54e62	xZ+jK2B+0aQ/VL+cRWVbkgXaTc2eUeaCeIdwKx01sRHXI6RZbh7tsOZfM+2qKaWBe8fodMXJt3GZv6w2QgZq9w==	2026-05-16 13:26:23.022421+00	f	2026-04-16 13:26:23.022304+00	3b77085b-d895-4074-9e32-2022c609b673
76ba60d5-3e10-40f1-9fbb-18a4cb185eaf	GHOxtJkOBtW6MPts+aRmJLvBQJqziqtfmqy7Fn6yjDGBVSa642EgPW+KlQQBbR0ZExFn4dRnwJWalriVIIwl9A==	2026-05-16 17:04:56.954369+00	f	2026-04-16 17:04:56.954083+00	3b77085b-d895-4074-9e32-2022c609b673
a07708c4-b5d0-40c3-8a1e-54e769491b5c	MHzZ8Ymv8FdgwbS8hdULpVmrYBkTU7FUlaMKIBp44nn84CdZXBW1YB1Wi66T89f3Xw7auGnJkJOQk8TiA0jaNQ==	2026-05-16 17:09:12.740558+00	f	2026-04-16 17:09:12.740357+00	0f8ed8de-312a-498a-84fa-3ef04e663455
52794af9-7c01-4a93-888d-0128c246e624	cAWWOxL6K0xtU6UjlwbBSF5RsdSc08+kYYEZf18/S+oTc5yJ0Cer+473Q2RzGKtRoZn+CEdzGPwoP+oTzxcU7Q==	2026-05-16 17:09:58.635417+00	f	2026-04-16 17:09:58.635326+00	0f8ed8de-312a-498a-84fa-3ef04e663455
8056de33-8915-4563-b9de-50be050a6e26	zEaExMV6yVn2Mj/94enVenzK6SN/E9yMtb9kRUu0wd/E9Je/UK/pGzUN6CGAY1M4B0PClWVXgR08LLW6opmxUA==	2026-05-16 17:10:29.018031+00	f	2026-04-16 17:10:29.018004+00	0f8ed8de-312a-498a-84fa-3ef04e663455
8245071f-87fd-40d9-a3c7-d3a2cec9d23f	FeIVLSBTUuES4TjCVe1e6Rk/aslSkSFjVoy6SaphS/nGWjrWjjNkFhi6S64UXvIVmfyIw3Gf5YNNPRdYLiIeSQ==	2026-05-16 17:11:05.008626+00	f	2026-04-16 17:11:05.008575+00	0f8ed8de-312a-498a-84fa-3ef04e663455
02a03bca-bf13-4b5a-93c1-fd63e93e1738	To47ALYNF/qhEcylD0jVuIUOk4JireBVGjrE9w4aCHrrH3/7J3dJNohsmMI5XWHpg/qNZIqzy7L5vO/93MuoBA==	2026-05-16 17:11:40.895751+00	f	2026-04-16 17:11:40.895676+00	0f8ed8de-312a-498a-84fa-3ef04e663455
26818a40-ff85-4eed-b55b-5b41cca0f674	gTyi2mvkJyp686fXBjtiflNyLj2rCGdrUPGLvuDozRhcWQM3t5pbUYHlwGCCgcJrMvTvYvcoGGCaIauO6kfmlA==	2026-05-16 17:12:17.702264+00	f	2026-04-16 17:12:17.702214+00	0f8ed8de-312a-498a-84fa-3ef04e663455
0ae81dd8-2c5b-4bed-b35d-e5255b3ead21	HVs90TFT0H3H9z2HN5ZQCDWIOAK/f1eG+WbXD55PDYel+GO2txHvkx6ojuyyDX/NFzkfs0uTaMGjZ6ECnqBGTA==	2026-05-16 17:12:48.006956+00	f	2026-04-16 17:12:48.006911+00	0f8ed8de-312a-498a-84fa-3ef04e663455
4d454a98-04bf-4567-b7b5-f7312ca5288e	/OfYeOuUSp2DaCgtT+g5NeG7bhR9iwbucSzuu0GE46uAzTNxFds0pJM1y4OSFP4oVtlH5shi3GT9JHtLW6zodA==	2026-05-16 17:13:28.355998+00	f	2026-04-16 17:13:28.355976+00	0f8ed8de-312a-498a-84fa-3ef04e663455
f6b1cbdb-0109-42f4-95af-030e43e12007	mwlT2Gp/F5hpAIrGg2UUhN1ztmq3SjmQ8efV01upYfgf82apug9zm27ALDUrz2LvfILWhT5BjK3UApPoaW0rIQ==	2026-05-16 17:14:02.035241+00	f	2026-04-16 17:14:02.035184+00	0f8ed8de-312a-498a-84fa-3ef04e663455
114ee805-bcf4-4cae-a2ed-f2d0607229f3	Qmv6vQORYwR/Jhxo7TRNuSkkthdWT2J7BfOynm5sGNDnQDxRHSvwRqUSA1yJjxotWhFMsfPUXZdBsWXd3K0v1w==	2026-05-16 17:14:35.655614+00	f	2026-04-16 17:14:35.655592+00	0f8ed8de-312a-498a-84fa-3ef04e663455
46034179-a60a-424a-ba5f-d024bd278a92	zo4JMHs7s9Epig1+W2UaNH4KQiBmtGoeGV9tEIYL1Fuo3EHrvKOBZGjEnGzIBGXsAW/CN8UK5BSSXHRMlRmggQ==	2026-05-16 17:20:24.613841+00	f	2026-04-16 17:20:24.608151+00	3b77085b-d895-4074-9e32-2022c609b673
6ece9dda-fb69-4e96-9ba8-d39f0886a3e0	vy4dOx6NEC9Jf54NVQ3z8fzQ1tnE20JGkZbNTubeAe6pVcWqSRQ4abuoUuUqQ5vqbWMuV5R/OnNrQhzDaWmLVA==	2026-05-16 17:22:22.676898+00	f	2026-04-16 17:22:22.676852+00	0f8ed8de-312a-498a-84fa-3ef04e663455
d5aa31a5-0c8a-4881-921f-b0ca97d59c17	vyk8+scSomcGCCqC2wqikjGKFdj7xnX++JY9ENrTk+4WaS4KjhHz3zelc4BjkwgdL1YLrSRFiBFWiBqoMev58w==	2026-05-16 17:23:08.415537+00	f	2026-04-16 17:23:08.415505+00	0f8ed8de-312a-498a-84fa-3ef04e663455
2f65be0b-e299-4ebc-96b4-ff041579604f	ctUNBNZdVyjsV6raTenc4cKBnu3AqfkpQgmdMui60bN/lFmrxDvSLTQ2JhMhrDiVX4tcOpW8ru/2oICDKrUX+g==	2026-05-16 17:23:38.81743+00	f	2026-04-16 17:23:38.817397+00	0f8ed8de-312a-498a-84fa-3ef04e663455
2850bb85-5131-402e-ab17-20e9b8b6da8e	s0BFaDGqfrxxKzB8EGfncOzvkvM9Cexnh1d6R+1gtbQDTlWT9kA8uiaTV4lhUwsEP8FDg7ONllDUjtj/lHZw+Q==	2026-05-16 17:24:14.727387+00	f	2026-04-16 17:24:14.727322+00	0f8ed8de-312a-498a-84fa-3ef04e663455
6014d21e-8836-4529-bb43-6e572b53bdae	AiSsRll5mUsJwFD/5+ovVJcx4yRLfK4lLV3gY8+k8X6MhbDD9y9n8h4/7ljWZvVLOGIytpPZ84PTS5seNWszsw==	2026-05-16 17:24:50.618633+00	f	2026-04-16 17:24:50.618601+00	0f8ed8de-312a-498a-84fa-3ef04e663455
170fb1cd-c6eb-4aa0-9a49-b198d44e10d7	dVwaaN6A2Vjj6yTTzUKovdwaQYN+nd8q/Yy5GexxtC+m1VjOR7dpgnj6PZYtfihKEJ0qHi60WqbPwnXodJfzfg==	2026-05-16 17:25:27.415863+00	f	2026-04-16 17:25:27.415813+00	0f8ed8de-312a-498a-84fa-3ef04e663455
a82f7259-0faa-4bee-8580-f0d66abcafb3	9c8w+X3O+pQ/CvOR9jkwENEbjRvmhekUEPiCM1E+s9RR+RZYLNnjZL/oSnz2LtHizyqPDwhwhM0MWslv2R6NYw==	2026-05-16 17:25:57.589642+00	f	2026-04-16 17:25:57.589629+00	0f8ed8de-312a-498a-84fa-3ef04e663455
7deabcdd-6e9d-4438-9174-6d4fccb8a280	sHmAkHzRWNhWvkkBf0JOo6GLvK/8Fz5TMPH+zcoREw841f0Gm8vlKL1sz0pxBeyqLHcOIWkAYePchIzgpnSm9w==	2026-05-16 17:26:37.860964+00	f	2026-04-16 17:26:37.860907+00	0f8ed8de-312a-498a-84fa-3ef04e663455
b8e0afc3-f29c-4338-b797-e98c9071a2c6	skKQCJkuNIvMZZNqNI3dn4D8lyACo2wLB65ks7DvwWUjyjiyApcuS+shke4Rc/uAD5RtBjO4cSKrNkHnq1XpRQ==	2026-05-16 17:27:11.432545+00	f	2026-04-16 17:27:11.432112+00	0f8ed8de-312a-498a-84fa-3ef04e663455
9191e51f-344c-4cc5-908a-a1eacb652487	3uCzedPK7oKxa+dDBaM/BYo2gK6Kb81X2jueo/NAbUN3/qQ4RkkqIWVfjrNDP+76CRK81OTat/dmT8me3CaJag==	2026-05-16 17:27:45.109216+00	f	2026-04-16 17:27:45.109065+00	0f8ed8de-312a-498a-84fa-3ef04e663455
f92a7831-1f0f-4cff-82ec-35f2b20462a0	p+Uh0P+F/Nm63LpgUaEZ+r+F34laoCA0UINY/tBMR+L4dR4DFNuGf+owFilMRr99NC6vVNSYQNnVDpqslXkA5Q==	2026-05-16 17:53:02.621388+00	f	2026-04-16 17:53:02.621327+00	0f8ed8de-312a-498a-84fa-3ef04e663455
1d7b2fc7-2685-4459-8cc7-38b674efa3ca	516IJNX8W8ni7GOxAYz7PIl9s0GWAjMMgrn8DX8EuXIUDgaf7P5HTqEZL38rgGvx6NEh/qz2+0b/dLOw6OiAeA==	2026-05-16 17:53:49.914194+00	f	2026-04-16 17:53:49.914148+00	0f8ed8de-312a-498a-84fa-3ef04e663455
8261bdf8-353a-4edc-943a-8403e264c3a1	N8bUTLvQNMMqIGdCOkpUN5HFVbDvfER/VcIpy2UOkouvfoYaX+9qkCrXyzHEFv4J/V+r4iga7Tx7M/gb5RZj5w==	2026-05-16 17:54:20.116443+00	f	2026-04-16 17:54:20.116351+00	0f8ed8de-312a-498a-84fa-3ef04e663455
05d940dc-6854-4d07-8b1e-b992ab27a6a0	PWITfulpkrT9ZMbdsNARzBs7RNu2hbLmGMQd2DJRcOJE5ZfZBVJgIIBz8VEsfrfelaovrxeKCgsEyynTPVwtpA==	2026-05-16 17:54:54.352051+00	f	2026-04-16 17:54:54.352001+00	0f8ed8de-312a-498a-84fa-3ef04e663455
70755936-a821-45cf-a969-e350bc1c7936	13hnd58vkcrEPCkV2JjoGjdz9b9brGEdJiixmfpPGYZwIpYxh1lXNbd7xzCv9LwZSzNt/utCapIiwfQsWjtnjA==	2026-05-16 17:55:28.107452+00	f	2026-04-16 17:55:28.107408+00	0f8ed8de-312a-498a-84fa-3ef04e663455
7d7f74a9-52ec-4034-9d72-aa79e84b7fe2	Sw9eHtIy2SttqTZ24kr1fisOdFzFPY1kkrRTRAAhMotA0LlCwVnjEOGJm43ByBRWnI5GOXDf4MEGhhPfF2K5yA==	2026-05-16 17:56:02.908227+00	f	2026-04-16 17:56:02.908179+00	0f8ed8de-312a-498a-84fa-3ef04e663455
4841c70b-2075-4692-b3fb-1a1785c9f1ed	Qnw/QV+GyeaIadb6wvlTyXRzP+HWdVDMWHo5zH22tQITvWf3xH2CUZc9SytWQ0AiR2rhy0Nm9Jp7N16HXs+8RQ==	2026-05-16 17:56:33.353105+00	f	2026-04-16 17:56:33.353072+00	0f8ed8de-312a-498a-84fa-3ef04e663455
6fa28017-071c-431e-837f-1738d3d505e1	96VV6beESodP3oe6epQEBs8Nsoe8pI5zeJP9Ohb+5iYv+l5rzPoV0QHAZ6GWeybMAtdpDZB0lYNN18owEVWTyA==	2026-05-16 17:57:13.553095+00	f	2026-04-16 17:57:13.553079+00	0f8ed8de-312a-498a-84fa-3ef04e663455
3310b4d0-4232-4106-afe1-1dd4fce8c7e8	7CArKZFUfDs9hGMBUoicU+WBOx3QsPk1r9tN5JPC06IDk1Lx+7hpy9jTTYisTUsGWXVnEOBkZcbGsn8j0n5cIw==	2026-05-16 17:57:47.228523+00	f	2026-04-16 17:57:47.228504+00	0f8ed8de-312a-498a-84fa-3ef04e663455
b826c2da-6b24-44b3-a2bf-de227fb0c7b4	Pr9zuQd6ted6ymWMe6wpo3jRL/YwGnqwDBi4p2bLO4jwfBvAPX9dkAtAYZ7WSlfSrUsiR3kfa18XD2Fz9PL6Lg==	2026-05-16 17:58:20.868837+00	f	2026-04-16 17:58:20.868817+00	0f8ed8de-312a-498a-84fa-3ef04e663455
\.


--
-- Data for Name: Rooms; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."Rooms" ("Id", "Name", "DepartmentId", "OrganizationId", "CreatedDate", "UpdatedDate", "DeletedAt", "IsDeleted") FROM stdin;
04916acb-b3eb-471b-a92d-cbbd0f5ad15a	Кабінет №114	acf504b1-f916-4571-9f89-0cab40073f0a	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366122+00	\N	\N	f
27850b62-e6d1-4390-b605-25e67a51d7fe	Кабінет №122	25af8e61-06e9-44a4-b7c9-fb04d4d572d3	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366124+00	\N	\N	f
336f75b8-38e0-492a-8b97-7c881f795c8a	Кабінет №130	d543dc16-edef-440c-a265-788e086f0f2b	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366126+00	\N	\N	f
3662fb73-5a64-4205-955c-aaaba5b2d5a5	Кабінет №102	907130cb-72f7-4aab-a952-9131360f15f4	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366113+00	\N	\N	f
40f087b0-f7df-4b55-a049-d99970224401	Кабінет №119	acf504b1-f916-4571-9f89-0cab40073f0a	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366123+00	\N	\N	f
436010d1-9eea-4e81-8ed4-9dfc9f7c4705	Кабінет №107	5626defc-cc69-4d54-bab2-6e225f6b5c7c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.36612+00	\N	\N	f
481a88b9-2873-4ffa-810f-64bc51ddb14b	Кабінет №115	acf504b1-f916-4571-9f89-0cab40073f0a	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366122+00	\N	\N	f
6108aefa-43fc-4d40-97f1-ac5a264ff611	Кабінет №126	373e7c8c-48ab-4f35-9240-0b907526aca8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366125+00	\N	\N	f
69e5f864-601b-42b4-a61d-e7bc5a00dd65	Кабінет №104	5626defc-cc69-4d54-bab2-6e225f6b5c7c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366114+00	\N	\N	f
6e8302c7-2463-4de5-af27-181deddfe82b	Кабінет №112	e57afb5b-0534-4748-bf04-b86569d01ec8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366121+00	\N	\N	f
78495cef-14ab-4bcc-8bf1-53bd5bcd1b90	Кабінет №132	d543dc16-edef-440c-a265-788e086f0f2b	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366127+00	\N	\N	f
7b5ae4fc-9f58-4f40-86e7-64382ccd25f4	Кабінет №116	acf504b1-f916-4571-9f89-0cab40073f0a	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366122+00	\N	\N	f
7f66fb20-757f-4f32-a1da-99877e85e55d	Кабінет №103	5626defc-cc69-4d54-bab2-6e225f6b5c7c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366114+00	\N	\N	f
7fab6a19-2926-4397-a68f-5a11ec7d5d08	Кабінет №110	e57afb5b-0534-4748-bf04-b86569d01ec8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.36612+00	\N	\N	f
80d24fc9-18c5-4ff0-baec-5e6d5cec7e34	Кабінет №134	d543dc16-edef-440c-a265-788e086f0f2b	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366127+00	\N	\N	f
83dc9aea-50bb-4fed-b8c3-ff8453946d7f	Кабінет №131	d543dc16-edef-440c-a265-788e086f0f2b	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366127+00	\N	\N	f
8b7e1331-bd0a-4eef-99a0-becf39981635	Кабінет №123	25af8e61-06e9-44a4-b7c9-fb04d4d572d3	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366124+00	\N	\N	f
8bf68ad2-589d-4dcf-8302-c3eb98c75c21	Кабінет №125	373e7c8c-48ab-4f35-9240-0b907526aca8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366125+00	\N	\N	f
90dab6ed-5999-4284-b8e4-dfbf3afbbbf4	Кабінет №127	373e7c8c-48ab-4f35-9240-0b907526aca8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366125+00	\N	\N	f
9968d210-7c8b-4534-bdec-24e969370549	Кабінет №113	e57afb5b-0534-4748-bf04-b86569d01ec8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366121+00	\N	\N	f
9ca3ea77-ff06-4928-b6ae-befc55471496	Кабінет №117	acf504b1-f916-4571-9f89-0cab40073f0a	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366123+00	\N	\N	f
9d0eee5f-cb26-4b59-849f-d0370435c525	Кабінет №100	907130cb-72f7-4aab-a952-9131360f15f4	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.36611+00	\N	\N	f
9d6279f8-96b9-4821-932c-d5eea6127bea	Кабінет №128	373e7c8c-48ab-4f35-9240-0b907526aca8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366126+00	\N	\N	f
9e7c904a-6278-404e-ada5-2bc26b3e2909	Кабінет №133	d543dc16-edef-440c-a265-788e086f0f2b	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366127+00	\N	\N	f
a16c5c84-698b-4028-99b6-ab9bb607d657	Кабінет №109	e57afb5b-0534-4748-bf04-b86569d01ec8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.36612+00	\N	\N	f
a5c13bf0-a0b8-4a64-8635-33fd0fcafa21	Кабінет №129	373e7c8c-48ab-4f35-9240-0b907526aca8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366126+00	\N	\N	f
b2dbdb91-713d-423e-b6f4-8ec89dcec27b	Кабінет №108	5626defc-cc69-4d54-bab2-6e225f6b5c7c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.36612+00	\N	\N	f
b66aeac2-86ee-44e6-ab84-de48fbdb4f67	Кабінет №120	25af8e61-06e9-44a4-b7c9-fb04d4d572d3	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366124+00	\N	\N	f
c27f6cf8-c1bf-47de-939a-5ef8598892f9	Кабінет №118	acf504b1-f916-4571-9f89-0cab40073f0a	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366123+00	\N	\N	f
c5effaa1-2180-49bd-bcdd-c27687277d8f	Кабінет №106	5626defc-cc69-4d54-bab2-6e225f6b5c7c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366119+00	\N	\N	f
d6b888c6-0caf-4e53-a105-8cde96eb9c84	Кабінет №101	907130cb-72f7-4aab-a952-9131360f15f4	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366112+00	\N	\N	f
ea28d6cc-4920-444c-966e-4e53c3db1049	Кабінет №124	373e7c8c-48ab-4f35-9240-0b907526aca8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366125+00	\N	\N	f
f339d07a-923c-405d-b955-cc9988579b89	Кабінет №111	e57afb5b-0534-4748-bf04-b86569d01ec8	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366121+00	\N	\N	f
f5e04ce1-7d54-4115-88f9-b9bd349a85a8	Кабінет №105	5626defc-cc69-4d54-bab2-6e225f6b5c7c	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366119+00	\N	\N	f
ffb19a44-0968-4885-9987-6f13453254dd	Кабінет №121	25af8e61-06e9-44a4-b7c9-fb04d4d572d3	69d1796a-d3cb-4761-b636-873c46de50ad	2026-04-10 08:45:43.366124+00	\N	\N	f
004d1a3a-ec39-4cbc-861e-de225891f856	Кабінет №115	eb261711-a00f-4ff4-bb5d-32a4ecdbc212	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299437+00	\N	\N	f
10a3deb3-80b7-4c85-9b4f-38d246e99eb2	Кабінет №110	3295fde9-7647-4cc4-8d60-1be8135bbdec	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299434+00	\N	\N	f
1b531da9-35f7-41ae-915a-ce77f04b5228	Кабінет №102	70e78b0b-86b2-4787-9572-2ef52fe02870	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299432+00	\N	\N	f
2817f369-a56d-4949-823f-805bf7f2df61	Кабінет №109	3295fde9-7647-4cc4-8d60-1be8135bbdec	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299434+00	\N	\N	f
36f395d8-de6b-45c8-ab93-cafab46f48f3	Кабінет №108	3295fde9-7647-4cc4-8d60-1be8135bbdec	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299434+00	\N	\N	f
4049ad5e-a924-4dd7-9858-f023ad614348	Кабінет №100	70e78b0b-86b2-4787-9572-2ef52fe02870	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299431+00	\N	\N	f
5773cf3d-4e76-4742-9d52-19b41d0d4b19	Кабінет №101	70e78b0b-86b2-4787-9572-2ef52fe02870	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299431+00	\N	\N	f
6463aaf3-3178-4a75-8793-7fa78c268ea5	Кабінет №105	3295fde9-7647-4cc4-8d60-1be8135bbdec	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299433+00	\N	\N	f
6b3ed101-5b9e-4e44-bc5a-c0010d31bccf	Кабінет №113	33be1ee6-6a54-486b-ab0d-806481ec2aef	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299435+00	\N	\N	f
7de1e7a3-0ad0-495a-842a-3d67c0d57fee	Кабінет №120	093635d4-2442-48d6-ba13-82572bc97bfb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299438+00	\N	\N	f
7f9d678a-7f72-413f-a368-7ba5e93b2ca7	Кабінет №111	33be1ee6-6a54-486b-ab0d-806481ec2aef	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299435+00	\N	\N	f
89ba9b67-ba5c-4c15-a566-3cca01da6fbd	Кабінет №118	eb261711-a00f-4ff4-bb5d-32a4ecdbc212	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299438+00	\N	\N	f
ae69dc8c-e35b-41d9-89d9-af2dce06580d	Кабінет №117	eb261711-a00f-4ff4-bb5d-32a4ecdbc212	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299437+00	\N	\N	f
d167a77b-64b1-478c-96b2-7422d2f7221b	Кабінет №116	eb261711-a00f-4ff4-bb5d-32a4ecdbc212	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299437+00	\N	\N	f
d503c0c6-7680-4183-a7eb-cb93ee6e5277	Кабінет №106	3295fde9-7647-4cc4-8d60-1be8135bbdec	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299433+00	\N	\N	f
dfdde900-e2b8-4728-8138-a980bd48568e	Кабінет №103	70e78b0b-86b2-4787-9572-2ef52fe02870	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299432+00	\N	\N	f
e04c300c-0cad-43a7-b944-0f0c4ae340f5	Кабінет №107	3295fde9-7647-4cc4-8d60-1be8135bbdec	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299433+00	\N	\N	f
e5528baf-72d5-47f0-b312-be4fa760fd8e	Кабінет №114	eb261711-a00f-4ff4-bb5d-32a4ecdbc212	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299437+00	\N	\N	f
e917cc43-1bda-4bbd-a99f-303928d07cc9	Кабінет №104	70e78b0b-86b2-4787-9572-2ef52fe02870	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299433+00	\N	\N	f
f53df19e-696b-4f2f-9504-4f10884aa52d	Кабінет №119	093635d4-2442-48d6-ba13-82572bc97bfb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299438+00	\N	\N	f
f7570a7b-4f81-438c-b8c2-98d116bc1fff	Кабінет №121	093635d4-2442-48d6-ba13-82572bc97bfb	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299438+00	\N	\N	f
fcefa63d-e806-44c6-b533-9460adf62c19	Кабінет №112	33be1ee6-6a54-486b-ab0d-806481ec2aef	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	2026-04-10 08:45:44.299435+00	\N	\N	f
0461e3c5-341e-4f22-b971-b36d8eb8bee5	Кабінет №113	4adc0153-1f37-4020-9535-eb744b344006	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.90947+00	\N	\N	f
0479c322-7998-4928-bc6c-ed1728564692	Кабінет №114	4adc0153-1f37-4020-9535-eb744b344006	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.90947+00	\N	\N	f
076842ca-e622-4a49-a6cc-44b4035c9e52	Кабінет №111	6a7807ce-1f0a-40df-8872-a13814f02b15	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909469+00	\N	\N	f
079202fc-f4b6-4cb3-b373-035043e55714	Кабінет №116	4adc0153-1f37-4020-9535-eb744b344006	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909471+00	\N	\N	f
1f2474f4-3400-4c46-94d6-44a1e764709d	Кабінет №109	6a7807ce-1f0a-40df-8872-a13814f02b15	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909469+00	\N	\N	f
217306f8-b150-40dc-902a-446f464d7a3c	Кабінет №131	e8f8987f-d0fa-43ab-9295-10cf0500a467	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909479+00	\N	\N	f
2352bfd1-4067-4a86-a351-b9ab58388683	Кабінет №101	28df8d82-7849-4ce2-8896-8b0eac2643e6	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909466+00	\N	\N	f
29bbc7dc-a6a1-4fb0-972e-e80811a11700	Кабінет №115	4adc0153-1f37-4020-9535-eb744b344006	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909471+00	\N	\N	f
2ce0cff5-442e-4f46-9077-6aaa0f61c6b3	Кабінет №103	28df8d82-7849-4ce2-8896-8b0eac2643e6	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909466+00	\N	\N	f
313d0bb0-3a49-42ed-9ff9-1dd5f9df9173	Кабінет №108	6a7807ce-1f0a-40df-8872-a13814f02b15	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909469+00	\N	\N	f
365f6f08-9137-4956-acda-457b00acd209	Кабінет №118	bdd99256-b436-41aa-8bb6-488553bf00c5	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909471+00	\N	\N	f
37d9f1bc-8732-48fe-af7e-3fcbe8a5a014	Кабінет №132	e8f8987f-d0fa-43ab-9295-10cf0500a467	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909479+00	\N	\N	f
3b6ea93b-beac-492d-bcb2-ac9e581e95ce	Кабінет №105	28df8d82-7849-4ce2-8896-8b0eac2643e6	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909467+00	\N	\N	f
3e7c3e48-9503-4f75-9dce-76be755a2f95	Кабінет №128	1ca1c8a6-8773-495d-a9f7-229a2070f4b3	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909478+00	\N	\N	f
587316a8-6fdc-4bb2-b9d0-623d676ff4a4	Кабінет №130	e8f8987f-d0fa-43ab-9295-10cf0500a467	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909479+00	\N	\N	f
5c6adbe7-27da-4ce7-bce7-bae394c93d2b	Кабінет №122	bdd99256-b436-41aa-8bb6-488553bf00c5	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909473+00	\N	\N	f
6316371e-0939-4af5-aa35-1597aa93cfc5	Кабінет №112	4adc0153-1f37-4020-9535-eb744b344006	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.90947+00	\N	\N	f
66a35332-cd17-49d9-8ed6-7fbdfacb9168	Кабінет №117	4adc0153-1f37-4020-9535-eb744b344006	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909471+00	\N	\N	f
6b35ce62-2168-4fe2-b2c9-c8d0f81a3d01	Кабінет №127	1ca1c8a6-8773-495d-a9f7-229a2070f4b3	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909478+00	\N	\N	f
7e9a0a89-a695-4d0a-b01b-8afdb4990568	Кабінет №129	e8f8987f-d0fa-43ab-9295-10cf0500a467	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909479+00	\N	\N	f
8c9fdd04-67dc-42eb-b920-43be0d71c834	Кабінет №107	6a7807ce-1f0a-40df-8872-a13814f02b15	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909468+00	\N	\N	f
99863a2f-17ac-4699-a867-fae4b305606f	Кабінет №124	1ca1c8a6-8773-495d-a9f7-229a2070f4b3	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909474+00	\N	\N	f
9d211c6a-8c3a-42a9-85ea-093200480e11	Кабінет №126	1ca1c8a6-8773-495d-a9f7-229a2070f4b3	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909478+00	\N	\N	f
a223023d-0597-40a9-bacb-d3dbcd108cdc	Кабінет №100	28df8d82-7849-4ce2-8896-8b0eac2643e6	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909462+00	\N	\N	f
af4df86b-7dcb-49f8-9747-d8cc8d8239a2	Кабінет №104	28df8d82-7849-4ce2-8896-8b0eac2643e6	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909467+00	\N	\N	f
c76e49d4-d358-4fe5-9484-d3beb2a1d20f	Кабінет №106	6a7807ce-1f0a-40df-8872-a13814f02b15	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909468+00	\N	\N	f
d45fda48-f591-4da2-88d8-f5e89c2a9176	Кабінет №123	bdd99256-b436-41aa-8bb6-488553bf00c5	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909473+00	\N	\N	f
dd1e5770-88bc-493e-babb-eea69de9cfe8	Кабінет №102	28df8d82-7849-4ce2-8896-8b0eac2643e6	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909466+00	\N	\N	f
e199b8f0-ede7-48cf-832b-e661283d0fbb	Кабінет №110	6a7807ce-1f0a-40df-8872-a13814f02b15	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909469+00	\N	\N	f
e91170b9-a9b7-4bcc-b334-a456031add44	Кабінет №120	bdd99256-b436-41aa-8bb6-488553bf00c5	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909472+00	\N	\N	f
f099dd7a-37d9-4f8b-8151-775ac63c6b45	Кабінет №119	bdd99256-b436-41aa-8bb6-488553bf00c5	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909471+00	\N	\N	f
f0bdfb1e-d2ac-4ae1-8986-297379b0d079	Кабінет №121	bdd99256-b436-41aa-8bb6-488553bf00c5	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909473+00	\N	\N	f
fa529b02-f033-4e20-8f33-dafa8a271efe	Кабінет №125	1ca1c8a6-8773-495d-a9f7-229a2070f4b3	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	2026-04-10 08:45:44.909478+00	\N	\N	f
0e59249b-2b27-4ec0-8648-81b3a7dac4e7	Кабінет №120	229c2be0-4fd6-412b-b870-b488e449c9d3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594294+00	\N	\N	f
16b459f0-09c8-42d1-a967-cf5a9b96b57d	Кабінет №116	229c2be0-4fd6-412b-b870-b488e449c9d3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594293+00	\N	\N	f
1e9c8b21-1440-4014-a7ea-26e2082f7acb	Кабінет №121	229c2be0-4fd6-412b-b870-b488e449c9d3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594294+00	\N	\N	f
2e788830-e4e6-4c19-a7d6-25d8c406366e	Кабінет №127	f84bf2c3-a30f-4f12-9690-02ba51ab317d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594296+00	\N	\N	f
2e7ed6dd-6122-497f-8e97-fc03d43dc07c	Кабінет №104	5faec016-5b45-4f64-b42d-0df65713e837	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594288+00	\N	\N	f
2faa3536-7802-4e55-8255-6b41930c49bb	Кабінет №129	f84bf2c3-a30f-4f12-9690-02ba51ab317d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594296+00	\N	\N	f
3729896d-8b55-4a8a-9017-2d66b3ff3cbd	Кабінет №110	a42aa014-2f14-4edf-9982-bd478b090e4f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59429+00	\N	\N	f
3c1e8c23-16ce-46c8-b8bf-f5019d80aa74	Кабінет №125	62903c81-d34c-4d49-a3c7-e1a53b1d2edf	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594295+00	\N	\N	f
41fe2d23-c2ad-423d-9bf9-7ac563a30189	Кабінет №118	229c2be0-4fd6-412b-b870-b488e449c9d3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594294+00	\N	\N	f
4b44088f-b767-4498-afcd-c0ac3bc4770d	Кабінет №115	c49b0d33-5ae6-4d21-a588-065edfcd4888	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594293+00	\N	\N	f
57f56efc-685b-407a-a058-8c5250dd41f0	Кабінет №130	f84bf2c3-a30f-4f12-9690-02ba51ab317d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594296+00	\N	\N	f
5832f208-dafd-4a4c-af66-d3eb052dcb89	Кабінет №105	5faec016-5b45-4f64-b42d-0df65713e837	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594289+00	\N	\N	f
679558a7-ebf0-4e80-9049-e283043d21db	Кабінет №128	f84bf2c3-a30f-4f12-9690-02ba51ab317d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594296+00	\N	\N	f
68705669-2b4f-45bc-b0d5-440b877dc04e	Кабінет №131	f84bf2c3-a30f-4f12-9690-02ba51ab317d	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594296+00	\N	\N	f
6fe71059-eeb2-4a78-8f6b-a25ca1a0ec0d	Кабінет №113	c49b0d33-5ae6-4d21-a588-065edfcd4888	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59429+00	\N	\N	f
75ea03b5-ca8e-4747-99ce-e33ca199c0d4	Кабінет №126	62903c81-d34c-4d49-a3c7-e1a53b1d2edf	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594295+00	\N	\N	f
787581ce-3451-44a7-bff9-48003c92cda9	Кабінет №112	c49b0d33-5ae6-4d21-a588-065edfcd4888	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59429+00	\N	\N	f
78a44684-6b2e-485d-b4ef-0cb4a0ec77f4	Кабінет №107	a42aa014-2f14-4edf-9982-bd478b090e4f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594289+00	\N	\N	f
7a9664d3-7f2b-497a-8369-ea2a099f03d2	Кабінет №114	c49b0d33-5ae6-4d21-a588-065edfcd4888	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59429+00	\N	\N	f
87c6099f-9368-4267-9dbc-019928eeae8b	Кабінет №101	ef0ef570-07d6-457f-af27-cd7407353dbe	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594288+00	\N	\N	f
89b401af-ee3c-4e70-9aaa-a1a77268efba	Кабінет №102	ef0ef570-07d6-457f-af27-cd7407353dbe	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594288+00	\N	\N	f
a15947c1-0fcc-4b79-a6c3-c158181831ab	Кабінет №117	229c2be0-4fd6-412b-b870-b488e449c9d3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594294+00	\N	\N	f
a9bfccd0-1a4d-4db9-92b7-dc21076fd3a6	Кабінет №123	62903c81-d34c-4d49-a3c7-e1a53b1d2edf	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594295+00	\N	\N	f
afc56bd2-44ab-4784-b341-5182c4fff357	Кабінет №103	ef0ef570-07d6-457f-af27-cd7407353dbe	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594288+00	\N	\N	f
b7c27d7b-2b9a-44d5-af05-db062605bf3d	Кабінет №100	ef0ef570-07d6-457f-af27-cd7407353dbe	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594287+00	\N	\N	f
bfe87682-ae5d-4677-bd0c-1cdf2d6ac016	Кабінет №109	a42aa014-2f14-4edf-9982-bd478b090e4f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59429+00	\N	\N	f
c27e1078-5a98-44c3-96a6-b5cdc509226c	Кабінет №119	229c2be0-4fd6-412b-b870-b488e449c9d3	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594294+00	\N	\N	f
ccf36e37-43ae-405f-9290-583474db7c0d	Кабінет №106	5faec016-5b45-4f64-b42d-0df65713e837	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594289+00	\N	\N	f
d5bfba3f-0592-4dfe-8e23-551d6ebd65f7	Кабінет №108	a42aa014-2f14-4edf-9982-bd478b090e4f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594289+00	\N	\N	f
d5f00d47-4f27-444d-90f8-b3c84456d124	Кабінет №124	62903c81-d34c-4d49-a3c7-e1a53b1d2edf	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594295+00	\N	\N	f
df7fa17d-5b6c-4c89-9f10-03aa10f74dd3	Кабінет №122	62903c81-d34c-4d49-a3c7-e1a53b1d2edf	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.594295+00	\N	\N	f
e3ac9166-9f0f-486b-a252-d1fe06e7608e	Кабінет №111	a42aa014-2f14-4edf-9982-bd478b090e4f	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	2026-04-10 08:45:45.59429+00	\N	\N	f
10ce71d7-86c3-496a-8d03-a32ae6ce5e38	Кабінет №118	ed62e0cd-c3c4-4821-9a7e-9d7e8ed689d7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182809+00	\N	\N	f
1863336f-de06-43c5-855f-0358e4c9b03f	Кабінет №111	b499562d-dc37-489b-b148-e2cabea48b45	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182807+00	\N	\N	f
4a16eaa6-bfc0-4ea0-8494-1ff6b92e2552	Кабінет №117	ed62e0cd-c3c4-4821-9a7e-9d7e8ed689d7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182809+00	\N	\N	f
51d5f28a-0a63-45b5-a2a7-f7b2047caff2	Кабінет №104	85fb6ac3-f6e1-42dd-bc6a-9db53b023358	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182806+00	\N	\N	f
67c3562e-5ac8-4f1f-982f-f7e87530db9d	Кабінет №115	ed62e0cd-c3c4-4821-9a7e-9d7e8ed689d7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182808+00	\N	\N	f
69438a9a-b86c-4a93-b1c8-f1bd1b345c7a	Кабінет №116	ed62e0cd-c3c4-4821-9a7e-9d7e8ed689d7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182808+00	\N	\N	f
7ce73394-385e-404a-b505-d48fd64e1820	Кабінет №113	b499562d-dc37-489b-b148-e2cabea48b45	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182808+00	\N	\N	f
800870a0-6532-4ef7-a465-9123a4e89a2d	Кабінет №103	73fb67be-579d-4a4e-b020-23b5487b4c4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182806+00	\N	\N	f
8f54f625-6f2e-4d54-bf42-e7f0dd95b564	Кабінет №100	73fb67be-579d-4a4e-b020-23b5487b4c4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182804+00	\N	\N	f
a1b1d685-0300-4a44-8d53-fc838df3309d	Кабінет №107	85fb6ac3-f6e1-42dd-bc6a-9db53b023358	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182807+00	\N	\N	f
b2c4d784-58f5-4692-980b-3f13dc461122	Кабінет №108	85fb6ac3-f6e1-42dd-bc6a-9db53b023358	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182807+00	\N	\N	f
bb4f3239-ea16-4a2f-bfe0-535e39e7198a	Кабінет №102	73fb67be-579d-4a4e-b020-23b5487b4c4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182806+00	\N	\N	f
bc607998-d61d-44e7-904c-cf33152d7db1	Кабінет №112	b499562d-dc37-489b-b148-e2cabea48b45	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182808+00	\N	\N	f
bf57ed05-95c1-48e1-85de-0a20f57445c6	Кабінет №106	85fb6ac3-f6e1-42dd-bc6a-9db53b023358	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182806+00	\N	\N	f
df459e49-05dd-428b-82b1-c46bc82dba56	Кабінет №109	b499562d-dc37-489b-b148-e2cabea48b45	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182807+00	\N	\N	f
e8152a0a-3a66-41cb-9009-825fb698d418	Кабінет №114	ed62e0cd-c3c4-4821-9a7e-9d7e8ed689d7	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182808+00	\N	\N	f
f28f43de-4cb8-42c6-89bc-c45f9181faa1	Кабінет №105	85fb6ac3-f6e1-42dd-bc6a-9db53b023358	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182806+00	\N	\N	f
f2ad47df-f9d8-401d-b1ee-f31d02bcc7e9	Кабінет №101	73fb67be-579d-4a4e-b020-23b5487b4c4e	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182805+00	\N	\N	f
f950f047-6383-4bec-a645-83b248565e88	Кабінет №110	b499562d-dc37-489b-b148-e2cabea48b45	80ae5be4-384d-4c59-bace-7165043a8b73	2026-04-10 08:45:46.182807+00	\N	\N	f
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."Users" ("Id", "Email", "PasswordHash", "FirstName", "LastName", "Role", "FcmToken", "OrganizationId", "AvatarUrl", "CreatedDate", "UpdatedDate", "DeletedAt", "IsDeleted") FROM stdin;
1f2e36bb-b869-43c3-8993-c0ab8918a5ad	user13@org1.faims	AQAAAAIAAYagAAAAENcwk4mXWCB/nVxovGpPkdsxnlLSz6eYmjXDCeaLFxi98XVbevodvBTJde+i0fJ8pQ==	Радміла	Ткаченко	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.919459+00	\N	\N	f
28b2ef4b-569e-4925-bd00-8006dd4c5ffd	user3@org1.faims	AQAAAAIAAYagAAAAEKgsiZOio1dl07cl7QxkxuwmcQpg2iUn+FXnxoFlYE743NS+x7DWLzVujAIBVjI2PQ==	Альвіна	Опенько	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.46679+00	\N	\N	f
2b04b4d7-2de1-4b02-8e0b-9ffd67d1d495	user7@org1.faims	AQAAAAIAAYagAAAAEA9vIvcK0Fm46mDEyAH2c9CeG22B2Zxqx2T60xSC+mIdH2RNntlY9m7fqyufxkzAbw==	Яромил	Борецька	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.647431+00	\N	\N	f
40dd8bc1-9306-4823-b993-49ac350a806b	user2@org1.faims	AQAAAAIAAYagAAAAEPmfudE+I72SuxA2z75eSIS3ytNcYL+Wlzq6cN6Amgbzf9lnOQZnM1Pezm/2T2JoWg==	Марія	Павлів	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.421897+00	\N	\N	f
44587e9f-888b-4319-9dc5-c08d249d7cbe	user12@org1.faims	AQAAAAIAAYagAAAAEBX12k8dY13OXdtp5NivKzDIUjNRFsp8/iNhsW1fbNE5RkHYQorp1bhTY/nfz+g/7Q==	Афанасій	Мазайло	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.871817+00	\N	\N	f
70b1ef5c-e7a2-4727-9381-e481bdb4a9f6	user4@org1.faims	AQAAAAIAAYagAAAAECiSO+OPbM1y0p3YtakL9SAaIABnahVjHhxHBQMjKP8eFR08409vX6vw4BUjIsq43w==	Олександра	Романів	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.511633+00	\N	\N	f
916c26c8-d2e2-44f3-859d-1f65afbee01d	user6@org1.faims	AQAAAAIAAYagAAAAEIRR9a+i+e1ABDewICcKfRovHcPzoYrFSa8MZb6K5codvRYIomGokqC1MjX08a73cw==	Білослав	Стигайло	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.602561+00	\N	\N	f
cb8b7040-9e8e-448c-86ee-f1a281daa951	user10@org1.faims	AQAAAAIAAYagAAAAEMIsyE6qU6SpjK9+0fEspHT14ohTNSXepgdXgIXq4CxI1YI39TJFqFbHokAxw3s60Q==	Крентта	Горовий	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.781977+00	\N	\N	f
d8b2150e-226e-4c0a-86c1-d95d75cbd3fd	user11@org1.faims	AQAAAAIAAYagAAAAEP8sPMl015LAk+BRrTiFgzHWIzS2rayXc4xeyKY+Jmf9vPQrV29+8Xh2fM4b4+A7uw==	Руслан	Бачей	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.826556+00	\N	\N	f
f18f48a0-76df-4e4e-b172-65aa694751f5	user9@org1.faims	AQAAAAIAAYagAAAAEBJhumfOAWGdTktdiqKr+KfZagCJGBuBFQuXg0fphNwcPkDGVexQ4ZtRpJXvXjWVFQ==	Анна	Дзюба	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.737257+00	\N	\N	f
f704683c-26b2-4f67-acd3-5d3b793899ec	user5@org1.faims	AQAAAAIAAYagAAAAELpg6mudKowo393eqNupZEVI/fd6LWpiO73bq1OW8yLw6V1gKbNoY0qPCqXEFFX7kQ==	Людмила	Гриневська	1	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.556914+00	\N	\N	f
0b1a46c4-9749-40f7-a98e-9a677ae01a8c	user4@org2.faims	AQAAAAIAAYagAAAAEJQWdzId34nu1akaafo6KFj9LiHI8os4ETiaz5b1Am1UBzV+SbprihcRLIXqiHsb1w==	Ратибор	Зварич	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.437365+00	\N	\N	f
112ffb29-b1d0-4a55-b239-b84f5639842a	user8@org2.faims	AQAAAAIAAYagAAAAEJEx6KN07AsrKJmVy/1B3xX/yizE/8HDRp4QI2zHwaFaJYydT3gb1K6DXGCJXjMDmw==	Мстислава	Горбач	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.622886+00	\N	\N	f
13c10326-88f8-4262-ae80-1b46898055dd	user2@org2.faims	AQAAAAIAAYagAAAAEB2qAtjl+MOPu7NNsyokOL2vjEYHOH766H6ogkV5V7SuUGSmQcjaXB6ZdRXdAg0Aaw==	Ростислав	Саєнко	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.347795+00	\N	\N	f
1704dbbd-7325-45fe-81c9-882d46afd09b	admin@org2.faims	AQAAAAIAAYagAAAAEGpWS8QEg1zuuGTr2WA4YJR3dV01i9nX1UdKHQ5nA+oPaIlCtf0LvBfJn0U21U64Zg==	Адміністратор	#2	0	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.248008+00	\N	\N	f
68202c68-294e-4a04-b5c6-af07caccaad8	user9@org2.faims	AQAAAAIAAYagAAAAEIXJZMYfjJ5F/+3flgHSslNdjhB83llPPI5C993ahmxiAeYCT+evsca6D/66yiGbSA==	Стожар	Роменець	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.669831+00	\N	\N	f
6e81ae0f-1cff-4006-a4b2-1313f573d224	user3@org2.faims	AQAAAAIAAYagAAAAECBCMP9LWGaf7AaBPWCqu+P0OGBi4seeesua61QdAN6STcxP6M8SxoOQKtg/AV3tJg==	Сніжан	Євенко	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.392547+00	\N	\N	f
84321877-7731-4a53-8eb0-43e62cba6d22	user5@org2.faims	AQAAAAIAAYagAAAAEBXscDDIz8+QdjvKfZM6c/qF2xasqSC0LKO3Q/OmG8QezRYt5tSLLkukRwdEjMiBMw==	Доброслава	Сторчак	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.481789+00	\N	\N	f
9290c915-0a1e-48bf-8af7-f8f5a2afe8f6	user6@org2.faims	AQAAAAIAAYagAAAAEHv2YwP+WjLRJm/JsPbb1oBd0A+K1SMKGWqws+K/rP//jYuYES5j0kdyznrntyCimg==	Василина	Потоцька	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.529137+00	\N	\N	f
9c5d76b1-4179-48e5-9222-ef71e2e981fb	user1@org2.faims	AQAAAAIAAYagAAAAECkGjnAHVO/k3RDLi1GMEtIES7OHac3oK3UrNx+RBaT2iCazwvrFE267dnGlCovccQ==	Марта	Ромочко	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.299998+00	\N	\N	f
f535a0c6-8624-4bf3-bd86-9d18f6aae388	user10@org2.faims	AQAAAAIAAYagAAAAECpGLLtH4eYK3LvwcWq6Ua0+rp7rAHTaXxjqmwtg3fKL9GjM+aegF6TnkP0H/lLFtQ==	Натан	Силецький	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.716286+00	\N	\N	f
f56fe224-1c44-4692-865d-be39ff1c4041	user7@org2.faims	AQAAAAIAAYagAAAAENEeDkCqxRz9hXEYYvz7w2NHH5t1cJqwTzbHb1WoJHtYVb/EpQWHvC5zM8gGmRQ5HA==	Звенигор	Третяк	1	\N	8f8527e7-589e-4aa7-92f3-fcbbd3bf667a	\N	2026-04-10 08:45:44.576118+00	\N	\N	f
30110403-4d1a-44f8-8cd9-04d92f5663c8	user7@org3.faims	AQAAAAIAAYagAAAAEJSfXkC5hVQjJ2vLx1ku0v1TPSdgWEPo5Ju2W/7c/p2ajxUbmjGcIzN1LyhW5+rVXg==	Адам	Ящук	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.184277+00	\N	\N	f
51953ce5-3663-4f9e-a117-4c5b99a6fbd7	user6@org3.faims	AQAAAAIAAYagAAAAEN9qPeswqyyC99PAIdjk9jD1/eqBHkB8ncw3TI6kqKQIgu18LvCp1SJ0AynARoFdXw==	Гарнослав	Лобачевський	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.139178+00	\N	\N	f
57d0af0e-6ec7-41b7-be5a-2c1850d758dc	user11@org3.faims	AQAAAAIAAYagAAAAEM/ZNF/NU2gRos096fKmHyEqL4hGRetcpDkxLiC+7XTlifHtLSVwF0y5j7LCWto13A==	Ратибор	Москалюк	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.365116+00	\N	\N	f
766cfdc7-d787-43be-b50d-cd7ffdebf54f	admin@org3.faims	AQAAAAIAAYagAAAAEC7AzHGehKciWpojGUYCxXLeBTwuQbzauj3R4wDh3hQzwWz0f1GJBF1/j7dp98sBww==	Адміністратор	#3	0	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:44.863792+00	\N	\N	f
8a7df9ad-f99a-4687-83b1-a974c72d0657	user10@org3.faims	AQAAAAIAAYagAAAAEIlgEhenK2lqpHiahzawJlZTW4IIRsjvphp6n7onJOOggPXkpvbdv0vuSWp2TRB8ew==	Злат	Федоришина	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.319926+00	\N	\N	f
8c02d414-979a-4fa5-a16d-486026ad9f7b	user8@org3.faims	AQAAAAIAAYagAAAAEAmf8fM8oQQovguCwexDsutX+doDH0d4nGgx5ktYEuqedlzmVOecvSts2CDZZTrCPw==	Тетяна	Шудрик	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.230186+00	\N	\N	f
b2e71292-8b17-4167-b4fa-e0d34af255ba	user12@org3.faims	AQAAAAIAAYagAAAAEAdVdv0fmwbPMQQyIOnd/IEwCsKD84vDrFUNLgno29l5nrVGT9uwpx4H4Qw+qp75Lg==	Василь	Махно	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.410468+00	\N	\N	f
b7772c6a-cce9-4b4d-8b26-53f4dae7375e	user1@org3.faims	AQAAAAIAAYagAAAAEIpevCP0Zh/EkWsN3lAtTyqoKuEp6Tk5Biqd2mNfQDTs/vvlL09OSENiLbW+V+upog==	Віталіна	Григоришина	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:44.910631+00	\N	\N	f
d830c597-a126-4420-9735-2bc6e0c1ed84	user5@org3.faims	AQAAAAIAAYagAAAAELPJm7reyhh0F54E2AY3+ag8GFTpW0eT83ncBckbVjDHJTSE1ZctDDZfvDGyA4Vaug==	Таїсія	Миклашевський	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.094282+00	\N	\N	f
e9e6681a-b8c6-4ed7-9f46-27959285c73c	user9@org3.faims	AQAAAAIAAYagAAAAEJCQbtF8tDgtLUmzoRQt0krJwO7+LcwqglYgbhmlT2puU7Fn8FAlDkBuoAzO7COkxg==	Тур	Третяк	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.275147+00	\N	\N	f
f180ad63-2730-43fc-83da-54fa3c9da5a4	user4@org3.faims	AQAAAAIAAYagAAAAEM0mdQJF0PTBYuvHuayCigrNoygaakr3F7RspUe57J4UUyOkmDegOIsWxgyWPeGtng==	Далемир	Москалюк	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.049548+00	\N	\N	f
f3eab368-5eb5-4e86-81ee-fbd331a647cc	user2@org3.faims	AQAAAAIAAYagAAAAEIMTra7lsQhKlMpoXweFOM/JQPYqbr/Z4XGU+V9Lm/IXXHlXrZej9f7LBMIoeieAvw==	Слава	Корнїйчук	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:44.955753+00	\N	\N	f
f7c84a1b-3bee-43df-b289-164526a9f502	user3@org3.faims	AQAAAAIAAYagAAAAELN2lsIgccoMoHZwC5Az/viADfvXrc5H1Ae2347B6g0iiIaNQsbeME4nC/CuZz7ocA==	Алла	Городоцький	1	\N	82ada3f9-55db-4ef1-9e08-0e66d08e92c1	\N	2026-04-10 08:45:45.001721+00	\N	\N	f
012587be-48f8-4678-9486-6fb54e502d2d	user4@org4.faims	AQAAAAIAAYagAAAAEGJWzmx4LmvjstPU2izJUGB8QvIqpK125sr3tFgWZGEkQVqq5L2bfbt6sx69uDgmjg==	Ілона	Бердник	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.728495+00	\N	\N	f
0d7481c3-6296-4ea8-9904-a8332b6ff51f	user6@org4.faims	AQAAAAIAAYagAAAAEFQ1YX2a8uK1xjjEQmM6PSmPUA8RZ/wkO3JCK6m35OmeFA5JBdp/2axpL9BT2QzrAw==	Болеслава	Марків	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.818306+00	\N	\N	f
1a5e4c12-68c3-45d3-a92d-bef2c82e1334	user5@org4.faims	AQAAAAIAAYagAAAAEBK4rqGYW8IE/fXcxZqrLVI7giYvAC2Xtw+n3GH8Sejp8Z2ouxVB47AbN3mVLS3UAQ==	Соломія	Семещук	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.773335+00	\N	\N	f
2a779739-3a10-43b2-b1ce-cf108480a30a	user7@org4.faims	AQAAAAIAAYagAAAAEJO1Jbi/7psn/P3vO42D8N7/KIK1o56edO091bxyO/LnijmGlvAkQ6uSuL2mrXap6g==	Влад	Луцьків	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.863799+00	\N	\N	f
2f99e495-00e9-495b-b6c2-80d6c2a06e6c	user10@org4.faims	AQAAAAIAAYagAAAAEPahWu4d5wWcVvhwIorao9faJbeoTCuZ6KkCwOqOT4I7MpZpyG2G+OQLCrlf6Z+I5A==	Владислав	Миклухо	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.998173+00	\N	\N	f
4d12ada0-e540-45f2-82d9-1f09d36f8c44	user3@org4.faims	AQAAAAIAAYagAAAAEH6SQmVpFS5CfyWc9aUjn9/+XDM+kwQ9fYES7Xf1PBTm3oYWJFDv+K051rrchLbdzw==	Антон	Лазірко	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.683904+00	\N	\N	f
5781d60c-cc1d-4a0f-89f2-e1690857287d	user1@org4.faims	AQAAAAIAAYagAAAAENWPKiCSwhdQFnWhpCDX0rqympdRwcUE56VRfUbLlL3dr5sLPOVk0eiDU2WwqgtRCA==	Панас	Марієвська	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.594454+00	\N	\N	f
7b3c5f0e-9841-4520-a32e-b8a3b20d137f	admin@org4.faims	AQAAAAIAAYagAAAAEB9sMjAkCK+ZCK2aJuOQvK2S18IMiSAosgssJeo+diJEQAbfr/e9ONhqXFe/JzyxKQ==	Адміністратор	#4	0	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.548918+00	\N	\N	f
8e6640f0-577c-476f-975a-33c1ddf2fd63	user9@org4.faims	AQAAAAIAAYagAAAAEOX8lkljCLOgrfcRA09lFCbgnmQaBWhEeuFEoug+lN6ehZkfWwgZmUMzi54h2sNvcA==	Григорій	Василишина	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.953499+00	\N	\N	f
d234d8f8-8f49-4a69-b268-316777633cb9	user2@org4.faims	AQAAAAIAAYagAAAAELg6urYrEpoICUlftooaYAswaPKalKA838ttoap4YmOgrzPtIWCANSF5Ysz8jZhn7Q==	Анфіса	Усич	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.639+00	\N	\N	f
d249ab9d-20be-4594-9730-5e8ca7be7707	user8@org4.faims	AQAAAAIAAYagAAAAEA2hkLD5TGOe9s/15yIk1rijVHpD9pexzc4/gImI+jVzHl+9mkZvdv2melAsPSUktw==	Таїсія	Милославський	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:45.908652+00	\N	\N	f
dce88cda-deda-494c-a043-57cfee71a2d7	user11@org4.faims	AQAAAAIAAYagAAAAEHbbHZYfVey2Il0HKP2Dujlh7gxnE06aOVX4gg35ld5NeLmbhF+DXvj6kJTJdDHJnw==	Щек	Дурдинець	1	\N	0fcb59c3-f80b-43dc-b4f6-25c876836ab4	\N	2026-04-10 08:45:46.046835+00	\N	\N	f
0df2f73a-fdaf-4db2-8a57-390642dc1c66	user1@org5.faims	AQAAAAIAAYagAAAAEIgmYzmaHt6dhyXaZovOztBfZ2P4WzQL59V6mdzp/6wn6vRAdGN1mTSw8t5tkZL2zQ==	Максим	Яловий	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.182897+00	\N	\N	f
3f27d2dc-02ef-4b09-b829-81cfb6be5ed7	user5@org5.faims	AQAAAAIAAYagAAAAEFio6V7qlZ59OLj6oBEjh7lEU8AG1A5iUlKRrUi9cjLXY+Jmq6Ne3HGOGHM1HR5neg==	Устим	Плаксій	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.361577+00	\N	\N	f
44e6ae52-0550-4867-b49b-92eb3078c59d	user11@org5.faims	AQAAAAIAAYagAAAAELvXUGDbH0Deo/l1jBNGHD6vuM0XLMmVAxRKPNe97hokfYznds4aU1Qiz2p23rrQ2w==	Орися	Сплюх	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.631267+00	\N	\N	f
6d85ddc4-0576-4ee7-9659-40bd84327709	admin@org5.faims	AQAAAAIAAYagAAAAECV45YhCsKDt/eGEVsSNDQUPRn4X9vxkRJn10AVU5g2Gf/gOXCKzUUkPEBsiyJoccw==	Адміністратор	#5	0	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.137287+00	\N	\N	f
75e94312-d7fd-4db6-8fd6-5a8f52bf70dd	user6@org5.faims	AQAAAAIAAYagAAAAEAMEIX7MsUAAwau0UDxnWdSw4LvVvaYr9hFHoDErdwuWIHXYW3QTQ72cxGBNf6wOPg==	Пелагея	Сторожук	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.406768+00	\N	\N	f
7a2e2c23-f709-46a0-81b7-17a60ab2e754	user4@org5.faims	AQAAAAIAAYagAAAAEG/h7l/XEri1B+ALaAvVXqZx4mnYOSmCDMBq0Q6umj185IEbM8MaPDWPuaYkaCIwcA==	Немира	Яцьків	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.316961+00	\N	\N	f
7c42e46e-f141-4f8e-9a48-00fd59443331	user3@org5.faims	AQAAAAIAAYagAAAAECxgsW6vEMy2tzbzTAyQc5lSfjmb9RbhaQqfG5ANQJ4T+KN6uzsYW+qpj3RU/uJrCg==	Анастасія	Лагойда	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.271864+00	\N	\N	f
8a1196c3-cdb3-4728-bb24-b4e505f57788	user9@org5.faims	AQAAAAIAAYagAAAAEHTBXDE/KqVA8kVwtfvmewYl+6il5tDHJouYM+hp0Q3mBIXAW8RnOo8va0exbafxhg==	Поліна	Андрухович	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.541479+00	\N	\N	f
8da86b6a-99c2-4450-bde9-72a97861930f	user8@org5.faims	AQAAAAIAAYagAAAAEELayw/Lj9ifRFIqo85R3xD+MlT1IuanavPOQqm7WQb4kaI7eqwahwL+IqGhQAuGGg==	Валерія	Бутько	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.496716+00	\N	\N	f
b6a9c9e5-1d6b-4a19-88fd-447ea8cd5539	user2@org5.faims	AQAAAAIAAYagAAAAEOfWrq9fCE+GfdXWtQqjNvvgwqbOky78MMPwyxuXDPQ8Cew1gtEkrqAMgJ2cuD5KVg==	Люборада	Негода	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.227421+00	\N	\N	f
b7707c87-cdc9-481a-bff6-8a3cbc4c8505	user12@org5.faims	AQAAAAIAAYagAAAAEHYcnp4pIPMEAsFIBc97XzroXe4+jnjUSRC4iOgOtdndwf1fGzTO0/9iyJ+goMgqJg==	Мілана	Стигайло	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.675886+00	\N	\N	f
ca5da4dd-33dd-4259-ba1f-6ffcc151d53c	user10@org5.faims	AQAAAAIAAYagAAAAEOSn44bmA4aQd14UaUKEst/ogQwbtgzhkzBWhA8aKhjuy95YH236hxFZ6wRL2UUkxQ==	Яромил	Латан	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.586211+00	\N	\N	f
e08aa6e4-e325-4b14-a4c8-59c2b8b5e2b8	user7@org5.faims	AQAAAAIAAYagAAAAEEAR0sAaow6jL058j3MQyfDIHkCz3rtb6lJ71z+gOvUuDhOniWddRJpVOEsiyddeOQ==	Макар	Городоцький	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.451323+00	\N	\N	f
e69e45c3-3993-4935-8237-1d279e96e12b	user13@org5.faims	AQAAAAIAAYagAAAAEL8mQ/P62tveprzwVnpunckWnSpLd7usgqbQm//sIrZXZxFc7GwAaf/GgVwQnMByqw==	Земислав	Приймак	1	\N	80ae5be4-384d-4c59-bace-7165043a8b73	\N	2026-04-10 08:45:46.720875+00	\N	\N	f
063a708f-4471-488e-81e4-fa4617696898	deleted_063a708f4471488e81e4fa4617696898@deleted.faims	64e32af9-6a59-4b19-9037-a8dcc8b11a66	Видалено	Користувач	0	\N	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-10 08:45:43.284547+00	2026-04-16 07:38:46.515255+00	2026-04-16 07:42:53.26684+00	t
0f8ed8de-312a-498a-84fa-3ef04e663455	user1@org1.faims	AQAAAAIAAYagAAAAEDifFLBYalafCkLL/ChOG/5mFwFqmhDApBV2/oDYr+TZuhxgfJW81hjqWN4O6ToYPA==	Доляна	Слободян	1	f0rVOybvR4myFZ1O0dMwe0:APA91bEOAz0XjkEF2kdg5mz-YccckpmdmOuZVmZR1bQG1qvXFDSXS68x-kDKLng0IzBbJYPvxSO73ZxpWoZgOl1zmPDr2cu2hjyIH5VjJpidaKlOeM1sytE	69d1796a-d3cb-4761-b636-873c46de50ad	/avatars/0f8ed8de-312a-498a-84fa-3ef04e663455.png	2026-04-10 08:45:43.377435+00	2026-04-16 17:58:20.931231+00	\N	f
019d9634-10f6-7e3d-8898-a05a0de01bd7	test@gmail.com	AQAAAAIAAYagAAAAEEiiIulqw9NB9M9Fho4kIEeXsIO+bQeD9+3oFMMtLo+i0dhPDzejBuZZAs35fHz45A==	Тест	Тест	1	dLHOXi8RS4-g8ajqZl_7--:APA91bEIcPW_Fi2CisJmJiPwpnbpp_6jPDPlUu4nQ7y8RUwP__lNVvTmHy_NilC6Y72OksQ668_d7GIK4Mw4P0GXqdJ9Lses5H6RJm33dx4r6u4kIwlmnlg	69d1796a-d3cb-4761-b636-873c46de50ad	\N	2026-04-16 12:11:27.801526+00	2026-04-16 12:14:04.649761+00	\N	f
3b77085b-d895-4074-9e32-2022c609b673	admin2@org1.faims	AQAAAAIAAYagAAAAEHZmppSV6Y6eeghC8Txii5J6y7D3EDQmxJKeeHDZeklvV/Utv1ZMJrMpW9SofbcZxQ==	Ореста	Балабан	0	fo3MG0xwRqekMQ0E2WMXxF:APA91bEziM_PmoZ8oEk0zkEyvhtTATFVNSnCVxMuSJJLfA6VIIvGpd7A8IoNUglsDghkENHRREEr1a3fvbuHyxcZ6W5hfABBOkfLDFtB_yJzGOt2e3WGst4	69d1796a-d3cb-4761-b636-873c46de50ad	/avatars/3b77085b-d895-4074-9e32-2022c609b673.jpg	2026-04-10 08:45:43.692291+00	2026-04-16 17:20:24.663742+00	\N	f
\.


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: faims_admin
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20260318195701_InitialCreate	9.0.10
20260331145620_AddRefreshTokens	9.0.10
20260415084534_AddSoftDelete	9.0.10
\.


--
-- Name: Departments PK_Departments; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Departments"
    ADD CONSTRAINT "PK_Departments" PRIMARY KEY ("Id");


--
-- Name: FirstAidKits PK_FirstAidKits; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."FirstAidKits"
    ADD CONSTRAINT "PK_FirstAidKits" PRIMARY KEY ("Id");


--
-- Name: Journals PK_Journals; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Journals"
    ADD CONSTRAINT "PK_Journals" PRIMARY KEY ("Id");


--
-- Name: Medications PK_Medications; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Medications"
    ADD CONSTRAINT "PK_Medications" PRIMARY KEY ("Id");


--
-- Name: Organizations PK_Organizations; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Organizations"
    ADD CONSTRAINT "PK_Organizations" PRIMARY KEY ("Id");


--
-- Name: RefreshTokens PK_RefreshTokens; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."RefreshTokens"
    ADD CONSTRAINT "PK_RefreshTokens" PRIMARY KEY ("Id");


--
-- Name: Rooms PK_Rooms; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Rooms"
    ADD CONSTRAINT "PK_Rooms" PRIMARY KEY ("Id");


--
-- Name: Users PK_Users; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "PK_Users" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: IX_Departments_OrganizationId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Departments_OrganizationId" ON public."Departments" USING btree ("OrganizationId");


--
-- Name: IX_FirstAidKits_OrganizationId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_FirstAidKits_OrganizationId" ON public."FirstAidKits" USING btree ("OrganizationId");


--
-- Name: IX_FirstAidKits_ResponsibleUserId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE UNIQUE INDEX "IX_FirstAidKits_ResponsibleUserId" ON public."FirstAidKits" USING btree ("ResponsibleUserId");


--
-- Name: IX_FirstAidKits_RoomId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE UNIQUE INDEX "IX_FirstAidKits_RoomId" ON public."FirstAidKits" USING btree ("RoomId");


--
-- Name: IX_FirstAidKits_UniqueNumber; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE UNIQUE INDEX "IX_FirstAidKits_UniqueNumber" ON public."FirstAidKits" USING btree ("UniqueNumber");


--
-- Name: IX_Journals_FirstAidKitId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Journals_FirstAidKitId" ON public."Journals" USING btree ("FirstAidKitId");


--
-- Name: IX_Journals_OrganizationId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Journals_OrganizationId" ON public."Journals" USING btree ("OrganizationId");


--
-- Name: IX_Journals_UserId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Journals_UserId" ON public."Journals" USING btree ("UserId");


--
-- Name: IX_Medications_FirstAidKitId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Medications_FirstAidKitId" ON public."Medications" USING btree ("FirstAidKitId");


--
-- Name: IX_Medications_OrganizationId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Medications_OrganizationId" ON public."Medications" USING btree ("OrganizationId");


--
-- Name: IX_RefreshTokens_UserId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_RefreshTokens_UserId" ON public."RefreshTokens" USING btree ("UserId");


--
-- Name: IX_Rooms_DepartmentId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Rooms_DepartmentId" ON public."Rooms" USING btree ("DepartmentId");


--
-- Name: IX_Rooms_OrganizationId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Rooms_OrganizationId" ON public."Rooms" USING btree ("OrganizationId");


--
-- Name: IX_Users_OrganizationId; Type: INDEX; Schema: public; Owner: faims_admin
--

CREATE INDEX "IX_Users_OrganizationId" ON public."Users" USING btree ("OrganizationId");


--
-- Name: Departments FK_Departments_Organizations_OrganizationId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Departments"
    ADD CONSTRAINT "FK_Departments_Organizations_OrganizationId" FOREIGN KEY ("OrganizationId") REFERENCES public."Organizations"("Id") ON DELETE CASCADE;


--
-- Name: FirstAidKits FK_FirstAidKits_Organizations_OrganizationId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."FirstAidKits"
    ADD CONSTRAINT "FK_FirstAidKits_Organizations_OrganizationId" FOREIGN KEY ("OrganizationId") REFERENCES public."Organizations"("Id") ON DELETE CASCADE;


--
-- Name: FirstAidKits FK_FirstAidKits_Rooms_RoomId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."FirstAidKits"
    ADD CONSTRAINT "FK_FirstAidKits_Rooms_RoomId" FOREIGN KEY ("RoomId") REFERENCES public."Rooms"("Id") ON DELETE CASCADE;


--
-- Name: FirstAidKits FK_FirstAidKits_Users_ResponsibleUserId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."FirstAidKits"
    ADD CONSTRAINT "FK_FirstAidKits_Users_ResponsibleUserId" FOREIGN KEY ("ResponsibleUserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: Journals FK_Journals_FirstAidKits_FirstAidKitId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Journals"
    ADD CONSTRAINT "FK_Journals_FirstAidKits_FirstAidKitId" FOREIGN KEY ("FirstAidKitId") REFERENCES public."FirstAidKits"("Id") ON DELETE CASCADE;


--
-- Name: Journals FK_Journals_Organizations_OrganizationId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Journals"
    ADD CONSTRAINT "FK_Journals_Organizations_OrganizationId" FOREIGN KEY ("OrganizationId") REFERENCES public."Organizations"("Id") ON DELETE CASCADE;


--
-- Name: Journals FK_Journals_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Journals"
    ADD CONSTRAINT "FK_Journals_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: Medications FK_Medications_FirstAidKits_FirstAidKitId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Medications"
    ADD CONSTRAINT "FK_Medications_FirstAidKits_FirstAidKitId" FOREIGN KEY ("FirstAidKitId") REFERENCES public."FirstAidKits"("Id") ON DELETE CASCADE;


--
-- Name: Medications FK_Medications_Organizations_OrganizationId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Medications"
    ADD CONSTRAINT "FK_Medications_Organizations_OrganizationId" FOREIGN KEY ("OrganizationId") REFERENCES public."Organizations"("Id") ON DELETE CASCADE;


--
-- Name: RefreshTokens FK_RefreshTokens_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."RefreshTokens"
    ADD CONSTRAINT "FK_RefreshTokens_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: Rooms FK_Rooms_Departments_DepartmentId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Rooms"
    ADD CONSTRAINT "FK_Rooms_Departments_DepartmentId" FOREIGN KEY ("DepartmentId") REFERENCES public."Departments"("Id") ON DELETE CASCADE;


--
-- Name: Rooms FK_Rooms_Organizations_OrganizationId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Rooms"
    ADD CONSTRAINT "FK_Rooms_Organizations_OrganizationId" FOREIGN KEY ("OrganizationId") REFERENCES public."Organizations"("Id") ON DELETE CASCADE;


--
-- Name: Users FK_Users_Organizations_OrganizationId; Type: FK CONSTRAINT; Schema: public; Owner: faims_admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "FK_Users_Organizations_OrganizationId" FOREIGN KEY ("OrganizationId") REFERENCES public."Organizations"("Id") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict S0cKBaMyLkvxwyOh3BdsIeXPvTSh69Dp0ugZvOpFOqD0CXcZkITCqfWNpDW2qJJ

